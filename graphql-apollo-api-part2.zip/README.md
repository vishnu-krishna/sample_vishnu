# get into project folder

cd graphql-apollo-api-part2

# install dependencies

 npm install

# Run local dev server

npm run dev