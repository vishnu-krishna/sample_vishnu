const userEvents = require('./user');

module.exports = {
  userEvents
};