module.exports = {
  USER_CREATED: 'USER_CREATED'
};