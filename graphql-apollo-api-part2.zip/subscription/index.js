const { PubSub } = require('apollo-server-express');

module.exports = new PubSub();