const fse = require('fs-extra')
const archiver = require('archiver')

// Read arguments and ensure `relativeOutputDirectory` and `bundleName` are present
const args = process.argv
console.log(args)
if (args.length !== 4) {
  throw new Error(
    'You are missing arguments. Intended use is `node bundle-build-output.js relativeOutputDirectory bundleName`'
  )
}

// Make directories (release / snapshot) or empty if present already
fse.emptyDirSync('release')
fse.emptyDirSync('snapshot')

// Bundle /build output to /relativeOutputDirectory as bundleName.zip
var outputFileAddress = process.cwd() + `/${args[2]}/${args[3]}.zip`
const output = fse.createWriteStream(outputFileAddress)
const archive = archiver('zip', {
  zlib: { level: 9 }
})

output.on('close', function () {
  console.log(
    'Build folder has been compressed and output to ' + outputFileAddress
  )
})

output.on('end', function () {
  console.log('Data has been drained')
})

archive.on('warning', function (err) {
  if (err.code === 'ENOENT') {
    console.log(err)
  } else {
    throw err
  }
})

archive.on('error', function (err) {
  throw err
})

archive.pipe(output)
archive.directory('build/', '/')
archive.finalize()
