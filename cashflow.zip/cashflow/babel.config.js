module.exports = {
  presets: [
    '@babel/preset-react',
    [
      '@babel/preset-env',
      {
        targets: ['>0.25%', 'ie >= 11']
      }
    ]
  ],
  env: {
    test: {
      presets: ['@babel/preset-react'],
      plugins: ['transform-es2015-modules-commonjs']
    }
  }
}
