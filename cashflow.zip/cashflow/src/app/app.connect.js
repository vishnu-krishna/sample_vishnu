import { connect } from 'react-redux'
import { App } from 'app/app'

export default connect(state => state.appData)(App)
