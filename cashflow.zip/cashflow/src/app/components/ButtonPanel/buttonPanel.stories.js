import { storiesOf } from '@storybook/react'
import React from 'react'
import { ButtonPanel } from './buttonPanel.component'

export const defaultProps = {
  primaryButtonText: 'Continue',
  secondaryButtonText: 'Cancel',
  isPrimaryButtonDisabled: false,
  isSecondaryButtonDisabled: false,
  primaryButtonClicked: () => alert('Primary Button Clicked'),
  secondaryButtonClicked: () => alert('Secondary Button Clicked')
}

storiesOf('Button Panel Component', module).add('Default', () => (
  <ButtonPanel {...defaultProps} />
))
