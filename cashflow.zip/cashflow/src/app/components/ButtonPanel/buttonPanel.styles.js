import styled from 'styled-components'
import styleVars from '@anz/styles-global'

export const ButtonWrapper = styled.div`
  display: flex;
  justify-content: flex-end;
  margin-top: 66px;
`

export const PrimaryButton = styled.div`
  margin-left: ${styleVars.dimensions.gap20};
`

export const SecondaryButton = styled.div`
  margin-left: 35px;
`

export const HorizontalLine = styled.div`
  &:after {
    display: block;
    content: '';
    height: 1px;
    width: 100%;
    background-color: #cdcdcd;
    position: relative;
    top: 30px;
  }
`
