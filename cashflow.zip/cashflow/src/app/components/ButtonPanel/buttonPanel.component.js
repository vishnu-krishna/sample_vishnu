import Button from '../common/button/button.component'
import React from 'react'
import {
  ButtonWrapper,
  HorizontalLine,
  PrimaryButton,
  SecondaryButton
} from './buttonPanel.styles'
import PropTypes from 'prop-types'

export const ButtonPanel = ({
  primaryButtonText,
  secondaryButtonText,
  isPrimaryButtonDisabled,
  isSecondaryButtonDisabled,
  primaryButtonClicked,
  secondaryButtonClicked,
  primaryButtonId,
  secondaryButtonId
}) => (
  <>
    <ButtonPanel.HorizontalLine />
    <ButtonPanel.ButtonWrapper>
      {secondaryButtonText && (
        <ButtonPanel.SecondaryButton>
          <Button
            id={secondaryButtonId}
            buttonLabel={secondaryButtonText}
            isSecondary
            isDisabled={isSecondaryButtonDisabled}
            buttonClicked={secondaryButtonClicked}
            dataTestId='btnpanel-btn-secondary'
          />
        </ButtonPanel.SecondaryButton>
      )}
      <ButtonPanel.PrimaryButton>
        <Button
          id={primaryButtonId}
          buttonLabel={primaryButtonText}
          isDisabled={isPrimaryButtonDisabled}
          buttonClicked={primaryButtonClicked}
          dataTestId='btnpanel-btn-primary'
        />
      </ButtonPanel.PrimaryButton>
    </ButtonPanel.ButtonWrapper>
  </>
)

ButtonPanel.ButtonWrapper = ButtonWrapper
ButtonPanel.SecondaryButton = SecondaryButton
ButtonPanel.PrimaryButton = PrimaryButton
ButtonPanel.HorizontalLine = HorizontalLine

ButtonPanel.propTypes = {
  primaryButtonText: PropTypes.string.isRequired,
  secondaryButtonText: PropTypes.string,
  isPrimaryButtonDisabled: PropTypes.bool,
  isSecondaryButtonDisabled: PropTypes.bool,
  primaryButtonClicked: PropTypes.func,
  secondaryButtonClicked: PropTypes.func,
  primaryButtonId: PropTypes.string,
  secondaryButtonId: PropTypes.string
}

ButtonPanel.defaultProps = {
  primaryButtonText: 'Primary Button',
  secondaryButtonText: '',
  isPrimaryButtonDisabled: false,
  isSecondaryButtonDisabled: true
}
