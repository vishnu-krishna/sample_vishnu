import { buttonContentTestId } from '../common/button/button.component'
import React from 'react'
import { render } from '@testing-library/react'
import { ButtonPanel } from './buttonPanel.component'
import userEvent from '@testing-library/user-event'

describe('Button Panel Component', () => {
  const primaryButtonMock = jest.fn()
  const secondaryButtonMock = jest.fn()
  const buttonPanelProps = {
    primaryButtonText: 'Continue',
    secondaryButtonText: 'Cancel',
    primaryButtonClicked: primaryButtonMock,
    secondaryButtonClicked: secondaryButtonMock
  }

  beforeEach(() => {
    primaryButtonMock.mockClear()
    secondaryButtonMock.mockClear()
  })

  test('should enable the buttons and handle the clicks of the button', () => {
    const { getAllByTestId } = render(
      <ButtonPanel
        {...buttonPanelProps}
        isPrimaryButtonDisabled={false}
        isSecondaryButtonDisabled={false}
      />
    )
    const buttonElement = getAllByTestId(buttonContentTestId)
    expect(buttonElement[0]).not.toBeDisabled()
    expect(buttonElement[1]).not.toBeDisabled()
    userEvent.click(buttonElement[1])
    expect(primaryButtonMock).toHaveBeenCalled()
    userEvent.click(buttonElement[0])
    expect(secondaryButtonMock).toHaveBeenCalled()
  })

  test('should disable the buttons and NOT handle the clicks of the button', () => {
    const { getAllByTestId } = render(
      <ButtonPanel
        {...buttonPanelProps}
        isPrimaryButtonDisabled
        isSecondaryButtonDisabled
      />
    )
    const buttonElement = getAllByTestId(buttonContentTestId)
    expect(buttonElement[0]).toBeDisabled()
    expect(buttonElement[1]).toBeDisabled()
    userEvent.click(buttonElement[1])
    expect(primaryButtonMock).not.toHaveBeenCalled()
    userEvent.click(buttonElement[0])
    expect(secondaryButtonMock).not.toHaveBeenCalled()
  })
})
