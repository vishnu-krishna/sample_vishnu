import styled from 'styled-components'
import styleVars from '@anz/styles-global'

export const TabsWrapper = styled.div`
  // this is not the best approach to fix the column width
  // we need to modify the OceanBlue table component to be
  // able to set the column width properly.
  margin-bottom: 20px;
  #dashboard-tabs-headers {
    display: table;
    margin-top: 0;
    li {
      display: table-cell;
      padding-left: 5px;
      padding-right: 5px;
    }
    li:first-child {
      padding-left: 15px;
    }
    li:last-child {
      padding-right: 15px;
    }
  }
`

export const TableHeaderBar = styled.div`
  border-top-left-radius: 10px;
  border-top-right-radius: 10px;
  background-color: ${styleVars.color.oceanBlue};
  position: relative;
  height: 10px;
`

export const TableContents = styled.div`
  background-color: ${styleVars.color.white};
  height: 100%;
  border-left: 1px solid ${styleVars.color.lightGrey};
  border-right: 1px solid ${styleVars.color.lightGrey};
  border-bottom: 1px solid ${styleVars.color.lightGrey};
  ${({ withoutHeaderBar }) =>
    withoutHeaderBar &&
    `
    border-top: 1px solid ${styleVars.color.lightGrey};
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
  `}

  ${({ withoutBorder }) =>
    withoutBorder &&
    `
    border-top: none;
    border-top-left-radius: 0px;
    border-top-right-radius: 0px;
    border-bottom: none;
    border-left: none;
  `}

  ${({ fromCap }) =>
    fromCap &&
    `
    border-right: none
  `}
  }
`

export const TableHeaderText = styled.div`
  padding: 20px;
`

export const TableWrapper = styled.div`
  table {
    table-layout: fixed;
    width: 100%;
    // this is not the best approach to fix the column width
    // we need to modify the OceanBlue table component to be
    // able to set the column width properly.
    th:nth-child(2),
    td:nth-child(2) {
      padding-left: 0;
      width: 240px;
    }
    th:nth-child(3),
    td:nth-child(3) {
      min-width: ${({ tabConfigAndData: { showIcon } }) => showIcon && '300px'};
    }
    th:first-child,
    td:first-child {
      width: ${({ tabConfigAndData: { submissionDateTime } }) =>
        submissionDateTime ? '45px' : 'auto'};
      padding-left: 0;
      padding-right: 0;
    }
    th:last-child,
    td:last-child {
      width: ${({ tabConfigAndData: { moreOptions } }) =>
        moreOptions ? '60px' : 'auto'};
    }
  }
`
