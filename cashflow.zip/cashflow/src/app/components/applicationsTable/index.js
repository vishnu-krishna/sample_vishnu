import ApplicationsTable from 'app/components/applicationsTable/applicationsTable.component'

export default ApplicationsTable
