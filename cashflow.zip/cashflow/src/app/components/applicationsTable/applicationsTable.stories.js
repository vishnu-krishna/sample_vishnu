import React from 'react'
import { storiesOf } from '@storybook/react'
import ApplicationsTable from 'app/components/applicationsTable/applicationsTable.component'
import successResponse from 'app/components/applicationsTable/testData/applicationTable_success.json'
import emptyResponse from 'app/components/applicationsTable/testData/applicationTable_empty.json'

storiesOf('ApplicationsTable', module).add('With Data', () => {
  const appConfig = {
    title: 'Applications',
    tabs: [
      {
        title: 'Unassigned',
        headerMapping: [
          { title: '' },
          { title: 'Date & time of online submission' },
          { title: 'Entity name' },
          { title: 'OLA ID' },
          { title: 'BBD ID' },
          { title: 'Type' },
          { title: '' }
        ],
        dataMapping: {
          icon: '',
          submissionDateTime: 'created',
          entityName: 'entityName',
          olaID: '',
          bbdID: 'applicationId',
          type: 'applicationType',
          moreOptions: ''
        },
        columnNames: ['Column 1'],
        data: successResponse.summaries
      },
      {
        title: 'Assigned',
        headerMapping: [
          { title: '' },
          { title: 'Date & time of online submission' },
          { title: 'Entity name' },
          { title: 'OLA ID' },
          { title: 'BBD ID' },
          { title: 'Type' },
          { title: '' }
        ],
        dataMapping: {
          icon: '',
          submissionDateTime: 'created',
          entityName: 'entityName',
          olaID: '',
          bbdID: 'applicationId',
          type: 'applicationType',
          moreOptions: ''
        },
        data: successResponse.summaries
      },
      {
        title: 'My Tasks',
        headerMapping: [
          { title: '' },
          { title: 'Date & time of online submission' },
          { title: 'Entity name' },
          { title: 'OLA ID' },
          { title: 'BBD ID' },
          { title: 'Type' },
          { title: '' }
        ],
        dataMapping: {
          icon: '',
          submissionDateTime: 'created',
          entityName: 'entityName',
          olaID: '',
          bbdID: 'applicationId',
          type: 'applicationType',
          moreOptions: ''
        },
        data: successResponse.summaries
      }
    ]
  }

  appConfig.tabs.forEach(tab => {
    tab.data = successResponse.summaries
  })

  return (
    <ApplicationsTable
      configAndData={appConfig}
      dataTextWhenEmpty=''
      numberOfRecordsToDisplay={3}
    />
  )
})

storiesOf('ApplicationsTable', module).add('With empty data', () => {
  const appConfig = {
    title: 'Applications',
    tabs: [
      {
        title: 'Unassigned',
        headerMapping: [
          { title: '' },
          { title: 'Date & time of online submission' },
          { title: 'Entity name' },
          { title: 'OLA ID' },
          { title: 'BBD ID' },
          { title: 'Type' },
          { title: '' }
        ],
        dataMapping: {
          icon: '',
          submissionDateTime: 'created',
          entityName: 'entityName',
          olaID: '',
          bbdID: 'applicationId',
          type: 'applicationType',
          moreOptions: ''
        },
        columnNames: ['Column 1'],
        data: successResponse.summaries
      },
      {
        title: 'Assigned',
        headerMapping: [
          { title: '' },
          { title: 'Date & time of online submission' },
          { title: 'Entity name' },
          { title: 'OLA ID' },
          { title: 'BBD ID' },
          { title: 'Type' },
          { title: '' }
        ],
        dataMapping: {
          icon: '',
          submissionDateTime: 'created',
          entityName: 'entityName',
          olaID: '',
          bbdID: 'applicationId',
          type: 'applicationType',
          moreOptions: ''
        },
        data: successResponse.summaries
      },
      {
        title: 'My Tasks',
        headerMapping: [
          { title: '' },
          { title: 'Date & time of online submission' },
          { title: 'Entity name' },
          { title: 'OLA ID' },
          { title: 'BBD ID' },
          { title: 'Type' },
          { title: '' }
        ],
        dataMapping: {
          icon: '',
          submissionDateTime: 'created',
          entityName: 'entityName',
          olaID: '',
          bbdID: 'applicationId',
          type: 'applicationType',
          moreOptions: ''
        },
        data: successResponse.summaries
      }
    ]
  }

  appConfig.tabs.forEach(tab => {
    tab.data = emptyResponse.summaries
  })

  return (
    <ApplicationsTable
      configAndData={appConfig}
      dataTextWhenEmpty=''
      numberOfRecordsToDisplay={3}
    />
  )
})
