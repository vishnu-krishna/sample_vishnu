import React from 'react'
import { render } from '@testing-library/react'
import ApplicationsTable from 'app/components/applicationsTable/applicationsTable.component'
import successResponse from './testData/applicationTable_success.json'
import emptyResponse from './testData/applicationTable_empty.json'
import inFlightHistoryConfig from 'app/components/applicationsTable/testData/inFlight-history-config.json'
import store from 'store'
import { Provider } from 'react-redux'
import { APPLICATIONS_TABLE_MAX_NUMBER_INCREMENT } from 'app/constants'
import userEvent from '@testing-library/user-event'

window.env = { BBD_URL: 'http://someurl' }

const appConfig = {
  title: 'Applications',
  tabs: [
    {
      title: 'Unassigned',
      headerMapping: [
        { title: '' },
        { title: 'Date & time of online submission' },
        { title: 'Entity name' },
        { title: 'OLA ID' },
        { title: 'BBD ID' },
        { title: 'Type' },
        { title: '' }
      ],
      dataMapping: {
        icon: '',
        submissionDateTime: 'created',
        entityName: 'entityName',
        olaID: '',
        bbdID: 'applicationId',
        type: 'applicationType',
        moreOptions: ''
      },
      columnNames: [
        'urgency-icon',
        'submission-time',
        'entity-name',
        'ola-id',
        'bbd-id',
        'type',
        'actions-menu'
      ],
      data: successResponse.summaries
    },
    {
      title: 'Assigned',
      headerMapping: [
        { title: '' },
        { title: 'Date & time of online submission' },
        { title: 'Entity name' },
        { title: 'OLA ID' },
        { title: 'BBD ID' },
        { title: 'Type' },
        { title: '' }
      ],
      dataMapping: {
        icon: '',
        submissionDateTime: 'created',
        entityName: 'entityName',
        olaID: '',
        bbdID: 'applicationId',
        type: 'applicationType',
        moreOptions: ''
      },
      columnNames: [
        'urgency-icon',
        'submission-time',
        'entity-name',
        'ola-id',
        'bbd-id',
        'type',
        'actions-menu'
      ],
      data: successResponse.summaries
    },
    {
      title: 'My Tasks',
      headerMapping: [
        { title: '' },
        { title: 'Date & time of online submission' },
        { title: 'Entity name' },
        { title: 'OLA ID' },
        { title: 'BBD ID' },
        { title: 'Type' },
        { title: '' }
      ],
      dataMapping: {
        icon: '',
        submissionDateTime: 'created',
        entityName: 'entityName',
        olaID: '',
        bbdID: 'applicationId',
        type: 'applicationType',
        moreOptions: ''
      },
      columnNames: [
        'urgency-icon',
        'submission-time',
        'entity-name',
        'ola-id',
        'bbd-id',
        'type',
        'actions-menu'
      ],
      data: successResponse.summaries
    }
  ]
}

describe('ApplicationsTable', () => {
  it('renders correctly with application data', () => {
    appConfig.tabs.forEach(tab => {
      tab.data = successResponse.summaries
    })
    const dashboardTable = render(
      <Provider store={store}>
        <ApplicationsTable configAndData={appConfig} />
      </Provider>
    )

    expect(dashboardTable.asFragment()).toMatchSnapshot()
  })

  it('renders correctly with 0 data', () => {
    appConfig.tabs.forEach(tab => {
      tab.data = emptyResponse.summaries
    })
    const { asFragment, queryByText } = render(
      <Provider store={store}>
        <ApplicationsTable configAndData={appConfig} />
      </Provider>
    )

    expect(queryByText('Displaying applications: 0 to 0 of 0')).not.toBeNull()

    expect(asFragment()).toMatchSnapshot()
  })

  it('correctly set the states of the show more/show less buttons and loads the correct number of applications to the table', () => {
    appConfig.tabs.forEach(tab => {
      tab.data = successResponse.summaries
    })

    const { getAllByTestId, getByTestId } = render(
      <Provider store={store}>
        <ApplicationsTable
          configAndData={appConfig}
          maximumNumberOfRowsToDisplay={APPLICATIONS_TABLE_MAX_NUMBER_INCREMENT}
        />
      </Provider>
    )

    const moreButton = getByTestId('showMore_button')
    const lessButton = getByTestId('showLess_button')

    const dashboardRowIdRegex = /^dashboard-table-table-body_row_(\d)*$/
    let numberOfApplicationRows = getAllByTestId(dashboardRowIdRegex).length

    expect(numberOfApplicationRows).toEqual(20)
    expect(moreButton).toBeEnabled()
    expect(lessButton).toBeDisabled()
    userEvent.click(moreButton)

    numberOfApplicationRows = getAllByTestId(dashboardRowIdRegex).length
    expect(numberOfApplicationRows).toEqual(40)
    expect(moreButton).toBeEnabled()
    expect(lessButton).toBeEnabled()
    userEvent.click(lessButton)

    numberOfApplicationRows = getAllByTestId(dashboardRowIdRegex).length
    expect(numberOfApplicationRows).toEqual(20)
    expect(moreButton).toBeEnabled()
    expect(lessButton).toBeDisabled()
    userEvent.click(lessButton)
  })

  it('correctly set the states of the show more/show less buttons and loads the correct number of Inflight and history applications to the table', () => {
    const { getByTestId, getAllByTestId } = render(
      <Provider store={store}>
        <ApplicationsTable
          configAndData={inFlightHistoryConfig}
          maximumNumberOfRowsToDisplay={5}
        />
      </Provider>
    )

    const moreButton = getByTestId('showMore_button')
    const lessButton = getByTestId('showLess_button')

    const dashboardRowIdRegex = /^dashboard-table-table-body_row_(\d)*$/
    let numberOfApplicationRows = getAllByTestId(dashboardRowIdRegex).length

    expect(numberOfApplicationRows).toEqual(5)
    expect(moreButton).toBeEnabled()
    expect(lessButton).toBeDisabled()
    userEvent.click(moreButton)

    numberOfApplicationRows = getAllByTestId(dashboardRowIdRegex).length
    expect(numberOfApplicationRows).toEqual(10)
    expect(moreButton).toBeEnabled()
    expect(lessButton).toBeEnabled()
    userEvent.click(lessButton)

    numberOfApplicationRows = getAllByTestId(dashboardRowIdRegex).length
    expect(numberOfApplicationRows).toEqual(5)
    expect(moreButton).toBeEnabled()
    expect(lessButton).toBeDisabled()
    userEvent.click(lessButton)
  })
})

describe('Application table with consent status column', () => {
  const appConfig = {
    title: 'Applications',
    tabs: [
      {
        title: 'Unassigned',
        headerMapping: [
          { title: '' },
          { title: 'Date & time of online submission' },
          { title: 'Entity name' },
          { title: 'OLA ID' },
          { title: 'BBD ID' },
          { title: 'Type' },
          { title: 'Consent Status' },
          { title: '' }
        ],
        dataMapping: {
          icon: '',
          submissionDateTime: 'created',
          entityName: 'entityName',
          olaID: '',
          bbdID: 'applicationId',
          type: 'applicationType',
          appConsentsStatus: 'appConsentsStatus',
          moreOptions: ''
        },
        columnNames: [
          'urgency-icon',
          'submission-time',
          'entity-name',
          'ola-id',
          'bbd-id',
          'type',
          'consent-status',
          'actions-menu'
        ],
        consentStats: {
          Pending: 0,
          Received: 0,
          Failed: 0,
          Expired: 0
        },
        data: successResponse.summaries
      },
      {
        title: 'Assigned',
        headerMapping: [
          { title: '' },
          { title: 'Date & time of online submission' },
          { title: 'Entity name' },
          { title: 'OLA ID' },
          { title: 'BBD ID' },
          { title: 'Type' },
          { title: 'Consent Status' },
          { title: '' }
        ],
        dataMapping: {
          icon: '',
          submissionDateTime: 'created',
          entityName: 'entityName',
          olaID: '',
          bbdID: 'applicationId',
          type: 'applicationType',
          appConsentsStatus: 'appConsentsStatus',
          moreOptions: ''
        },
        columnNames: [
          'urgency-icon',
          'submission-time',
          'entity-name',
          'ola-id',
          'bbd-id',
          'type',
          'consent-status',
          'actions-menu'
        ],
        consentStats: {
          Pending: 0,
          Received: 0,
          Failed: 0,
          Expired: 0
        },
        data: successResponse.summaries
      },
      {
        title: 'My Tasks',
        headerMapping: [
          { title: '' },
          { title: 'Date & time of online submission' },
          { title: 'Entity name' },
          { title: 'OLA ID' },
          { title: 'BBD ID' },
          { title: 'Type' },
          { title: 'Consent Status' },
          { title: '' }
        ],
        dataMapping: {
          icon: '',
          submissionDateTime: 'created',
          entityName: 'entityName',
          olaID: '',
          bbdID: 'applicationId',
          type: 'applicationType',
          appConsentsStatus: 'appConsentsStatus',
          moreOptions: ''
        },
        columnNames: [
          'urgency-icon',
          'submission-time',
          'entity-name',
          'ola-id',
          'bbd-id',
          'type',
          'consent-status',
          'actions-menu'
        ],
        consentStats: {
          Pending: 0,
          Received: 0,
          Failed: 0,
          Expired: 0
        },
        data: successResponse.summaries
      }
    ]
  }

  it('renders correctly with application data with consent column', () => {
    appConfig.tabs.forEach(tab => {
      tab.data = successResponse.summaries
    })
    const dashboardTable = render(
      <Provider store={store}>
        <ApplicationsTable configAndData={appConfig} />
      </Provider>
    )

    expect(dashboardTable.asFragment()).toMatchSnapshot()
  })

  it('To validate whether consent column is displayed in application table', () => {
    appConfig.tabs.forEach(tab => {
      tab.data = successResponse.summaries
    })

    const { getByTestId, getAllByTestId } = render(
      <Provider store={store}>
        <ApplicationsTable
          configAndData={appConfig}
          maximumNumberOfRowsToDisplay={APPLICATIONS_TABLE_MAX_NUMBER_INCREMENT}
        />
      </Provider>
    )

    const moreButton = getByTestId('showMore_button')
    const lessButton = getByTestId('showLess_button')

    const dashboardRowIdRegex = /^dashboard-table-table-body_row_(\d)*$/
    let numberOfApplicationRows = getAllByTestId(dashboardRowIdRegex).length

    const dashboardColIdRegex = /^dashboard-table-table-body_row_0_col_(\d)*$/
    let numberOfApplicationCols = getAllByTestId(dashboardColIdRegex).length

    expect(numberOfApplicationCols).toEqual(9)

    expect(numberOfApplicationRows).toEqual(20)
    expect(moreButton).toBeEnabled()
    expect(lessButton).toBeDisabled()
    userEvent.click(moreButton)

    numberOfApplicationRows = getAllByTestId(dashboardRowIdRegex).length
    expect(numberOfApplicationRows).toEqual(40)
    expect(moreButton).toBeEnabled()
    expect(lessButton).toBeEnabled()
    userEvent.click(lessButton)

    numberOfApplicationRows = getAllByTestId(dashboardRowIdRegex).length
    expect(numberOfApplicationRows).toEqual(20)
    expect(moreButton).toBeEnabled()
    expect(lessButton).toBeDisabled()
    userEvent.click(lessButton)
  })

  it('To validate whether consent stats block is displayed above application table', () => {
    appConfig.tabs.forEach(tab => {
      tab.data = successResponse.summaries
    })

    const { getByTestId, getAllByTestId } = render(
      <Provider store={store}>
        <ApplicationsTable
          configAndData={appConfig}
          maximumNumberOfRowsToDisplay={APPLICATIONS_TABLE_MAX_NUMBER_INCREMENT}
        />
      </Provider>
    )

    const dashboardColIdRegex = /^dashboard-table-table-body_row_0_col_(\d)*$/
    let numberOfApplicationCols = getAllByTestId(dashboardColIdRegex).length

    expect(numberOfApplicationCols).toEqual(9)

    const receivedStats = getByTestId('consent-stats-icon-Received')
    const pendingStats = getByTestId('consent-stats-icon-Pending')
    const failedStats = getByTestId('consent-stats-icon-Failed')
    const expiredStats = getByTestId('consent-stats-icon-Expired')
    const receivedStatsContent = getByTestId('consent-stats-content-Received')
    const pendingStatsContent = getByTestId('consent-stats-content-Pending')
    const failedStatsContent = getByTestId('consent-stats-content-Failed')
    const expiredStatsContent = getByTestId('consent-stats-content-Expired')
    expect(getByTestId('consent-stats-wrapper')).toBeInTheDocument()
    expect(receivedStats).toBeInTheDocument()
    expect(pendingStats).toBeInTheDocument()
    expect(failedStats).toBeInTheDocument()
    expect(expiredStats).toBeInTheDocument()
    expect(receivedStatsContent).toBeInTheDocument()
    expect(pendingStatsContent).toBeInTheDocument()
    expect(failedStatsContent).toBeInTheDocument()
    expect(expiredStatsContent).toBeInTheDocument()
    expect(receivedStatsContent.innerHTML).toBe('Received: 0')
    expect(pendingStatsContent.innerHTML).toBe('Pending: 0')
    expect(failedStatsContent.innerHTML).toBe('Failed: 0')
    expect(expiredStatsContent.innerHTML).toBe('Expired: 0')
  })
})
