import React, { useEffect, useState } from 'react'
import { Tab, Tabs } from '@anz/tabs'
import Table from 'app/components/anz/table/sortableTable.component'
import anzStyles from '@anz/styles-global'
import {
  TableWrapper,
  TabsWrapper
} from 'app/components/applicationsTable/applicationsTable.styles'
import UrgencyIcon from '../dashboard/urgencyIcon'
import ActionsMenu from '../dashboard/actionsMenu/actionsMenu.connect'
import { TruncatedTextTooltip } from '../common/truncatedTextTooltip/truncatedTextTooltip.component'
import SectionContainer from '../sectionContainer'
import { formatUTCDate, sortDescending } from 'app/utils/dateUtil'
import { mapAppData } from '../../pages/cfDashboardPage/mapper/dataMapper'
import DashboardLegend from '../dashboard/tableLegend'
import PaginatedTableFooter from '../paginatedTableFooter'
import { openApplication } from '../dashboard/openApplication/applicationUrlBuilder'
import { ConsentStats } from 'app/components/common/consentStats/consentStats.component'
import { PropTypes } from 'prop-types'

const sortByOldestFirst = (appData1, appData2) => {
  return sortDescending(appData1.created, appData2.created)
}

const TableContent = ({
  tabConfigAndData,
  numberOfRecordsToDisplay,
  dataTextWhenEmpty
}) => {
  const headData = tabConfigAndData.headerMapping

  const mappedData = tabConfigAndData.data
    .sort(sortByOldestFirst)
    .map(appData => {
      const mappedAppData = mapAppData(appData, tabConfigAndData)
      if (!tabConfigAndData.linkField) {
        mappedAppData.entityName = (
          <a
            href={openApplication(appData)}
            target='_blank'
            rel='noopener noreferrer'
          >
            <TruncatedTextTooltip text={mappedAppData.entityName} />
          </a>
        )
      } else {
        mappedAppData[tabConfigAndData.linkField] = (
          <a
            href={openApplication(appData)}
            target='_blank'
            rel='noopener noreferrer'
          >
            {mappedAppData[tabConfigAndData.linkField]}
          </a>
        )
        mappedAppData.entityName = (
          <TruncatedTextTooltip text={mappedAppData.entityName} />
        )
      }

      if (
        !tabConfigAndData.showIcon &&
        !tabConfigAndData.submissionDateTime &&
        !tabConfigAndData.moreOptions
      ) {
        return {
          ...mappedAppData,
          date: tabConfigAndData.dateFormat
            ? formatUTCDate(mappedAppData.date, tabConfigAndData.dateFormat)
            : formatUTCDate(mappedAppData.date)
        }
      }

      return {
        ...mappedAppData,
        icon: tabConfigAndData.showIcon && (
          <UrgencyIcon submissionTime={mappedAppData.submissionDateTime} />
        ),
        submissionDateTime:
          tabConfigAndData.submissionDateTime &&
          formatUTCDate(mappedAppData.submissionDateTime),
        moreOptions: tabConfigAndData.moreOptions && (
          <ActionsMenu appData={appData} />
        )
      }
    })

  return (
    <TableWrapper tabConfigAndData={tabConfigAndData}>
      {tabConfigAndData.consentStats && (
        <ConsentStats consentConfigData={tabConfigAndData.consentStats} />
      )}
      <Table
        id={'dashboard-table'}
        data={mappedData.slice(0, numberOfRecordsToDisplay)}
        head={headData}
        appearance={{
          fullWidth: true,
          highlightHeader: true,
          stripeBody: true,
          highlightFooter: true,
          headerTopBorderColor: `${anzStyles.color.deepCurrent}`,
          cellSizing: 'standard',
          columnTextAlign: ['center']
        }}
        columnNames={tabConfigAndData.columnNames}
        perPage={numberOfRecordsToDisplay}
        noDataText={dataTextWhenEmpty}
      />
    </TableWrapper>
  )
}

const mappedNumApplicationsDisplayedPerTab = (
  configAndData,
  maximumNumberOfRowsToDisplay
) => {
  return configAndData.tabs.map(element =>
    Math.min(element.data.length, maximumNumberOfRowsToDisplay)
  )
}

const ApplicationsTable = ({
  configAndData,
  dataTextWhenEmpty,
  maximumNumberOfRowsToDisplay
}) => {
  const [currTab, setCurrTab] = useState(configAndData.tabs[0])
  const [
    numApplicationsDisplayed,
    setTableNumberOfApplicationsDisplayed
  ] = useState(
    mappedNumApplicationsDisplayedPerTab(
      configAndData,
      maximumNumberOfRowsToDisplay
    )
  )

  useEffect(() => {
    setTableNumberOfApplicationsDisplayed(
      mappedNumApplicationsDisplayedPerTab(
        configAndData,
        maximumNumberOfRowsToDisplay
      )
    )
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [configAndData])

  const selectedTabNumber =
    configAndData.tabs.indexOf(currTab) === -1
      ? 0
      : configAndData.tabs.indexOf(currTab)

  const onTabChange = (configAndData, selectedTabIndex) => {
    setCurrTab(configAndData.tabs[selectedTabIndex])
  }

  const moreButtonPressed = (to, total) => {
    const newTo = Math.min(total, to + maximumNumberOfRowsToDisplay)
    const selectedTabNumber = configAndData.tabs.indexOf(currTab)
    const newState = numApplicationsDisplayed.slice()
    newState[selectedTabNumber] = newTo
    setTableNumberOfApplicationsDisplayed(newState)
  }

  const lessButtonPressed = to => {
    const potentiallyNewTo = to - maximumNumberOfRowsToDisplay
    const newTo =
      potentiallyNewTo < maximumNumberOfRowsToDisplay
        ? maximumNumberOfRowsToDisplay
        : potentiallyNewTo
    const newState = numApplicationsDisplayed.slice()
    newState[selectedTabNumber] = newTo
    setTableNumberOfApplicationsDisplayed(newState)
  }

  useEffect(() => {
    if (configAndData.tabs.indexOf(currTab) === -1) {
      setCurrTab(configAndData.tabs[0])
      setTableNumberOfApplicationsDisplayed(
        mappedNumApplicationsDisplayedPerTab(
          configAndData,
          maximumNumberOfRowsToDisplay
        )
      )
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [configAndData, configAndData.tabs, currTab])

  const numApplicationsDisplayedForTab =
    numApplicationsDisplayed[selectedTabNumber] || 0
  const totalApplicationsForTab =
    configAndData.tabs[selectedTabNumber].data.length

  return (
    <TabsWrapper>
      <SectionContainer title={configAndData.title}>
        {configAndData.tabs.length > 1 ? (
          <Tabs
            id='dashboard-tabs-headers'
            key={configAndData.tabs.map(tab => tab.title).concat([])}
            index={0}
            tabsPerView={configAndData.tabs.length}
            indexOnchangeCallback={index => onTabChange(configAndData, index)}
          >
            {configAndData.tabs.map((tabConfigAndData, index) => {
              return (
                <Tab
                  index={index}
                  key={tabConfigAndData.title}
                  id={tabConfigAndData.title}
                  title={`${tabConfigAndData.title} (${
                    tabConfigAndData.data.length
                  })`}
                >
                  <TableContent
                    tabConfigAndData={tabConfigAndData}
                    numberOfRecordsToDisplay={numApplicationsDisplayedForTab}
                    dataTextWhenEmpty={dataTextWhenEmpty}
                  />
                </Tab>
              )
            })}
          </Tabs>
        ) : (
          <TableContent
            tabConfigAndData={configAndData.tabs[0]}
            numberOfRecordsToDisplay={numApplicationsDisplayedForTab}
            dataTextWhenEmpty={dataTextWhenEmpty}
          />
        )}
        <PaginatedTableFooter
          from={totalApplicationsForTab === 0 ? 0 : 1}
          to={numApplicationsDisplayedForTab}
          total={totalApplicationsForTab}
          onMoreClick={() =>
            moreButtonPressed(
              numApplicationsDisplayedForTab,
              totalApplicationsForTab
            )
          }
          onLessClick={() => lessButtonPressed(numApplicationsDisplayedForTab)}
          maximumNumberOfRowsToDisplay={maximumNumberOfRowsToDisplay}
        />
      </SectionContainer>
      {currTab.showIcon && <DashboardLegend />}
    </TabsWrapper>
  )
}

TableContent.propTypes = {
  tabConfigAndData: PropTypes.any,
  numberOfRecordsToDisplay: PropTypes.any,
  dataTextWhenEmpty: PropTypes.any
}

ApplicationsTable.propTypes = {
  configAndData: PropTypes.any,
  maximumNumberOfRowsToDisplay: PropTypes.any,
  dataTextWhenEmpty: PropTypes.any
}

export default ApplicationsTable
