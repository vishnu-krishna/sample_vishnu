import styled, { css } from 'styled-components'

export const Table = styled.table`
  border-collapse: collapse;
  border: ${({ appearance }) =>
    appearance.border === 'all' ? `1px solid #DDD` : `0`};
  background: #fff;
  font-family: 'Myriad Pro', sans-serif;

  ${props =>
    props.appearance &&
    props.appearance.fullWidth &&
    css`
      width: 100%;
    `}
  ${props =>
    props.appearance &&
    props.appearance.rowSpacing &&
    css`
      border-spacing: ${props.appearance.rowSpacing} 0px;
      border-collapse: separate;
    `}
`

export const Tr = styled.tr`
  background: transparent;

  ${props =>
    props.appearance &&
    props.appearance.stripeBody &&
    css`
      &:nth-child(odd) {
        background-color: #f9f9f9;
      }
    `}
`

export const Td = styled.td`
  padding: 16px 16px;
  ${props =>
    props.appearance &&
    props.appearance.cellSizing &&
    props.appearance.cellSizing === 'condensed' &&
    css`
      padding: 8px 16px;
    `}
  ${props =>
    props.appearance &&
    props.appearance.cellSizing &&
    props.appearance.cellSizing === 'medium' &&
    css`
      padding: 24px 16px;
    `}
  ${props =>
    props.appearance &&
    props.appearance.cellSizing &&
    props.appearance.cellSizing === 'large' &&
    css`
      padding: 31px 16px;
    `}
  color: #494949;
  ${props =>
    props.appearance &&
    props.appearance.columnTextAlign &&
    css`
      text-align: ${props.appearance.columnTextAlign[props.colIndex]};
    `}
  ${props =>
    props.appearance &&
    props.appearance.columnDivider &&
    css`
      border-right: 1px solid #ddd;
      &:last-child {
        border-right: 0;
      }
    `}
  ${props =>
    props.appearance &&
    props.appearance.rowDivider &&
    css`
      border-bottom: 1px solid #ddd;
    `}
  ${props =>
    props.appearance.border === 'body' &&
    css`
      &:first-child {
        border-left: 1px solid #ddd;
      }
      &:last-child {
        border-right: 1px solid #ddd;
      }
      ${Tr}:first-child & {
        border-top: 1px solid #ddd;
      }
      ${Tr}:last-child & {
        border-bottom: 1px solid #ddd;
      }
    `}
`

export const FooterTd = styled.td`
  padding: 16px 16px;
  ${props =>
    props.appearance &&
    props.appearance.cellSizing &&
    props.appearance.cellSizing === 'condensed' &&
    css`
      padding: 8px 16px;
    `}
  ${props =>
    props.appearance &&
    props.appearance.cellSizing &&
    props.appearance.cellSizing === 'medium' &&
    css`
      padding: 24px 16px;
    `}
  ${props =>
    props.appearance &&
    props.appearance.cellSizing &&
    props.appearance.cellSizing === 'large' &&
    css`
      padding: 31px 16px;
    `}
  color: #494949;
  ${props =>
    props.appearance &&
    props.appearance.highlightFooter &&
    css`
      background-color: #f2f2f2;
      font-weight: bold;
    `}
`

export const Th = styled.th`
  padding: 16px 16px;
  ${props =>
    props.appearance &&
    props.appearance.cellSizing &&
    props.appearance.cellSizing === 'condensed' &&
    css`
      padding: 8px 16px;
    `}
  ${props =>
    props.appearance &&
    props.appearance.cellSizing &&
    props.appearance.cellSizing === 'medium' &&
    css`
      padding: 24px 16px;
    `}
  ${props =>
    props.appearance &&
    props.appearance.cellSizing &&
    props.appearance.cellSizing === 'large' &&
    css`
      padding: 31px 16px;
    `}
  color: #494949;
  text-align: left;
  ${props =>
    props.appearance &&
    props.appearance.highlightHeader &&
    css`
      background-color: #f2f2f2;
      font-weight: bold;
    `}
  ${props =>
    props.appearance &&
    props.appearance.columnTextAlign &&
    css`
      text-align: ${props.appearance.columnTextAlign[props.colIndex]};
    `}
  ${props =>
    props.appearance &&
    props.appearance.columnDivider &&
    css`
      border-right: 1px solid #ddd;
      &:last-child {
        border-right: 0;
      }
    `}
  ${props =>
    props.appearance &&
    props.appearance.rowDivider &&
    css`
      border-bottom: 1px solid #ddd;
    `}
  ${props =>
    props.appearance &&
    props.appearance.headerTopBorderColor &&
    !props.rowHead &&
    css`
      border-top: 4px solid ${props.appearance.headerTopBorderColor};
    `}
  ${props =>
    props.appearance.border === 'head' &&
    !props.rowHead &&
    css`
      border-top: 1px solid #ddd;
      &:first-child {
        border-left: 1px solid #ddd;
      }
      &:last-child {
        border-right: 1px solid #ddd;
      }
    `}
  ${props =>
    props.appearance.border === 'body' &&
    props.rowHead &&
    css`
      &:first-child {
        border-left: 1px solid #ddd;
      }
      &:last-child {
        border-right: 1px solid #ddd;
      }
      ${Tr}:first-child & {
        border-top: 1px solid #ddd;
      }
      ${Tr}:last-child & {
        border-bottom: 1px solid #ddd;
      }
    `}
`

export const Sort = styled.button`
  padding: 0;
  border: 0;
  background: transparent;
  font-size: 16px;
  font-weight: bold;
  font-family: 'Myriad Pro', sans-serif;
  transition: color 0.2s;
  color: #494949;
  cursor: pointer;
  position: relative;

  &:hover,
  &:focus {
    color: #007dba;
    outline: 0;
  }

  &::before,
  &::after {
    border: 4px solid transparent;
    content: '';
    display: block;
    height: 0;
    right: -16px;
    top: 50%;
    position: absolute;
    width: 0;
  }

  &::before {
    border-bottom-color: #007dba50;
    margin-top: -9px;
    transition: border-bottom-color 0.2s;

    ${props =>
      props.col === props.sortedBy &&
      props.sortOrder === 'ascending' &&
      css`
        border-bottom-color: #007dba;
      `}
  }

  &::after {
    border-top-color: #007dba50;
    margin-top: 1px;
    transition: border-top-color 0.2s;

    ${props =>
      props.col === props.sortedBy &&
      props.sortOrder === 'descending' &&
      css`
        border-top-color: #007dba;
      `}
  }
`

export const NoDataTextTd = styled.td`
  padding: 15px 0;
  text-align: center;
`
