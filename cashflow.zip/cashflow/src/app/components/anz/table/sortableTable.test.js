import React from 'react'
import { render } from '@testing-library/react'
import SortableTable from 'app/components/anz/table/sortableTable.component'

describe('Dashboard ActionMenu', () => {
  it('With no data - snapshot', () => {
    const { container, queryByTestId } = render(
      <SortableTable
        id={'table'}
        data={[]}
        head={[{ title: 'Col1', sortable: false }]}
        columnNames={['Col1']}
      />
    )
    expect(queryByTestId('table-table-body-no-data-text')).not.toBeNull()
    expect(container.innerHTML).toMatchSnapshot()
  })

  it('With data - snapshot', () => {
    const { container, queryByTestId } = render(
      <SortableTable
        id={'table'}
        data={[{ col1: 'col1 data' }]}
        head={[{ title: 'Col1', sortable: false }]}
        columnNames={['Col1']}
      />
    )

    expect(queryByTestId('table-table-body-no-data-text')).toBeNull()
    expect(queryByTestId('table-table-body_row_0_col_0')).not.toBeNull()
    expect(container.innerHTML).toMatchSnapshot()
  })
})
