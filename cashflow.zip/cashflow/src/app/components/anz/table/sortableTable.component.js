import React, { useEffect, useState } from 'react'
import { PropTypes } from 'prop-types'
import sortBy from 'lodash/sortBy'
import reverse from 'lodash/reverse'

import Pagination from '@anz/pagination'

import {
  FooterTd,
  NoDataTextTd,
  Sort,
  Table,
  Td,
  Th,
  Tr
} from 'app/components/anz/table/sortableTable.styles'

const TableHead = ({
  head,
  updateSortedBy,
  sortedBy,
  updateSortOrder,
  sortOrder,
  id,
  appearance
}) => {
  const handleSort = key => {
    if (sortedBy === key) {
      updateSortOrder(sortOrder === 'ascending' ? 'descending' : 'ascending')
    } else {
      updateSortedBy(key)
      updateSortOrder('ascending')
    }
  }

  return (
    <thead>
      <Tr>
        {head.map((col, colIndex) => (
          <Th key={colIndex} appearance={appearance} colIndex={colIndex}>
            {col.sortable && (
              <Sort
                data-test-id={`${id}_sort_${colIndex}`}
                onClick={() => handleSort(colIndex.toString())}
                sortedBy={sortedBy}
                col={colIndex.toString()}
                sortOrder={sortOrder}
              >
                {col.title}
              </Sort>
            )}
            {!col.sortable && col.title}
          </Th>
        ))}
      </Tr>
    </thead>
  )
}

TableHead.propTypes = {
  head: PropTypes.any,
  updateSortedBy: PropTypes.any,
  sortedBy: PropTypes.any,
  updateSortOrder: PropTypes.any,
  sortOrder: PropTypes.any,
  id: PropTypes.any,
  appearance: PropTypes.any
}

const TableBody = ({ data, id, appearance, columnNames, noDataText }) => {
  const td = (colIndex, rowKey, col) => (
    <Td
      key={colIndex}
      data-test-id={`${id}_row_${rowKey}_col_${colIndex}`}
      name={`${id}_${columnNames[colIndex]}_row_${rowKey}`}
      appearance={appearance}
      colIndex={colIndex}
    >
      {col.contents}
    </Td>
  )

  const th = (colIndex, rowKey, col) => (
    <Th
      rowHead
      key={colIndex}
      data-test-id={`${id}_row_${rowKey}_col_${colIndex}`}
      name={`${id}_heading_${columnNames[colIndex]}`}
      appearance={appearance}
      colIndex={colIndex}
    >
      {col.contents}
    </Th>
  )

  const tr = (rowKey, row) => (
    <Tr
      key={rowKey}
      data-test-id={`${id}_row_${rowKey}`}
      appearance={appearance}
    >
      {row.map((col, colIndex) =>
        isHeading(col) ? th(colIndex, rowKey, col) : td(colIndex, rowKey, col)
      )}
    </Tr>
  )

  const isHeading = col => col.key === 'rowHeading'

  return (
    <tbody>
      {data.length === 0 ? (
        <tr>
          <NoDataTextTd
            id={`${id}-no-data-text`}
            data-test-id={`${id}-no-data-text`}
            colSpan={columnNames.length}
          >
            {noDataText}
          </NoDataTextTd>
        </tr>
      ) : (
        data.map((row, rowKey) => tr(rowKey, row))
      )}
    </tbody>
  )
}

TableBody.propTypes = {
  data: PropTypes.any,
  id: PropTypes.any,
  columnNames: PropTypes.any,
  appearance: PropTypes.any,
  noDataText: PropTypes.any
}

/**
 * No protection is given against this function modifying the contents of `data`, however
 * the only actions applied are rebuilding new lists from its contents.
 *
 * If at some stage this function (for some reason) has to modify cells, a clone or use of
 * something like Immutable.js will be necessary for safety
 */
const sortTable = (data, tableSortedBy, tableSortOrder, perPage, page) => {
  let newData

  if (perPage && data.length > perPage) {
    newData = data.slice((page - 1) * perPage, page * perPage)
  } else {
    // NB: `data` gets mapped into a new array soon, so isn't modified
    newData = data
  }

  newData = newData.map(row => {
    return Object.keys(row).map(col => ({
      key: col,
      contents: row[col]
    }))
  })

  if (tableSortedBy) {
    newData = sortBy(newData, o => o[tableSortedBy].contents)
  }

  if (tableSortOrder === 'descending') {
    newData = reverse(newData)
  }

  return newData
}

const SortableTable = ({
  data,
  head,
  perPage,
  currentPage,
  appearance,
  sortedBy,
  sortOrder,
  id,
  columnNames,
  noDataText
}) => {
  const [page, setPage] = useState(currentPage)
  const [tableSortedBy, setTableSortedBy] = useState(sortedBy)
  const [tableSortOrder, setTableSortOrder] = useState(sortOrder)
  const [transformedData, setTransformedData] = useState(
    sortTable(data, tableSortedBy, tableSortOrder, perPage, page)
  )

  useEffect(() => {
    const sortedData = sortTable(
      data,
      tableSortedBy,
      tableSortOrder,
      perPage,
      page
    )
    setTransformedData(sortedData)
  }, [data, tableSortedBy, tableSortOrder, page, perPage])

  return (
    <Table appearance={appearance} data-test-id={`${id}-table`}>
      <TableHead
        head={head}
        updateSortedBy={setTableSortedBy}
        sortedBy={tableSortedBy}
        updateSortOrder={setTableSortOrder}
        sortOrder={tableSortOrder}
        id={`${id}-table-head`}
        appearance={appearance}
      />
      <TableBody
        data={transformedData}
        id={`${id}-table-body`}
        appearance={appearance}
        columnNames={columnNames}
        noDataText={noDataText}
      />
      {perPage && perPage < data.length ? (
        <tfoot>
          <Tr>
            <FooterTd
              colSpan={Object.keys(data[0]).length}
              appearance={appearance}
            >
              <Pagination
                updatePage={setPage}
                perPage={perPage}
                results={data}
                currentPage={page}
                id={`${id}-table-pagination`}
              />
            </FooterTd>
          </Tr>
        </tfoot>
      ) : null}
    </Table>
  )
}

SortableTable.propTypes = {
  /** The data to display within the table. */
  data: PropTypes.arrayOf(PropTypes.object).isRequired,
  /** The headings for the data, will need to match up with what is in the data to not break the table layout. */
  head: PropTypes.arrayOf(
    PropTypes.shape({
      /** Text to show in the TH tag. */
      title: PropTypes.string.isRequired,
      /** Whether the column is sortable. */
      sortable: PropTypes.bool
    })
  ).isRequired,
  /** The table styling properties for individual customisation. */
  appearance: PropTypes.shape({
    /** Whether the table should span over the full width. */
    fullWidth: PropTypes.bool,
    /** Whether the column headings should be highlighted with a darker shading. */
    highlightHeader: PropTypes.bool,
    /** Whether the body rows should be striped with a shading. */
    stripeBody: PropTypes.bool,
    /** Whether the table footer should be highlighted with a darker shading. */
    highlightFooter: PropTypes.bool,
    /** The column headings top border color to distinguish with other tables. */
    headerTopBorderColor: PropTypes.string,
    /** The column text alignment, left by default */
    columnTextAlign: PropTypes.arrayOf(
      PropTypes.oneOf(['left', 'center', 'right'])
    ),
    /** The cell text sizing, standard by default */
    cellSizing: PropTypes.oneOf([
      '',
      'standard',
      'condensed',
      'medium',
      'large'
    ]),
    /** The horizontal spacing between columns in pixels, e.g. '5px' */
    rowSpacing: PropTypes.string,
    /** Whether the columns should be divided with a vertical border. */
    columnDivider: PropTypes.bool,
    /** Whether the rows should be divided with a horizontal border. */
    rowDivider: PropTypes.bool,
    /** Whether the table should be contained by an outer border. */
    border: PropTypes.oneOf(['none', 'body', 'head', 'all'])
  }),
  /** How many rows to show per page if the table is paginated. */
  perPage: PropTypes.number,
  /** The current page to show if the table is paginated. */
  currentPage: PropTypes.number,
  /** The id attribute for the DOM. */
  id: PropTypes.string.isRequired,
  /** The column the table is presently sorted by. */
  sortedBy: PropTypes.string,
  /** Ascending or descending sort order on the table. */
  sortOrder: PropTypes.string, // TODO: should be `oneOf(['ascending', 'descending'])` and preferably using constants not string literals
  noDataText: PropTypes.string,
  columnNames: PropTypes.any
}

SortableTable.defaultProps = {
  data: [],
  appearance: {
    fullWidth: true,
    highlightHeader: true,
    stripeBody: true,
    highlightFooter: true,
    cellSizing: 'condensed',
    rowSpacing: '0px',
    columnDivider: false,
    rowDivider: false,
    border: 'all'
  },
  currentPage: 1,
  noDataText: 'No data to be displayed.'
}

export default SortableTable
