import React from 'react'
import { storiesOf } from '@storybook/react'
import { Provider } from 'react-redux'
import { ApplicationHistory } from './applicationHistory.component'
import { store } from 'store'

const app_summary = {
  creditDecision: null,
  championStatus: 'N',
  currentCcr: null,
  finalCcr: null,
  orderVersions: [
    {
      version: 1,
      createdDate: '2019-09-13T02:03:07.767Z',
      orderState: 'PENDING_NEW',
      owner: 'CSPUsr2',
      ownerName: 'Adam Treloar',
      assigneeLanId: 'CSPUsr2',
      assigneeName: 'Adam Treloar',
      assigneeDate: '2019-09-13T02:03:07.892Z',
      assigneeType: 'FR'
    },
    {
      version: 1,
      createdDate: '2019-09-15T02:03:33.267Z',
      orderState: 'NEW',
      owner: 'CSPUsr2',
      ownerName: 'Adam Treloar',
      assigneeLanId: 'CSPUsr2',
      assigneeName: 'Adam Treloar',
      assigneeDate: '2019-09-15T02:03:07.892Z',
      assigneeType: 'FR'
    }
  ]
}

const APP_ID = '123456789'
storiesOf('ApplicationHistory', module)
  .add('with history data', () => (
    <div
      style={{
        padding: '20px 30px',
        width: '960px',
        border: '1px solid black'
      }}
    >
      <Provider store={store}>
        <ApplicationHistory
          bbdID={APP_ID}
          olaID={'987654321'}
          entityName={'Mcleroy Bryan Geological Services Pty Limited'}
          appHistory={{
            appId: APP_ID,
            history: app_summary.orderVersions
          }}
          getAppHistory={() => {}}
        />
      </Provider>
    </div>
  ))

  .add('with no history data', () => (
    <div
      style={{
        padding: '20px 30px',
        width: '960px',
        border: '1px solid black'
      }}
    >
      <Provider store={store}>
        <ApplicationHistory
          bbdID={APP_ID}
          olaID={'987654321'}
          entityName={'Mcleroy Bryan Geological Services Pty Limited'}
          appHistory={{
            appId: APP_ID,
            history: []
          }}
          getAppHistory={() => {}}
        />
      </Provider>
    </div>
  ))

  .add('loading data', () => (
    <div
      style={{
        padding: '20px 30px',
        width: '960px',
        border: '1px solid black'
      }}
    >
      <Provider store={store}>
        <ApplicationHistory
          bbdID={APP_ID}
          olaID={'987654321'}
          entityName={'Mcleroy Bryan Geological Services Pty Limited'}
          appHistory={null}
          getAppHistory={() => {}}
        />
      </Provider>
    </div>
  ))

  .add('error loading data', () => (
    <div
      style={{
        padding: '20px 30px',
        width: '960px',
        border: '1px solid black'
      }}
    >
      <Provider store={store}>
        <ApplicationHistory
          bbdID={APP_ID}
          olaID={'987654321'}
          entityName={'Mcleroy Bryan Geological Services Pty Limited'}
          appHistory={{ appId: APP_ID, error: 'this is an error' }}
          getAppHistory={() => {}}
        />
      </Provider>
    </div>
  ))
