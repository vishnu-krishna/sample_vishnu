import React, { useEffect } from 'react'
import PropTypes from 'prop-types'
import {
  ErrorWrapper,
  ScrollPane,
  SpinnerWrapper
} from './ApplicationHistory.styles'
import * as uuid from 'uuid'
import { DASHBOARD_STATUS_MAPPING } from 'app/constants'
import { formatUTCDate, sortDescending } from 'app/utils/dateUtil'
import { SimpleTable } from 'app/components/common/simpleTable/simpleTable.component'
import { Spinner } from 'app/components/common/spinner/spinner.component'
import Error from '@anz/error'
import {
  ContentPane,
  FieldLabel,
  FieldValue,
  Heading
} from 'app/components/app/appModal/appModal.styles'
import { ButtonPanel } from 'app/components/ButtonPanel/buttonPanel.component'

const mapHistoryData = historyData => {
  return historyData.map(history => ({
    dateTime: history.createdDate,
    status: history.orderState,
    staff: history.assigneeName || 'System'
  }))
}

export const ApplicationHistory = ({
  id = uuid.v4(),
  bbdID,
  olaID,
  entityName,
  appHistory,
  hideAppModal,
  getAppHistory
}) => {
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => getAppHistory(bbdID), [])

  // if appHistory is null or appHistory.appId does not match in the state
  if (!appHistory || appHistory.appId !== bbdID) {
    return (
      <SpinnerWrapper>
        <Spinner />
      </SpinnerWrapper>
    )
  }

  if (appHistory.error) {
    return (
      <ErrorWrapper>
        <Error errorHeading='Unable to load Application History data.' />
      </ErrorWrapper>
    )
  }

  const history = mapHistoryData(appHistory.history)
  const sorted = Object.assign([], history).sort((history1, history2) =>
    sortDescending(history2.dateTime, history1.dateTime)
  )
  const tableConfig = {
    headers: ['Date and time', 'Application status', 'Staff member'],
    data: sorted.map(historyData => ({
      ...historyData,
      dateTime: formatUTCDate(historyData.dateTime),
      status: DASHBOARD_STATUS_MAPPING[historyData.status]
    }))
  }

  return (
    <ContentPane id={id} data-test-id='modal-application-history'>
      <Heading>History for application with</Heading>
      <div>
        <FieldLabel>BBD ID:</FieldLabel>
        <FieldValue>{bbdID}</FieldValue>
      </div>
      <div>
        <FieldLabel>OLA ID:</FieldLabel>
        <FieldValue>{olaID}</FieldValue>
      </div>
      <div>
        <FieldLabel>Entity Name:</FieldLabel>
        <FieldValue>{entityName}</FieldValue>
      </div>
      <ScrollPane>
        <SimpleTable tableConfig={tableConfig} showOutsideBorder stickyHeader />
      </ScrollPane>
      <ButtonPanel
        primaryButtonText='Close'
        primaryButtonClicked={hideAppModal}
      />
    </ContentPane>
  )
}

ApplicationHistory.propTypes = {
  id: PropTypes.string,
  bbdID: PropTypes.string.isRequired,
  olaID: PropTypes.string.isRequired,
  entityName: PropTypes.string.isRequired,
  appHistory: PropTypes.object,
  hideAppModal: PropTypes.func,
  getAppHistory: PropTypes.func
}
