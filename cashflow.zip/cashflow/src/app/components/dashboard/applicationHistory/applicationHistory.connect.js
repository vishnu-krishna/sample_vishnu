import { getAppHistoryAction } from 'app/pages/cfDashboardPage/actions'
import { connect } from 'react-redux'
import { ApplicationHistory } from './applicationHistory.component'
import { hideAppModalAction } from 'app/actions'

export const mapDispatchToProps = dispatch => {
  return {
    hideAppModal: () => dispatch(hideAppModalAction()),
    getAppHistory: appId => {
      dispatch(getAppHistoryAction(appId))
    }
  }
}
export const mapStateToProps = state => {
  return {
    appHistory: state.dashboardData.appHistory
  }
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ApplicationHistory)
