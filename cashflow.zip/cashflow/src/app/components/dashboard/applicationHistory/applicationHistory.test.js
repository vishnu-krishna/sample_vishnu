import React from 'react'
import { getByText, render } from '@testing-library/react'
import {
  mapDispatchToProps,
  mapStateToProps
} from './applicationHistory.connect'
import { ApplicationHistory } from 'app/components/dashboard/applicationHistory/applicationHistory.component'
import userEvent from '@testing-library/user-event'

const APP_SUMMARY = {
  creditDecision: null,
  championStatus: 'N',
  currentCcr: null,
  finalCcr: null,
  orderVersions: [
    {
      version: 1,
      createdDate: '2019-09-13T02:03:07.767Z',
      orderState: 'PENDING_NEW',
      owner: 'CSPUsr2',
      ownerName: 'Adam Treloar',
      assigneeLanId: 'CSPUsr2',
      assigneeName: '',
      assigneeDate: '2019-09-13T02:03:07.892Z',
      assigneeType: 'FR'
    },
    {
      version: 1,
      createdDate: '2019-09-15T02:03:33.267Z',
      orderState: 'NEW',
      owner: 'CSPUsr2',
      ownerName: 'Adam Treloar',
      assigneeLanId: 'CSPUsr2',
      assigneeName: 'Adam Treloar',
      assigneeDate: '2019-09-15T02:03:07.892Z',
      assigneeType: 'FR'
    }
  ]
}

describe('ApplicationHistory component', () => {
  it('Should display application history data (sorted by DateTime Descending order)', async () => {
    const appId = '123456789'
    const { container, asFragment } = render(
      <ApplicationHistory
        bbdID={appId}
        olaID={'987654321'}
        entityName={'Mcleroy Bryan Geological Services Pty Limited'}
        appHistory={{
          appId,
          history: APP_SUMMARY.orderVersions
        }}
        getAppHistory={() => {}}
      />
    )

    const cancelButton = getByText(container, 'Close').closest('button')
    await userEvent.click(cancelButton)

    expect(asFragment()).toMatchSnapshot()
  })

  it('Should display "No data to be displayed" message (no history)', () => {
    const appId = '123456789'
    const { asFragment } = render(
      <ApplicationHistory
        id={'withNoData'}
        bbdID={appId}
        olaID={'987654321'}
        entityName={'Mcleroy Bryan Geological Services Pty Limited'}
        appHistory={{
          appId,
          history: []
        }}
        getAppHistory={() => {}}
      />
    )
    expect(asFragment()).toMatchSnapshot()
  })

  it('Should display spinner for loading data', () => {
    const appId = '123456789'
    const { asFragment } = render(
      <ApplicationHistory
        id={'withNoData'}
        bbdID={appId}
        olaID={'987654321'}
        entityName={'Mcleroy Bryan Geological Services Pty Limited'}
        appHistory={null}
        getAppHistory={() => {}}
      />
    )
    expect(asFragment()).toMatchSnapshot()
  })

  it('Should display error message when server failed', () => {
    const appId = '12309874'
    const { asFragment } = render(
      <ApplicationHistory
        id='hasError'
        bbdID={appId}
        olaID={'987654321'}
        entityName={'Mcleroy Bryan Geological Services Pty Limited'}
        appHistory={{ appId, error: 'this is an error' }}
        getAppHistory={() => {}}
      />
    )
    expect(asFragment()).toMatchSnapshot()
  })
})

describe('ApplicationHistory.Connect', () => {
  it('Should return expected props', () => {
    const props = mapDispatchToProps({})
    expect(props.getAppHistory).toBeDefined()
  })

  it('Should return expected state', () => {
    const historyData = ['x', 'y', 'z']
    const state = mapStateToProps({
      dashboardData: { appHistory: historyData }
    })
    expect(state.appHistory).toEqual(historyData)
  })
})
