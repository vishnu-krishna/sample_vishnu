import styled from 'styled-components'

export const ScrollPane = styled.div`
  margin-top: 30px;
  overflow-x: hidden;
  overflow-y: auto;
  height: 181px;
`

export const SpinnerWrapper = styled.div`
  text-align: center;
  > div {
    left: 50%;
    margin-left: -30px;
  }
`

export const ErrorWrapper = styled.div`
  p[data-test-id='error-link'] {
    display: none;
  }
`
