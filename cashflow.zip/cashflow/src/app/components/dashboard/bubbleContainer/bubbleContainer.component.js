import React from 'react'
import styleVars from '@anz/styles-global'
import { Bubble } from 'app/components/common/bubble/bubble.component'
import { AnzCol, AnzGrid, AnzRow } from '@anz/grid'
import { StyledContainer, StyledLi } from './bubbleContainer.styles'
import { DEFAULT_COL_PROPS, DEFAULT_GRID_PROPS } from 'app/utils/gridUtils'
import { SERVER_CALL_STATES } from 'app/services/constants'
import { PropTypes } from 'prop-types'
import { isNullOrUndefined } from 'app/utils/appUtils'

const BubbleContainer = ({
  inFlightApps,
  successfulApps,
  inFlightBubbleLoading,
  successfulBubbleLoading,
  bubbleOnClick,
  activeBubble = 'Applications'
}) => {
  const setActiveBubble = bubbleName => {
    bubbleOnClick(bubbleName)
  }

  return (
    <StyledContainer data-test-id='dashboard-circles'>
      <AnzGrid {...DEFAULT_GRID_PROPS} center={'lg'}>
        <AnzRow data-type={'row'}>
          <AnzCol {...DEFAULT_COL_PROPS}>
            <BubbleGroup
              bubbles={inFlightApps.circles}
              status={inFlightBubbleLoading}
              activeBubble={activeBubble}
              setActiveBubble={setActiveBubble}
            />
            <BubbleGroup
              bubbles={successfulApps.circles}
              status={successfulBubbleLoading}
              activeBubble={activeBubble}
              setActiveBubble={setActiveBubble}
            />
          </AnzCol>
        </AnzRow>
      </AnzGrid>
    </StyledContainer>
  )
}

const BubbleGroup = ({ bubbles, status, activeBubble, setActiveBubble }) => {
  const convertToCurrencyFormat = (value, error) => {
    if (isNullOrUndefined(value) || value === 0 || error) {
      return '-'
    }
    return `$${parseFloat(value)
      .toFixed(2)
      .replace(/\.0+$/, '')
      .replace(/\d{1,3}(?=(\d{3})+(?!\d))/g, '$&,')}`
  }

  return bubbles.map((bubble, index) => {
    const isActive = activeBubble === bubble.title
    return (
      <StyledLi key={index}>
        <Bubble
          id={`${bubble.title.replace(/ /g, '-')}-${index}`}
          isLoading={status === SERVER_CALL_STATES.IN_PROGRESS}
          bubbleText={bubble.count}
          bubbleSubText={convertToCurrencyFormat(bubble.value)}
          label={bubble.title}
          // TODO: here is where we kick off the redux
          onBubbleClick={() => setActiveBubble(bubble.title)}
          labelColor={
            status === SERVER_CALL_STATES.ERROR
              ? styleVars.color.system.error
              : styleVars.color.darkGrey
          }
          bgColor={
            isActive ? styleVars.color.oceanBlue : styleVars.color.grayscale90
          }
          outlineColor={
            isActive
              ? styleVars.color.darkOceanBlue
              : styleVars.color.grayscale60
          }
          bubbleTextColor={
            isActive ? styleVars.color.white : styleVars.color.black60
          }
          labelSubText={bubble.subtitle ? bubble.subtitle : ''}
          spinnerColor={
            isActive ? styleVars.color.white : styleVars.color.oceanBlue
          }
        />
      </StyledLi>
    )
  })
}

BubbleContainer.propTypes = {
  inFlightApps: PropTypes.any,
  successfulApps: PropTypes.any,
  inFlightBubbleLoading: PropTypes.any,
  successfulBubbleLoading: PropTypes.any,
  bubbleOnClick: PropTypes.any,
  activeBubble: PropTypes.any
}

export default BubbleContainer
