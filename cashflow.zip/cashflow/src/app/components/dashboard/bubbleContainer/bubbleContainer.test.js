import React from 'react'
import { render } from '@testing-library/react'
import BubbleContainer from './bubbleContainer.component'
import { SERVER_CALL_STATES } from 'app/services/constants'
import userEvent from '@testing-library/user-event'

describe('BubbleContainer snapshot test', () => {
  const initialState = {
    inflightApps: {
      circles: [
        {
          title: 'Applications'
        },
        {
          title: 'Sent for Assessment'
        },
        {
          title: 'Documents Out'
        },
        {
          title: 'Drawdown Requested'
        }
      ]
    },
    successfulApps: {
      circles: [
        {
          title: 'Successful'
        }
      ]
    },
    inFlightBubbleLoading: SERVER_CALL_STATES.IN_PROGRESS,
    successfulBubbleLoading: SERVER_CALL_STATES.IN_PROGRESS
  }

  const serverCallFailedState = {
    inflightApps: {
      circles: [
        {
          title: 'Applications'
        },
        {
          title: 'Sent for Assessment'
        },
        {
          title: 'Documents Out'
        },
        {
          title: 'Drawdown Requested'
        }
      ]
    },
    successfulApps: {
      circles: [
        {
          title: 'Successful'
        }
      ]
    },
    inFlightBubbleLoading: SERVER_CALL_STATES.ERROR,
    successfulBubbleLoading: SERVER_CALL_STATES.ERROR
  }

  const bubbleHasSubtitle = {
    inflightApps: {
      circles: [
        {
          title: 'Applications',
          subtitle: 'Test Subtitle'
        },
        {
          title: 'Sent for Assessment',
          subtitle: 'Test Subtitle'
        },
        {
          title: 'Documents Out',
          subtitle: 'Test Subtitle'
        },
        {
          title: 'Drawdown Requested',
          subtitle: 'Test Subtitle'
        }
      ]
    },
    successfulApps: {
      circles: [
        {
          title: 'Successful',
          subtitle: 'Test Subtitle'
        }
      ]
    },
    inFlightBubbleLoading: SERVER_CALL_STATES.ERROR,
    successfulBubbleLoading: SERVER_CALL_STATES.ERROR
  }

  const bubbleHasValue = {
    inflightApps: {
      circles: [
        {
          title: 'Applications',
          value: 123100.0
        },
        {
          title: 'Sent for Assessment',
          value: 308524675.0
        },
        {
          title: 'Documents Out',
          value: 123456
        },
        {
          title: 'Drawdown Requested',
          value: 0
        }
      ]
    },
    successfulApps: {
      circles: [
        {
          title: 'Successful',
          value: 12458738
        }
      ]
    },
    inFlightBubbleLoading: SERVER_CALL_STATES.ERROR,
    successfulBubbleLoading: SERVER_CALL_STATES.ERROR
  }

  it('renders correctly', () => {
    const myFunction = jest.fn()
    const bubbleContainer = render(
      <BubbleContainer
        inFlightApps={initialState.inflightApps}
        successfulApps={initialState.successfulApps}
        inFlightBubbleLoading={initialState.inFlightBubbleLoading}
        successfulBubbleLoading={initialState.successfulBubbleLoading}
        bubbleOnClick={myFunction}
        activeBubble='Applications'
      />
    )
    expect(bubbleContainer).toMatchSnapshot()
  })

  it('should trigger bubbleOnClick when all the five bubble is clicked which changes the activeBubble', () => {
    const myFunction = jest.fn()
    const { getByTestId } = render(
      <BubbleContainer
        inFlightApps={initialState.inflightApps}
        successfulApps={initialState.successfulApps}
        inFlightBubbleLoading={initialState.inFlightBubbleLoading}
        successfulBubbleLoading={initialState.successfulBubbleLoading}
        bubbleOnClick={myFunction}
        activeBubble='Applications'
      />
    )
    const rendered1stBubble = getByTestId('Applications-0')
    userEvent.click(rendered1stBubble)
    expect(myFunction).toHaveBeenCalledTimes(1)

    const rendered2ndBubble = getByTestId('Sent-for-Assessment-1')
    userEvent.click(rendered2ndBubble)
    expect(myFunction).toHaveBeenCalledTimes(2)

    // const rendered3thBubble = getByTestId('documents-Out-2')
    // fireEvent.click(rendered3thBubble)
    // expect(myFunction).toHaveBeenCalledTimes(3)

    const rendered4thBubble = getByTestId('Drawdown-Requested-3')
    userEvent.click(rendered4thBubble)
    expect(myFunction).toHaveBeenCalledTimes(3)

    const rendered5thBubble = getByTestId('Successful-0')
    userEvent.click(rendered5thBubble)
    expect(myFunction).toHaveBeenCalledTimes(4)
  })

  it('renders correctly when an error is present for server call', () => {
    const myFunction = jest.fn()
    const bubbleContainer = render(
      <BubbleContainer
        inFlightApps={serverCallFailedState.inflightApps}
        successfulApps={serverCallFailedState.successfulApps}
        inFlightBubbleLoading={serverCallFailedState.inFlightBubbleLoading}
        successfulBubbleLoading={serverCallFailedState.successfulBubbleLoading}
        bubbleOnClick={myFunction}
        activeBubble='Applications'
      />
    )
    expect(bubbleContainer).toMatchSnapshot()
  })

  it('renders correctly when bubble has a subtitle', () => {
    const myFunction = jest.fn()
    const bubbleContainer = render(
      <BubbleContainer
        inFlightApps={bubbleHasSubtitle.inflightApps}
        successfulApps={bubbleHasSubtitle.successfulApps}
        inFlightBubbleLoading={bubbleHasSubtitle.inFlightBubbleLoading}
        successfulBubbleLoading={bubbleHasSubtitle.successfulBubbleLoading}
        bubbleOnClick={myFunction}
        activeBubble='Applications'
      />
    )
    expect(bubbleContainer).toMatchSnapshot()
  })

  it('renders correctly when bubble has a number value that should be converted into the desired string format', () => {
    const myFunction = jest.fn()
    const bubbleContainer = render(
      <BubbleContainer
        inFlightApps={bubbleHasValue.inflightApps}
        successfulApps={bubbleHasValue.successfulApps}
        inFlightBubbleLoading={bubbleHasValue.inFlightBubbleLoading}
        successfulBubbleLoading={bubbleHasValue.successfulBubbleLoading}
        bubbleOnClick={myFunction}
        activeBubble='Applications'
      />
    )
    expect(bubbleContainer).toMatchSnapshot()
  })
  it('renders with correct currency format', async () => {
    const bubbleValues = {
      inflightApps: {
        circles: [
          {
            title: 'Applications',
            count: 30,
            value: 40000
          },
          {
            title: 'Sent for Assessment',
            count: 8,
            value: 40000.98
          },
          {
            title: 'Documents Out',
            count: 3,
            value: 90000.0
          },
          {
            title: 'Drawdown Requested',
            count: 3,
            value: 9879887.9
          }
        ]
      },
      successfulApps: {
        circles: [
          {
            title: 'Successful',
            count: 67,
            value: 7888789.98876
          }
        ]
      },
      inFlightBubbleLoading: SERVER_CALL_STATES.SUCCESS,
      successfulBubbleLoading: SERVER_CALL_STATES.SUCCESS
    }
    const { findByText } = render(
      <BubbleContainer
        inFlightApps={bubbleValues.inflightApps}
        successfulApps={bubbleValues.successfulApps}
        inFlightBubbleLoading={bubbleValues.inFlightBubbleLoading}
        successfulBubbleLoading={bubbleValues.successfulBubbleLoading}
        bubbleOnClick={jest.fn()}
        activeBubble='Applications'
      />
    )
    const applicationsValue = await findByText('$40,000')
    const inAssessmentValue = await findByText('$40,000.98')
    const inDocumentsValue = await findByText('$90,000')
    const inDrawdownValue = await findByText('$9,879,887.90')
    const successfulValue = await findByText('$7,888,789.99')
    expect(applicationsValue).toBeTruthy()
    expect(inAssessmentValue).toBeTruthy()
    expect(inDocumentsValue).toBeTruthy()
    expect(inDrawdownValue).toBeTruthy()
    expect(successfulValue).toBeTruthy()
  })
})
