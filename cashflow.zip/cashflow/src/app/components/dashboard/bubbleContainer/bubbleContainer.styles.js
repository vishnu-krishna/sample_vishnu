import styled from 'styled-components'

export const StyledLi = styled.li`
  display: inline-block;
  padding-left: 24px;
  padding-right: 24px;
  vertical-align: top;
  width: 18%;
`

export const StyledContainer = styled.div`
  margin: 24px;
  display: block;
  text-align: center;
`
