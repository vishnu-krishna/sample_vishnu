import styled from 'styled-components'

export const ActionMenuIconWrapper = styled.span`
  display: inline-block;
  min-width: 30px;
  padding-top: 6px;
  text-align: center;
  svg {
    -webkit-transform: rotate(90deg);
    -moz-transform: rotate(90deg);
    -o-transform: rotate(90deg);
    -ms-transform: rotate(90deg);
    transform: rotate(90deg);
  }
`

export const ActionMenuItemsWrapper = styled.span`
  display: inline-block;
  position: absolute;
`
