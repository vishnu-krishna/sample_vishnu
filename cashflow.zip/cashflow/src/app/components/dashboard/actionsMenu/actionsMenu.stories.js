import React from 'react'
import { storiesOf } from '@storybook/react'
import { ActionsMenu } from './actionsMenu.component'

storiesOf('ActionMenu', module).add('Show/hide menu', () => {
  return (
    <div style={{ paddingLeft: '205px' }}>
      <ActionsMenu
        appData={{
          owner: true,
          status: 'PENDING_CUSTOMER_LINK',
          anzUser: 'myself'
        }}
      />
      <br />
      <ActionsMenu
        appData={{ owner: true, status: 'NEW', anzUser: 'myself' }}
      />
      <br />
      <br />
      <ActionsMenu
        appData={{
          owner: true,
          status: 'AWAITING_DRAWDOWN_REQUEST',
          anzUser: 'myself'
        }}
      />
      <br />
      <br />
      <ActionsMenu
        appData={{ owner: true, status: 'AWAITING_CASE_ID', anzUser: 'myself' }}
      />
      <br />
      <br />
      <ActionsMenu
        appData={{
          owner: false,
          status: 'AWAITING_CASE_ID',
          anzUser: 'myself'
        }}
      />
      <br />
      <br />
      <ActionsMenu
        appData={{
          owner: false,
          status: 'AWAITING_DRAWDOWN_REQUEST',
          anzUser: 'myself'
        }}
      />
    </div>
  )
})
