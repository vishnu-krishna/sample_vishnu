import { connect } from 'react-redux'
import { ActionsMenu } from './actionsMenu.component'

export default connect()(ActionsMenu)
