import React from 'react'
import {
  CONFIRM_FINALISATION,
  OPEN_APPLICATION,
  RELINK_CUSTOMER,
  SELF_ASSIGN_APPLICATION,
  SUBMIT_DRAWDOWN_REQUEST,
  VIEW_APPLICATION_HISTORY,
  WITHDRAW_APPLICATION
} from './actionsMenu.const'
import ApplicationHistory from 'app/components/dashboard/applicationHistory/applicationHistory.connect'
import { WithdrawApplication } from 'app/components/dashboard/withdrawApplication/withdrawApplication.component'
import {
  openApplication,
  submitDrawdownRequest
} from 'app/components/dashboard/openApplication/applicationUrlBuilder'
import { SelfAssignApplication } from 'app/components/dashboard/selfAssignApplication/selfAssignApplication.component'
import { OrderState } from 'app/constants'
import { showAppModalAction } from 'app/actions'
import { RelinkCustomer } from 'app/components/dashboard/relinkCustomer/relinkCustomer.component'
import ConfirmFinalisation from '../confirmFinalisation/confirmFinalisation.component'

export const ACTION_MENU_OPTIONS = [
  {
    text: WITHDRAW_APPLICATION,
    actionType: 'onClick',
    states: [
      OrderState.PENDING_NEW,
      OrderState.NEW,
      OrderState.AWAITING_REWORK,
      OrderState.AWAITING_FRONTLINE_ACTION,
      OrderState.ASSESSMENT_APPROVED_IN_PRINCIPLE,
      OrderState.PENDING_SUBMITTED,
      OrderState.SUBMITTED,
      OrderState.AUTO_REFERRED,
      OrderState.AUTO_APPROVED,
      OrderState.AWAITING_DRAWDOWN_REQUEST,
      OrderState.PENDING_FULFILMENT,
      OrderState.DRAWDOWN_REQUEST_PENDING_SUBMITTED,
      OrderState.DRAWDOWN_REQUEST_SUBMITTED,
      OrderState.PENDING_DRAWDOWN
    ],
    action: (appData, dispatch) =>
      dispatch(
        showAppModalAction({
          content: <WithdrawApplication appData={appData} />
        })
      )
  },
  {
    text: SUBMIT_DRAWDOWN_REQUEST,
    actionType: 'onClick',
    states: [OrderState.AWAITING_DRAWDOWN_REQUEST],
    action: appData => window.location.assign(submitDrawdownRequest(appData))
  },
  {
    text: RELINK_CUSTOMER,
    actionType: 'onClick',
    states: [
      OrderState.PENDING_NEW,
      OrderState.NEW,
      OrderState.AWAITING_CASE_ID,
      OrderState.AWAITING_REWORK
    ],
    action: (appData, dispatch) =>
      dispatch(
        showAppModalAction({
          content: (
            <RelinkCustomer
              bbdID={appData.applicationId}
              olaID={appData.externalSystemApplicationId}
              entityName={appData.entityName}
              entityId={appData.entityId}
            />
          )
        })
      )
  },
  {
    text: OPEN_APPLICATION,
    actionType: 'onClick',
    states: [
      OrderState.PENDING_CUSTOMER_LINK,
      OrderState.PENDING_NEW,
      OrderState.NEW,
      OrderState.AWAITING_CASE_ID,
      OrderState.ASSESSMENT_APPROVED_IN_PRINCIPLE,
      OrderState.PENDING_REWORK,
      OrderState.AWAITING_FRONTLINE_ACTION,
      OrderState.AWAITING_REWORK,
      OrderState.PENDING_SUBMITTED,
      OrderState.SUBMITTED,
      OrderState.AUTO_REFERRED,
      OrderState.AUTO_APPROVED,
      OrderState.PENDING_ASSESSMENT,
      OrderState.ASSESSMENT_APPROVED,
      OrderState.AWAITING_ASSESSMENT_APPLICATION_REWORK,
      OrderState.PENDING_FULFILMENT,
      OrderState.AWAITING_DRAWDOWN_REQUEST,
      OrderState.DRAWDOWN_REQUEST_PENDING_SUBMITTED,
      OrderState.DRAWDOWN_REQUEST_SUBMITTED,
      OrderState.PENDING_DRAWDOWN,
      OrderState.DRAWDOWN_COMPLETED,
      OrderState.PENDING_FINALISATION,
      OrderState.FINALISED,
      OrderState.WITHDRAWN,
      OrderState.PENDING_WITHDRAWN,
      OrderState.AUTO_DECLINED,
      OrderState.ASSESSMENT_DECLINED
    ],
    action: appData => window.open(openApplication(appData), '_blank')
  },
  {
    text: VIEW_APPLICATION_HISTORY,
    actionType: 'onClick',
    states: [
      OrderState.PENDING_CUSTOMER_LINK,
      OrderState.PENDING_NEW,
      OrderState.NEW,
      OrderState.AWAITING_CASE_ID,
      OrderState.ASSESSMENT_APPROVED_IN_PRINCIPLE,
      OrderState.PENDING_REWORK,
      OrderState.AWAITING_FRONTLINE_ACTION,
      OrderState.AWAITING_REWORK,
      OrderState.PENDING_SUBMITTED,
      OrderState.SUBMITTED,
      OrderState.AUTO_REFERRED,
      OrderState.AUTO_APPROVED,
      OrderState.PENDING_ASSESSMENT,
      OrderState.ASSESSMENT_APPROVED,
      OrderState.AWAITING_ASSESSMENT_APPLICATION_REWORK,
      OrderState.PENDING_FULFILMENT,
      OrderState.AWAITING_DRAWDOWN_REQUEST,
      OrderState.DRAWDOWN_REQUEST_PENDING_SUBMITTED,
      OrderState.DRAWDOWN_REQUEST_SUBMITTED,
      OrderState.PENDING_DRAWDOWN,
      OrderState.DRAWDOWN_COMPLETED,
      OrderState.PENDING_FINALISATION,
      OrderState.FINALISED,
      OrderState.WITHDRAWN,
      OrderState.PENDING_WITHDRAWN,
      OrderState.AUTO_DECLINED,
      OrderState.ASSESSMENT_DECLINED
    ],
    action: (appData, dispatch) =>
      dispatch(
        showAppModalAction({
          content: (
            <ApplicationHistory
              bbdID={appData.applicationId}
              olaID={appData.externalSystemApplicationId}
              entityName={appData.entityName}
            />
          )
        })
      )
  },
  {
    text: SELF_ASSIGN_APPLICATION,
    actionType: 'onClick',
    states: [
      OrderState.PENDING_CUSTOMER_LINK,
      OrderState.PENDING_NEW,
      OrderState.NEW,
      OrderState.AWAITING_CASE_ID,
      OrderState.ASSESSMENT_APPROVED_IN_PRINCIPLE,
      OrderState.PENDING_REWORK,
      OrderState.AWAITING_FRONTLINE_ACTION,
      OrderState.AWAITING_REWORK,
      OrderState.PENDING_SUBMITTED,
      OrderState.SUBMITTED,
      OrderState.AUTO_REFERRED,
      OrderState.AUTO_APPROVED,
      OrderState.PENDING_ASSESSMENT,
      OrderState.ASSESSMENT_APPROVED,
      OrderState.AWAITING_ASSESSMENT_APPLICATION_REWORK,
      OrderState.PENDING_FULFILMENT,
      OrderState.AWAITING_DRAWDOWN_REQUEST,
      OrderState.DRAWDOWN_REQUEST_PENDING_SUBMITTED,
      OrderState.DRAWDOWN_REQUEST_SUBMITTED,
      OrderState.PENDING_DRAWDOWN,
      OrderState.DRAWDOWN_COMPLETED,
      OrderState.PENDING_FINALISATION,
      OrderState.FINALISED,
      OrderState.WITHDRAWN,
      OrderState.PENDING_WITHDRAWN,
      OrderState.AUTO_DECLINED,
      OrderState.ASSESSMENT_DECLINED
    ],
    showIfOwner: false,
    action: (appData, dispatch) =>
      dispatch(
        showAppModalAction({
          content: (
            <SelfAssignApplication
              bbdID={appData.applicationId}
              status={appData.status}
              olaID={appData.externalSystemApplicationId}
              entityName={appData.entityName}
              anzUser={appData.anzUser}
            />
          )
        })
      )
  },
  {
    text: CONFIRM_FINALISATION,
    actionType: 'onClick',
    states: [OrderState.PENDING_FINALISATION],
    action: (appData, dispatch) =>
      dispatch(
        showAppModalAction({
          content: <ConfirmFinalisation appId={appData.applicationId} />
        })
      )
  }
]
