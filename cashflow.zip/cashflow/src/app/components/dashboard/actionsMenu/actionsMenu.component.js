import React from 'react'
import PropTypes from 'prop-types'
import DropdownMenu from '@anz/dropdown-menu'
import { ACTION_MENU_OPTIONS } from './applicationOptions'
import {
  ActionMenuIconWrapper,
  ActionMenuItemsWrapper
} from './actionsMenu.styles'
import MoreIcon from '@anz/icon/dist/filled/arrows-and-symbols/more'
import * as ReactDOM from 'react-dom'
import * as uuid from 'uuid'
import {
  RELINK_CUSTOMER,
  SELF_ASSIGN_APPLICATION,
  SUBMIT_DRAWDOWN_REQUEST,
  WITHDRAW_APPLICATION
} from './actionsMenu.const'

export const isActionVisible = (option, appData) => {
  // state not match, return false
  if (option.states.indexOf(appData.status) === -1) {
    return false
  }

  // return true/false based on whether current user is the owner of the application
  switch (option.text) {
    case WITHDRAW_APPLICATION:
    case SUBMIT_DRAWDOWN_REQUEST:
    case RELINK_CUSTOMER:
      // current user has to be the owner to display
      return appData.owner
    case SELF_ASSIGN_APPLICATION:
      // current owner should not be the owner to display
      return !appData.owner
    default:
      // we don't care, whether the current user is the owner or not to display
      return true
  }
}

export class ActionsMenu extends React.Component {
  constructor (props) {
    super(props)
    this.domRef = null
    this.state = { showMenu: false }

    this.onWindowClicked = this.onWindowClicked.bind(this)
  }

  onWindowClicked (e) {
    const target = e.target
    const actionMenuDom = this.domRef
    if (
      !actionMenuDom ||
      actionMenuDom === target ||
      actionMenuDom.contains(target)
    ) {
      return
    }
    this.setState({ showMenu: false })
  }

  createMenuItems (appData, dispatch) {
    return ACTION_MENU_OPTIONS.map(option => Object.assign({}, option))
      .filter(option => isActionVisible(option, appData))
      .map(item => {
        item.onClick = () => {
          this.setState({ showMenu: false })
          item.action(appData, dispatch)
        }
        return item
      })
  }

  createPopupMenu (id, showMenu, appData, dispatch) {
    const items = this.createMenuItems(appData, dispatch)

    if (!showMenu || !this.domRef || items.length === 0) {
      // remove window handler, if we are not showing the popup menu
      window.removeEventListener('click', this.onWindowClicked)
      return null
    }
    window.addEventListener('click', this.onWindowClicked)

    const menuItemPos = this.domRef.getBoundingClientRect()
    return ReactDOM.createPortal(
      <ActionMenuItemsWrapper
        style={{
          left: menuItemPos.left + menuItemPos.width / 2,
          top: menuItemPos.bottom + window.scrollY
        }}
      >
        <DropdownMenu id={id} positionX={'right'} items={items} active />
      </ActionMenuItemsWrapper>,
      document.body
    )
  }

  render () {
    const { showMenu } = this.state
    /* eslint-disable react/prop-types */
    const { id = uuid.v4(), appData, dispatch } = this.props
    /* eslint-disable react/prop-types */
    return (
      <>
        <ActionMenuIconWrapper
          ref={ref => (this.domRef = ref)}
          id={`${id}-wrapper`}
          onClick={() => this.setState({ showMenu: !showMenu })}
        >
          <MoreIcon />
        </ActionMenuIconWrapper>
        {this.createPopupMenu(id, showMenu, appData, dispatch)}
      </>
    )
  }
}

ActionsMenu.propTypes = {
  id: PropTypes.string,
  appData: PropTypes.object.isRequired
}
