import React from 'react'
import {
  getByText,
  queryByAttribute,
  queryByText,
  render
} from '@testing-library/react'
import { ActionsMenu, isActionVisible } from './actionsMenu.component'
import { ACTION_MENU_OPTIONS } from './applicationOptions'
import userEvent from '@testing-library/user-event'

const getById = queryByAttribute.bind(null, 'id')

describe('Dashboard ActionMenu', () => {
  it('Basic snapshot', async () => {
    const testId = 'test-action-menu'
    const { asFragment } = render(<ActionsMenu id={testId} appData={{}} />)
    expect(asFragment()).toMatchSnapshot()
  })

  it('should show action menu as popup', async () => {
    const testId = 'test-action-menu'
    const { container } = render(
      <ActionsMenu id={testId} appData={{ owner: false, status: 'NEW' }} />
    )

    const target = await getById(container, `${testId}-wrapper`)
    await userEvent.click(target)
    expect(getByText(document.body, 'Self-assign application')).not.toBe(null)
    expect(document.body).toMatchSnapshot()
  })

  it('should close action menu - when the icon is clicked', async () => {
    const testId = 'test-action-menu'
    const { container } = render(
      <ActionsMenu id={testId} appData={{ owner: false, status: 'NEW' }} />
    )

    const target = await getById(container, `${testId}-wrapper`)

    await userEvent.click(target)
    expect(getByText(document.body, 'Self-assign application')).not.toBe(null)

    await userEvent.click(target)
    expect(
      queryByText(target, 'Self-assign application')
    ).not.toBeInTheDocument()

    expect(document.body).toMatchSnapshot()
  })

  it('should close action menu - when the menu item is clicked', async () => {
    const testId = 'test-action-menu'
    const { container } = render(
      <ActionsMenu
        id={testId}
        appData={{
          owner: false,
          status: 'NEW',
          applicationId: '2',
          externalSystemApplicationId: '2',
          entityName: 'entity'
        }}
        dispatch={() => {}}
      />
    )

    const target = await getById(container, `${testId}-wrapper`)

    await userEvent.click(target)
    const menuItem = getByText(document.body, 'Self-assign application')
    expect(menuItem).not.toBe(null)

    await userEvent.click(menuItem)
    expect(
      queryByText(document.body, 'Self-assign application')
    ).not.toBeInTheDocument()

    expect(document.body).toMatchSnapshot()
  })

  it('should close action menu when body is clicked', async () => {
    const testId = 'test-action-menu'
    const { container } = render(
      <ActionsMenu id={testId} appData={{ owner: false, status: 'NEW' }} />
    )

    const target = await getById(container, `${testId}-wrapper`)

    await userEvent.click(target)
    expect(getByText(document.body, 'Self-assign application')).not.toBe(null)

    await userEvent.click(document.body)
    expect(
      queryByText(document.body, 'Self-assign application')
    ).not.toBeInTheDocument()

    expect(document.body).toMatchSnapshot()
  })

  it('should check isActionVisible option return true /false', () => {
    let appData = {
      owner: true,
      status: 'PENDING_NEW'
    }
    expect(isActionVisible(ACTION_MENU_OPTIONS[0], appData)).toBe(true)
    expect(isActionVisible(ACTION_MENU_OPTIONS[1], appData)).toBe(false)
    expect(isActionVisible(ACTION_MENU_OPTIONS[2], appData)).toBe(true)
    expect(isActionVisible(ACTION_MENU_OPTIONS[3], appData)).toBe(true)
    expect(isActionVisible(ACTION_MENU_OPTIONS[4], appData)).toBe(true)
    expect(isActionVisible(ACTION_MENU_OPTIONS[5], appData)).toBe(false)
  })
})
