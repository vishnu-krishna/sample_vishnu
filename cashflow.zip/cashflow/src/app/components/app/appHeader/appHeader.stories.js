import React from 'react'
import { storiesOf } from '@storybook/react'
import { AppHeader } from 'app/components/app/appHeader/appHeader.component'

storiesOf('App Header', module)
  .add('With 0 buttons', () => {
    return <AppHeader currentLocation='' />
  })
  .add('With 1 button', () => {
    return <AppHeader onDashboardClick={() => {}} currentLocation='' />
  })
  .add('With multiple buttons', () => {
    return (
      <AppHeader
        onDocumentsClick={() => {}}
        onSearchClick={() => {}}
        onCommentsClick={() => {}}
        onDashboardClick={() => {}}
        currentLocation=''
      />
    )
  })
  .add('Loading State with no buttons', () => {
    return <AppHeader showSpinner currentLocation='' />
  })
  .add('Loading State with buttons', () => {
    return (
      <AppHeader
        showSpinner
        onDocumentsClick={() => {}}
        onSearchClick={() => {}}
        onCommentsClick={() => {}}
        onDashboardClick={() => {}}
        currentLocation=''
      />
    )
  })
