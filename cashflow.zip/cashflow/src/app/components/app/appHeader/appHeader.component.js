import React, { useEffect, useState } from 'react'
import PropTypes from 'prop-types'
import Header from '@anz/header'

import { Spinner } from 'app/components/common/spinner/spinner.component'
import {
  ButtonContainer,
  ProgressBar,
  ProgressSpinner
} from 'app/components/app/appHeader/appHeader.styles'
import {
  AppHeaderButton,
  AppHeaderIcons,
  AppHeaderLabel
} from 'app/components/app/appHeader/appHeaderButton/appHeaderButton.component'
import { PAGES } from 'app/pages/constants'

const BgProgressBar = () => {
  const [progress, setProgress] = useState(0)

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress(prevProgress => {
        if (prevProgress >= 100) {
          return 0
        }
        return prevProgress + 1
      })
    }, 20)

    return () => clearInterval(timer)
  }, [])

  return (
    <>
      <ProgressSpinner data-test-id='app-bg-spinner'>
        <Spinner
          strokeWidth={5}
          logoSize={0}
          spinnerSize={30}
          spinnerTop={'0px'}
          spinnerLeft={'0px'}
        />
      </ProgressSpinner>
      <ProgressBar data-test-id='app-bg-progress-bar' progress={progress} />
    </>
  )
}

export const AppHeader = ({
  showSpinner,
  applicationId,
  onDashboardClick,
  onSearchClick,
  onCommentsClick,
  onDocumentsClick,
  currentLocation
}) => {
  const isCurrentLocationDashboard =
    currentLocation.includes(PAGES.dashboard.path) || currentLocation === '/'

  return (
    <Header maxWidth='auto'>
      {showSpinner && <BgProgressBar />}
      <ButtonContainer>
        {onDashboardClick && (
          <AppHeaderButton
            imageType={AppHeaderIcons.Dashboard}
            label={AppHeaderLabel.Dashboard}
            onClick={onDashboardClick}
          />
        )}
        {onSearchClick && (
          <AppHeaderButton
            imageType={AppHeaderIcons.Search}
            label={AppHeaderLabel.Search}
            onClick={onSearchClick}
          />
        )}
        {!isCurrentLocationDashboard && applicationId && onCommentsClick && (
          <AppHeaderButton
            imageType={AppHeaderIcons.Comments}
            label={AppHeaderLabel.Comments}
            onClick={onCommentsClick}
          />
        )}
        {!isCurrentLocationDashboard && applicationId && onDocumentsClick && (
          <AppHeaderButton
            imageType={AppHeaderIcons.Documents}
            label={AppHeaderLabel.Documents}
            onClick={onDocumentsClick}
          />
        )}
      </ButtonContainer>
    </Header>
  )
}

AppHeader.propTypes = {
  showSpinner: PropTypes.bool,
  onDashboardClick: PropTypes.func,
  onSearchClick: PropTypes.func,
  onCommentsClick: PropTypes.func,
  onDocumentsClick: PropTypes.func,
  currentLocation: PropTypes.string,
  applicationId: PropTypes.any
}
