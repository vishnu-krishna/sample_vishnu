import styled from 'styled-components'
import styleVars from '@anz/styles-global'

export const ProgressSpinner = styled.div`
  left: 50%;
  top: 14px;
  margin-left: -15px;
  position: absolute;
  z-index: 999;
`
export const ProgressBar = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  height: 3px;
  z-index: 999;
  border-bottom: 1px solid #11b1ff;
  background-color: ${styleVars.color.oceanBlue};
  width: ${({ progress }) => progress}%;
`

export const ButtonContainer = styled.div`
  display: flex;
  justify-content: flex-end;
  flex-grow: 1;
  padding-right: 20px;
`
