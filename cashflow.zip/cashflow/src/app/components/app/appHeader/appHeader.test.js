import React from 'react'
import { render } from '@testing-library/react'
import { AppHeader } from 'app/components/app/appHeader/appHeader.component'
import { PAGES } from 'app/pages/constants'
import userEvent from '@testing-library/user-event'
import { AppHeaderLabel } from './appHeaderButton/appHeaderButton.component'

describe('AppHeader', () => {
  test('with no Bg Spinner', () => {
    const { asFragment, queryByTestId } = render(
      <AppHeader showSpinner={false} currentLocation={PAGES.dashboard.path} />
    )
    expect(asFragment()).toMatchSnapshot()

    expect(queryByTestId('app-bg-spinner')).toBeNull()
    expect(queryByTestId('app-bg-progress-bar')).toBeNull()
  })

  test('with Bg Spinner', () => {
    const { asFragment, queryByTestId } = render(
      <AppHeader showSpinner={true} currentLocation={PAGES.dashboard.path} />
    )
    expect(asFragment()).toMatchSnapshot()

    expect(queryByTestId('app-bg-spinner')).toBeDefined()
    expect(queryByTestId('app-bg-progress-bar')).toBeDefined()
  })

  describe('Buttons', () => {
    const mockApplicationId = '1000000001'
    describe('With defined onclick functions', () => {
      const dashboardClick = jest.fn()
      const commentClick = jest.fn()
      const documentClick = jest.fn()
      const searchClick = jest.fn()

      describe('home page', () => {
        let element
        beforeEach(() => {
          element = render(
            <AppHeader
              applicationId={mockApplicationId}
              onDashboardClick={dashboardClick}
              onDocumentsClick={documentClick}
              onCommentsClick={commentClick}
              onSearchClick={searchClick}
              currentLocation='/'
            />
          )
        })
        it('should render search button', () => {
          const searchButton = element.getByText(AppHeaderLabel.Search)
          expect(searchButton).toBeInTheDocument()
          userEvent.click(searchButton)
          expect(searchClick).toBeCalled()
        })
        it('should render dashboard button', () => {
          const dashboardButton = element.getByText(AppHeaderLabel.Dashboard)
          expect(dashboardButton).toBeInTheDocument()
          userEvent.click(dashboardButton)
          expect(dashboardClick).toBeCalled()
        })
        it('should not render comment button', () => {
          const commentsButton = element.queryByText(AppHeaderLabel.Comments)
          expect(commentsButton).not.toBeInTheDocument()
        })
        it('should not render document button', () => {
          const documentButton = element.queryByText(AppHeaderLabel.Documents)
          expect(documentButton).not.toBeInTheDocument()
        })
      })

      describe('dashboard page', () => {
        let element
        beforeEach(() => {
          element = render(
            <AppHeader
              applicationId={mockApplicationId}
              onDashboardClick={dashboardClick}
              onDocumentsClick={documentClick}
              onCommentsClick={commentClick}
              onSearchClick={searchClick}
              currentLocation={PAGES.dashboard.path}
            />
          )
        })
        it('should render search button', () => {
          const searchButton = element.getByText(AppHeaderLabel.Search)
          expect(searchButton).toBeInTheDocument()
          userEvent.click(searchButton)
          expect(searchClick).toBeCalled()
        })
        it('should render dashboard button', () => {
          const dashboardButton = element.getByText(AppHeaderLabel.Dashboard)
          expect(dashboardButton).toBeInTheDocument()
          userEvent.click(dashboardButton)
          expect(dashboardClick).toBeCalled()
        })
        it('should not render comment button', () => {
          const commentsButton = element.queryByText(AppHeaderLabel.Comments)
          expect(commentsButton).not.toBeInTheDocument()
        })
        it('should not render document button', () => {
          const documentButton = element.queryByText(AppHeaderLabel.Documents)
          expect(documentButton).not.toBeInTheDocument()
        })
      })

      describe('preprocessing page', () => {
        let element
        beforeEach(() => {
          element = render(
            <AppHeader
              applicationId={mockApplicationId}
              onDashboardClick={dashboardClick}
              onDocumentsClick={documentClick}
              onCommentsClick={commentClick}
              onSearchClick={searchClick}
              currentLocation={PAGES.preProcessing.path}
            />
          )
        })
        it('should render search button', () => {
          const searchButton = element.getByText(AppHeaderLabel.Search)
          expect(searchButton).toBeInTheDocument()
          userEvent.click(searchButton)
          expect(searchClick).toBeCalled()
        })
        it('should render dashboard button', () => {
          const dashboardButton = element.getByText(AppHeaderLabel.Dashboard)
          expect(dashboardButton).toBeInTheDocument()
          userEvent.click(dashboardButton)
          expect(dashboardClick).toBeCalled()
        })
        it('should render comment button', () => {
          const commentsButton = element.getByText(AppHeaderLabel.Comments)
          expect(commentsButton).toBeInTheDocument()
          userEvent.click(commentsButton)
          expect(commentClick).toBeCalled()
        })
        it('should render document button', () => {
          const documentButton = element.getByText(AppHeaderLabel.Documents)
          expect(documentButton).toBeInTheDocument()
          userEvent.click(documentButton)
          expect(documentClick).toBeCalled()
        })
      })
    })

    describe('With undefined onclick function', () => {
      describe('home page', () => {
        let element
        beforeEach(() => {
          element = render(
            <AppHeader applicationId={mockApplicationId} currentLocation='/' />
          )
        })
        it('should not render search button', () => {
          const searchButton = element.queryByText(AppHeaderLabel.Search)
          expect(searchButton).not.toBeInTheDocument()
        })
        it('should not render dashboard button', () => {
          const dashboardButton = element.queryByText(AppHeaderLabel.Dashboard)
          expect(dashboardButton).not.toBeInTheDocument()
        })
        it('should not render comment button', () => {
          const commentsButton = element.queryByText(AppHeaderLabel.Comments)
          expect(commentsButton).not.toBeInTheDocument()
        })
        it('should not render document button', () => {
          const documentButton = element.queryByText(AppHeaderLabel.Documents)
          expect(documentButton).not.toBeInTheDocument()
        })
      })
      describe('dashboard page', () => {
        let element
        beforeEach(() => {
          element = render(
            <AppHeader
              applicationId={mockApplicationId}
              currentLocation={PAGES.dashboard.path}
            />
          )
        })
        it('should not render search button', () => {
          const searchButton = element.queryByText(AppHeaderLabel.Search)
          expect(searchButton).not.toBeInTheDocument()
        })
        it('should not render dashboard button', () => {
          const dashboardButton = element.queryByText(AppHeaderLabel.Dashboard)
          expect(dashboardButton).not.toBeInTheDocument()
        })
        it('should not render comment button', () => {
          const commentsButton = element.queryByText(AppHeaderLabel.Comments)
          expect(commentsButton).not.toBeInTheDocument()
        })
        it('should not render document button', () => {
          const documentButton = element.queryByText(AppHeaderLabel.Documents)
          expect(documentButton).not.toBeInTheDocument()
        })
      })
      describe('preprocessing page', () => {
        let element
        beforeEach(() => {
          element = render(
            <AppHeader
              applicationId={mockApplicationId}
              currentLocation={PAGES.preProcessing.path}
            />
          )
        })
        it('should not render search button', () => {
          const searchButton = element.queryByText(AppHeaderLabel.Search)
          expect(searchButton).not.toBeInTheDocument()
        })
        it('should not render dashboard button', () => {
          const dashboardButton = element.queryByText(AppHeaderLabel.Dashboard)
          expect(dashboardButton).not.toBeInTheDocument()
        })
        it('should not render comment button', () => {
          const commentsButton = element.queryByText(AppHeaderLabel.Comments)
          expect(commentsButton).not.toBeInTheDocument()
        })
        it('should not render document button', () => {
          const documentButton = element.queryByText(AppHeaderLabel.Documents)
          expect(documentButton).not.toBeInTheDocument()
        })
      })
    })
  })
})
