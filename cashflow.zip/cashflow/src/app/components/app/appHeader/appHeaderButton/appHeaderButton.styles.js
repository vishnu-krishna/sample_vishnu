import styled from 'styled-components'
import styleVars from '@anz/styles-global'

export const StyledButton = styled.button`
  margin: 4px;
  padding: 0;
  width: 80px;
  border: none;
  border-radius: 5px;
  background-color: ${styleVars.color.darkBlue};
  color: ${styleVars.color.white};
  text-align: center;
  font-family: 'Myriad Pro', sans-serif;

  :hover {
    background-color: ${styleVars.color.white};
    color: ${styleVars.color.oceanBlue};
    cursor: pointer;
  }

  svg {
    transform: scale(1.1, 1.1);
  }

  :focus {
    outline: 0;
  }
`

export const AppHeaderText = styled.p`
  font-style: normal;
  font-weight: bold;
  font-size: 14px;
  display: block;
  width: 100%;
  position: relative;
  margin: 0px;
`

export const ContentContainer = styled.div`
  display: block;
  height: 100%;
`
