import React from 'react'
import { render } from '@testing-library/react'
import {
  AppHeaderButton,
  AppHeaderIcons
} from 'app/components/app/appHeader/appHeaderButton/appHeaderButton.component'
import userEvent from '@testing-library/user-event'

describe('AppHeaderButton', () => {
  test('documents button should match snapshot', () => {
    const { asFragment } = render(
      <AppHeaderButton
        imageType={AppHeaderIcons.Documents}
        label='Documents'
        onClick={jest.fn()}
      />
    )
    expect(asFragment()).toMatchSnapshot()
  })

  test('Search button should match snapshot', () => {
    const { asFragment } = render(
      <AppHeaderButton
        imageType={AppHeaderIcons.Search}
        label='Search'
        onClick={jest.fn()}
      />
    )
    expect(asFragment()).toMatchSnapshot()
  })

  test('comments button should match snapshot', () => {
    const { asFragment } = render(
      <AppHeaderButton
        imageType={AppHeaderIcons.Comments}
        label='Comments'
        onClick={jest.fn()}
      />
    )
    expect(asFragment()).toMatchSnapshot()
  })

  test('Dashboard button should match snapshot', () => {
    const { asFragment } = render(
      <AppHeaderButton
        imageType={AppHeaderIcons.Dashboard}
        label='Dashboard'
        onClick={jest.fn()}
      />
    )
    expect(asFragment()).toMatchSnapshot()
  })

  test('No parameters should match snapshot', () => {
    const { asFragment } = render(<AppHeaderButton />)
    expect(asFragment()).toMatchSnapshot()
  })

  it('should invoke onClick on button click', () => {
    const onClick = jest.fn()
    const { getByRole } = render(<AppHeaderButton onClick={onClick} />)
    const button = getByRole('button')
    userEvent.click(button)
    expect(onClick).toHaveBeenCalled()
  })
})
