import PropTypes from 'prop-types'
import React from 'react'
import {
  AppHeaderText,
  ContentContainer,
  StyledButton
} from 'app/components/app/appHeader/appHeaderButton/appHeaderButton.styles'
import HomeIcon from '@anz/icon/dist/filled/generic/home'
import SearchIcon from '@anz/icon/dist/filled/generic/search'
import CommentsIcon from '@anz/icon/dist/filled/generic/feedback'
import DocumentsIcon from '@anz/icon/dist/filled/generic/statements-documents'

export const AppHeaderIcons = {
  Dashboard: 'dashboard_home',
  Search: 'search',
  Comments: 'comments',
  Documents: 'documents'
}

export const AppHeaderLabel = {
  Dashboard: 'Dashboard',
  Search: 'Search',
  Comments: 'Comments',
  Documents: 'Documents'
}

const componentForImageType = buttonType => {
  switch (buttonType) {
    case AppHeaderIcons.Dashboard:
      return <HomeIcon />
    case AppHeaderIcons.Search:
      return <SearchIcon />
    case AppHeaderIcons.Comments:
      return <CommentsIcon />
    case AppHeaderIcons.Documents:
      return <DocumentsIcon />
    default:
      return null
  }
}

export const AppHeaderButton = ({ imageType, label, onClick }) => {
  return (
    <StyledButton onClick={onClick}>
      <ContentContainer>
        {componentForImageType(imageType)}
        <AppHeaderText>{label}</AppHeaderText>
      </ContentContainer>
    </StyledButton>
  )
}

AppHeaderButton.propTypes = {
  image: PropTypes.string,
  label: PropTypes.string,
  onClick: PropTypes.func,
  imageType: PropTypes.any
}
