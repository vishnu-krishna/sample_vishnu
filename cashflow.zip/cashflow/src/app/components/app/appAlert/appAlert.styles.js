import styled from 'styled-components'

const WIDTH = 1024

export const AppAlertWrapper = styled.div`
  position: fixed;
  top: 75px;
  left: 50%;
  margin-left: -${WIDTH / 2}px;
  width: ${WIDTH}px;
  z-index: 999;
`
