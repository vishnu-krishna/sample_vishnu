import React, { useEffect } from 'react'
import * as ReactDOM from 'react-dom'
import PropTypes from 'prop-types'
import * as uuid from 'uuid'
import Alert from '@anz/alert'
import { AppAlertWrapper } from 'app/components/app/appAlert/appAlert.styles'
import { useDispatch } from 'react-redux'
import { hideAlertAction } from 'app/actions'

const DISMISS_DELAY = 5000

export const AppAlert = props => {
  const { id = uuid.v4(), reason, content } = props

  const dispatch = useDispatch()

  useEffect(() => {
    setTimeout(() => {
      dispatch(hideAlertAction())
    }, DISMISS_DELAY)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return ReactDOM.createPortal(
    <AppAlertWrapper>
      <Alert
        id={id}
        reason={reason}
        closable={true}
        onClose={() => dispatch(hideAlertAction())}
      >
        {content}
      </Alert>
    </AppAlertWrapper>,
    document.body
  )
}

AppAlert.REASON = {
  success: 'success',
  information: 'information',
  warning: 'warning',
  error: 'error'
}

AppAlert.propTypes = {
  id: PropTypes.string,
  reason: PropTypes.oneOf(Object.keys(AppAlert.REASON)).isRequired,
  content: PropTypes.any.isRequired
}
