import React from 'react'
import { getByText, render } from '@testing-library/react'
import { Provider } from 'react-redux'

import store from 'store'
import { AppAlert } from 'app/components/app/appAlert/appAlert.component'

describe('AppAlert component', () => {
  it('Should display success alert with message', () => {
    const content = 'Success Message'
    render(
      <Provider store={store}>
        <AppAlert reason={AppAlert.REASON.success} content={content} />
      </Provider>
    )

    expect(getByText(document.body, content)).not.toBeNull()
    expect(document.body).toMatchSnapshot()
  })

  it('Should display error alert with message', () => {
    const content = 'Error Message'
    render(
      <Provider store={store}>
        <AppAlert reason={AppAlert.REASON.error} content={content} />
      </Provider>
    )

    expect(getByText(document.body, content)).not.toBeNull()
    expect(document.body).toMatchSnapshot()
  })

  it('Should display information alert with message', () => {
    const content = 'Information Message'
    render(
      <Provider store={store}>
        <AppAlert reason={AppAlert.REASON.information} content={content} />
      </Provider>
    )

    expect(getByText(document.body, content)).not.toBeNull()
    expect(document.body).toMatchSnapshot()
  })

  it('Should display warning alert with message', () => {
    const content = 'Warning Message'
    render(
      <Provider store={store}>
        <AppAlert reason={AppAlert.REASON.warning} content={content} />
      </Provider>
    )

    expect(getByText(document.body, content)).not.toBeNull()
    expect(document.body).toMatchSnapshot()
  })
})
