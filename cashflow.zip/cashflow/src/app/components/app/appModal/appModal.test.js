import React from 'react'
import { render } from '@testing-library/react'
import { AppModal } from './appModal.component'

describe('appModal', () => {
  test('snapshot tests', () => {
    const { asFragment } = render(
      <AppModal
        modal={{
          content: <div>This is a test modal</div>
        }}
        hideAppModal={jest.fn()}
      />
    )
    expect(asFragment()).toMatchSnapshot()
  })
})
