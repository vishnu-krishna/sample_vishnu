import styled from 'styled-components'

export const ContentPane = styled.div`
  font-size: 16px;
`
export const Heading = styled.div`
  margin-bottom: 16px;
  font-size: 24px;
  font-weight: 100;
`
export const FieldLabel = styled.label`
  font-weight: bold;
  padding-right: 10px;
`
export const FieldValue = styled.span`
  clear: both;
`
