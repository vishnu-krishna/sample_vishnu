import { connect } from 'react-redux'
import { AppModal } from 'app/components/app/appModal/appModal.component'
import { hideAppModalAction } from 'app/actions'

export const mapDispatchToProps = dispatch => {
  return {
    hideAppModal: () => {
      dispatch(hideAppModalAction())
    }
  }
}

export default connect(
  null,
  mapDispatchToProps
)(AppModal)
