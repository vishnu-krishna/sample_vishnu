import React from 'react'
import { storiesOf } from '@storybook/react'
import { AppModal } from './appModal.component'

storiesOf('AppModal', module).add('show', () => {
  return (
    <AppModal
      modal={{
        content: <div>This is a test modal</div>
      }}
    />
  )
})
