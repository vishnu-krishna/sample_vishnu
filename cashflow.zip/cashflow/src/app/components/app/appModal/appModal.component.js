import React from 'react'
import Modal from '@anz/modal'
import PropTypes from 'prop-types'

export const AppModal = ({ modal, hideAppModal }) => {
  const { content } = modal
  const maxWidth = '960px'
  return (
    <Modal
      id='app-modal'
      title=''
      maxWidth={maxWidth}
      backdropClose={true}
      showClose={true}
      isOpen={true}
      closeModal={hideAppModal}
    >
      {content}
    </Modal>
  )
}

AppModal.propTypes = {
  modal: PropTypes.object,
  hideAppModal: PropTypes.func
}
