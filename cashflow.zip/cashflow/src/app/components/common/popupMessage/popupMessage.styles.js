import styled from 'styled-components'

export const PopupMessageWrapper = styled.div`
  margin: 24px;
  display: block;
  text-align: center;
  button {
    background: #fff;
  }
`
