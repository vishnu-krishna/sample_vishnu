import React from 'react'
import { render } from '@testing-library/react'
import { PopupMessage } from './popupMessage.component'
import RefreshIcon from '@anz/icon/dist/filled/generic/refresh'

describe('PopupMessage component', () => {
  it('an error message', () => {
    const { asFragment } = render(
      <PopupMessage
        id='error_no_action'
        message='A test message'
        reason='error'
      />
    )
    expect(asFragment()).toMatchSnapshot()
  })

  it('an error message', () => {
    const { asFragment } = render(
      <PopupMessage
        id='error_with_action'
        message='A test message with action'
        reason='error'
        action={{
          text: 'Refresh',
          icon: <RefreshIcon />,
          callback: () => {
            alert('Refresh application')
          }
        }}
      />
    )
    expect(asFragment()).toMatchSnapshot()
  })
})
