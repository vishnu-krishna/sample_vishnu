import React from 'react'
import PropTypes from 'prop-types'
import Alert from '@anz/alert'
import Button from '@anz/button'
import { PopupMessageWrapper } from './popupMessage.styles'

function createAction (action) {
  return action
    ? [
        <Button
          key={action.text}
          appearance='primary'
          variant='ghost'
          size='extra-small'
          icon={action.icon}
          iconPlacement='right'
          onClick={action.callback}
        >
          {action.text}
        </Button>
      ]
    : []
}

export function PopupMessage ({ id, message, reason, action }) {
  const actions = createAction(action)
  return (
    <PopupMessageWrapper>
      <Alert id={id} data-test-id={id} reason={reason} buttons={actions}>
        {message}
      </Alert>
    </PopupMessageWrapper>
  )
}

PopupMessage.propTypes = {
  id: PropTypes.string,
  message: PropTypes.string,
  reason: PropTypes.oneOf(['success', 'information', 'warning', 'error'])
    .isRequired,
  action: PropTypes.shape({
    text: PropTypes.string.isRequired,
    icon: PropTypes.object,
    callback: PropTypes.func.isRequired
  })
}
