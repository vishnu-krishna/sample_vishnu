import React from 'react'
import { storiesOf } from '@storybook/react'
import { PopupMessage } from './popupMessage.component'
import RefreshIcon from '@anz/icon/dist/filled/generic/refresh'

storiesOf('Popup Message', module)
  .add('Error message', () => {
    return (
      <PopupMessage
        id='x0'
        message='Unable to retrieve data for complete applications due to a system error. Please click the refresh button to load all complete applications'
        reason='error'
      />
    )
  })
  .add('Error message with action', () => {
    return (
      <PopupMessage
        id='x1'
        message='Unable to retrieve data for complete applications due to a system error. Please click the refresh button to load all complete applications'
        reason='error'
        action={{
          text: 'Refresh',
          icon: <RefreshIcon />,
          callback: () => {
            alert('Refresh application')
          }
        }}
      />
    )
  })
  .add('Success message', () => {
    return (
      <PopupMessage
        id='x2'
        message='Application retrieval is done'
        reason='success'
      />
    )
  })
  .add('Success message with action', () => {
    return (
      <PopupMessage
        id='x3'
        message='Application retrieval is done'
        reason='success'
        action={{
          text: 'Refresh',
          icon: <RefreshIcon />,
          callback: () => {
            alert('Refresh application')
          }
        }}
      />
    )
  })
  .add('Information message', () => {
    return (
      <PopupMessage
        id='x4'
        message='Application retrieval is done'
        reason='information'
      />
    )
  })
  .add('Information message with action', () => {
    return (
      <PopupMessage
        id='x5'
        message='Application retrieval is done'
        reason='information'
        action={{
          text: 'Refresh',
          icon: <RefreshIcon />,
          callback: () => {
            alert('Refresh application')
          }
        }}
      />
    )
  })
  .add('Warning message', () => {
    return (
      <PopupMessage
        id={'x6'}
        message='Application retrieval is done'
        reason='warning'
      />
    )
  })
  .add('Warning message with action', () => {
    return (
      <PopupMessage
        id='x7'
        message='Application retrieval is done'
        reason='warning'
        action={{
          text: 'Refresh',
          icon: <RefreshIcon />,
          callback: () => {
            alert('Refresh application')
          }
        }}
      />
    )
  })
