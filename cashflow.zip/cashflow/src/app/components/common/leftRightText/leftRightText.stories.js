import React from 'react'
import { storiesOf } from '@storybook/react'
import LeftRightText from 'app/components/common/leftRightText/leftRightText.component'

storiesOf('LeftRight Text Component', module)
  .add('Show Left and Right Text(not bold)', () => {
    return (
      <div style={{ display: 'flex' }}>
        <LeftRightText
          leftText={'Some Left Text'}
          rightText={'Some Right Text'}
          hideLeftText={false}
        />
      </div>
    )
  })
  .add('Show Left and Right Text (Bold)', () => {
    return (
      <div style={{ display: 'flex' }}>
        <LeftRightText
          leftText={'Some Left Text'}
          rightText={'Some Right Text'}
          hideLeftText={false}
          leftIsBold
          rightIsBold
        />
      </div>
    )
  })
