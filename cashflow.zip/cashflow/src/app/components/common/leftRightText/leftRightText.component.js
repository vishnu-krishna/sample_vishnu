import React from 'react'
import {
  LeftText,
  RightText,
  RightTextError,
  RightTextWithErrorContainer,
  SmallRightTextError
} from 'app/components/common/leftRightText/leftRightText.styles'
import PropTypes from 'prop-types'
import { trimValue } from 'app/utils/appUtils'

const setLeftText = (leftIsBold, leftText, hideLeftText) =>
  !hideLeftText && (
    <LeftText bold={leftIsBold} data-test-id='left-text'>
      {leftText}
    </LeftText>
  )

const setRightText = (
  isMandatoryField,
  rightIsBold,
  rightText,
  fromCap,
  acnWasDerived = false,
  isABN
) => {
  const rightTextWithoutError = (
    <RightText bold={rightIsBold} data-test-id='right-text'>
      {rightText}
    </RightText>
  )

  const rightTextWithError = (
    <RightTextError bold={rightIsBold} data-test-id='right-text-error'>
      {isABN
        ? `The ABN value for this business has not been returned. Please review the related iKC record to ensure the ABN value is updated.`
        : `Validation Error: Update profile information and reload CAP CIS ID`}
    </RightTextError>
  )
  const errorText = `The ACN value for this business has been derived from it's ABN. Please
        review the related iKC record to ensure the ACN value is updated, if
        needed.`
  const textWithAcnDerivedError = (
    <RightTextWithErrorContainer>
      <RightText bold={rightIsBold} data-test-id='right-text'>
        {rightText}
      </RightText>
      <SmallRightTextError bold={rightIsBold} data-test-id='right-text-error'>
        {errorText}
      </SmallRightTextError>
    </RightTextWithErrorContainer>
  )

  if (acnWasDerived) {
    return textWithAcnDerivedError
  }

  if (isMandatoryField && fromCap && !rightText) {
    return rightTextWithError
  }
  return rightTextWithoutError
}

const LeftRightText = ({
  leftText,
  hideLeftText = true,
  fromCap = false,
  rightText,
  leftIsBold = false,
  rightIsBold = false,
  isMandatoryField = false,
  acnWasDerived = false,
  isABN = false
}) => (
  <>
    {setLeftText(leftIsBold, trimValue(leftText), hideLeftText)}
    {setRightText(
      isMandatoryField,
      rightIsBold,
      trimValue(rightText),
      fromCap,
      acnWasDerived,
      isABN
    )}
  </>
)

LeftRightText.propTypes = {
  leftText: PropTypes.string,
  rightText: PropTypes.string,
  hideLeftText: PropTypes.bool,
  fromCap: PropTypes.bool,
  leftIsBold: PropTypes.bool,
  rightIsBold: PropTypes.bool,
  isMandatoryField: PropTypes.bool,
  isABN: PropTypes.bool,
  acnWasDerived: PropTypes.any
}

export default LeftRightText
