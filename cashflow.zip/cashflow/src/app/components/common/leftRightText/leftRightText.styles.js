import styled from 'styled-components'

export const LeftText = styled.div`
  flex: 0 0 35%;
  text-align: right;
  font-weight: ${({ bold }) => (bold ? 'bold' : 'normal')};
`
export const RightText = styled.div`
  white-space: pre-wrap;
  width: 325px;
  margin-left: 20px;
  font-weight: ${({ bold }) => (bold ? 'bold' : 'normal')};
  word-break: break-word;
  max-height: 100%;
  overflow: auto;
`
export const RightTextError = styled.div`
  font-size: 14px;
  margin-left: 20px;
  font-weight: ${({ bold }) => (bold ? 'bold' : 'normal')};
  color: #d53d39;
`

export const SmallRightTextError = styled.div`
  margin-left: 20px;
  margin-top: 6px;
  flex: 0 0 65%;
  font-weight: ${({ bold }) => (bold ? 'bold' : 'normal')};
  font-size: 14px;
  color: #d53d39;
`

export const RightTextWithErrorContainer = styled.div`
  display: flex;
  align-items: center;
`
