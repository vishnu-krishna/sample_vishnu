import { render } from '@testing-library/react'
import React from 'react'
import LeftRightText from 'app/components/common/leftRightText/leftRightText.component'

describe('Left Right Text Component', () => {
  test('left and right text NOT to be bold', () => {
    const { getByTestId } = render(
      <LeftRightText
        leftText='Some Left Text'
        rightText='Some Right Text'
        hideLeftText={false}
      />
    )
    const leftTextElement = getByTestId('left-text')
    const rightTextElement = getByTestId('right-text')
    expect(leftTextElement).toHaveStyleRule('font-weight', 'normal')
    expect(rightTextElement).toHaveStyleRule('font-weight', 'normal')
  })

  test('left and right text to be bold', () => {
    const { getByTestId } = render(
      <LeftRightText
        leftText='Some Left Text'
        hideLeftText={false}
        rightText='Some Right Text'
        leftIsBold
        rightIsBold
      />
    )
    const leftTextElement = getByTestId('left-text')
    const rightTextElement = getByTestId('right-text')
    expect(leftTextElement).toHaveStyleRule('font-weight', 'bold')
    expect(rightTextElement).toHaveStyleRule('font-weight', 'bold')
  })

  test('hide left text', () => {
    const { queryByTestId } = render(
      <LeftRightText
        leftText='Some Left Text'
        rightText='Some Right Text'
        leftIsBold
        rightIsBold
        hideLeftText={true}
      />
    )
    const leftTextElement = queryByTestId('left-text')
    expect(leftTextElement).not.toBeInTheDocument()
  })

  test('show right text with error message', () => {
    const { queryByTestId, queryByText } = render(
      <LeftRightText
        rightText=''
        leftIsBold
        rightIsBold
        isMandatoryField={true}
        fromCap={true}
        isABN={false}
      />
    )
    const rightTextElementErrorMessage = queryByTestId('right-text-error')
    const rightErrorText = queryByText(
      'Validation Error: Update profile information and reload CAP CIS ID'
    )
    const rightText = queryByTestId('right-text')
    expect(rightTextElementErrorMessage).toBeInTheDocument()
    expect(rightErrorText).toBeInTheDocument()
    expect(rightText).not.toBeInTheDocument()
  })

  test('show right text with abn error message', () => {
    const { queryByTestId, queryByText } = render(
      <LeftRightText
        rightText=''
        leftIsBold
        rightIsBold
        isMandatoryField={true}
        fromCap={true}
        isABN={true}
      />
    )
    const rightTextElementErrorMessage = queryByTestId('right-text-error')
    const rightErrorText = queryByText(
      'The ABN value for this business has not been returned. Please review the related iKC record to ensure the ABN value is updated.'
    )
    const rightText = queryByTestId('right-text')
    expect(rightTextElementErrorMessage).toBeInTheDocument()
    expect(rightErrorText).toBeInTheDocument()
    expect(rightText).not.toBeInTheDocument()
  })

  test('show NOT right text with error message when hideLeftText and isMandatoryField is false', () => {
    const { queryByTestId } = render(
      <LeftRightText
        leftText='Some Left Text'
        rightText=''
        leftIsBold
        rightIsBold
        hideLeftText={false}
        isMandatoryField={false}
      />
    )
    const rightTextElementErrorMessage = queryByTestId('right-text-error')
    const rightText = queryByTestId('right-text')
    expect(rightTextElementErrorMessage).not.toBeInTheDocument()
    expect(rightText).toBeInTheDocument()
  })

  test('show NOT right text with error message when hideLeftText is true but isMandatoryField is false', () => {
    const { queryByTestId } = render(
      <LeftRightText
        leftText='Some Left Text'
        rightText=''
        leftIsBold
        rightIsBold
        hideLeftText={true}
        isMandatoryField={false}
      />
    )
    const rightTextElementErrorMessage = queryByTestId('right-text-error')
    const rightText = queryByTestId('right-text')
    expect(rightTextElementErrorMessage).not.toBeInTheDocument()
    expect(rightText).toBeInTheDocument()
  })

  test('show NOT right text with error message when right text is not empt', () => {
    const { queryByTestId } = render(
      <LeftRightText
        leftText='Some Left Text'
        rightText='some right text'
        leftIsBold
        rightIsBold
        hideLeftText={true}
        isMandatoryField={true}
      />
    )
    const rightTextElementErrorMessage = queryByTestId('right-text-error')
    const rightText = queryByTestId('right-text')
    expect(rightTextElementErrorMessage).not.toBeInTheDocument()
    expect(rightText).toBeInTheDocument()
  })
})
