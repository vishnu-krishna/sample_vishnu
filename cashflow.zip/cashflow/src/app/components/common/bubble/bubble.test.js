import React from 'react'
import { render } from '@testing-library/react'
import { Bubble } from './bubble.component'

describe('Bubble snapshot test', () => {
  it('renders correctly', () => {
    const bubble = render(<Bubble />)
    expect(bubble).toMatchSnapshot()
  })
  it('should display the spinner when isLoading is true', () => {
    const id = 'testing-bubble'
    const { getByTestId } = render(<Bubble id={id} isLoading={true} />)
    const spinner = getByTestId(`test-spinner-${id}`)
    expect(spinner).toBeInTheDocument()
  })
  it('should not display the spinner when isLoading is false', () => {
    const id = 'testing-bubble'
    const { queryByTestId } = render(<Bubble isLoading={false} />)
    const spinner = queryByTestId(`test-spinner-${id}`)
    expect(spinner).toBeNull()
  })
})
