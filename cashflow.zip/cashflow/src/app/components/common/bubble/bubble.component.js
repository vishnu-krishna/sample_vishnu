import React from 'react'
import styleVars from '@anz/styles-global'
import { Spinner } from 'app/components/common/spinner/spinner.component'
import { PropTypes } from 'prop-types'

import {
  BubbleComponent,
  BubblesRoot,
  BubbleSubTxt,
  BubbleTxt,
  LabelSubText,
  LabelText
} from './bubble.styles'

export const Bubble = ({
  isLoading,
  bubbleSize,
  wrapperSize,
  id,
  label,
  bubbleText,
  labelColor,
  labelFontSize,
  bubbleSubText,
  bgColor,
  bubbleTextColor,
  outlineColor,
  onBubbleClick,
  labelSubText,
  spinnerColor
}) => {
  return (
    <BubbleComponent id={id} wrapperSize={wrapperSize}>
      <BubblesRoot
        data-test-id={id}
        bubbleSize={bubbleSize}
        bgColor={bgColor}
        outlineColor={outlineColor}
        onClick={onBubbleClick}
      >
        {isLoading ? (
          <Spinner id={`spinner-${id}`} color={spinnerColor} />
        ) : (
          <div>
            <BubbleTxt bubbleTextSize={48} bubbleTextColor={bubbleTextColor}>
              {bubbleText}
            </BubbleTxt>
            <BubbleSubTxt bubbleTextSize={16} bubbleTextColor={bubbleTextColor}>
              {bubbleSubText}
            </BubbleSubTxt>
          </div>
        )}
      </BubblesRoot>
      <LabelText
        data-test-id='dashboard-circleTitle'
        textWidth={bubbleSize}
        labelColor={labelColor}
        labelFontSize={labelFontSize}
      >
        {label}
      </LabelText>
      <LabelSubText
        data-test-id='dashboard-circleSubTitle'
        textWidth={bubbleSize}
        labelColor={labelColor}
        labelFontSize={labelFontSize}
      >
        {labelSubText}
      </LabelSubText>
    </BubbleComponent>
  )
}

Bubble.propTypes = {
  wrapperSize: PropTypes.any,
  bubbleSize: PropTypes.any,
  labelFontSize: PropTypes.any,
  bubbleText: PropTypes.any,
  bgColor: PropTypes.any,
  bubbleTextColor: PropTypes.any,
  outlineColor: PropTypes.any,
  label: PropTypes.any,
  bubbleSubText: PropTypes.any,
  labelColor: PropTypes.any,
  labelSubText: PropTypes.any,
  spinnerColor: PropTypes.any,
  isLoading: PropTypes.any,
  id: PropTypes.any,
  onBubbleClick: PropTypes.any
}

Bubble.defaultProps = {
  wrapperSize: 135,
  bubbleSize: 150,
  labelFontSize: 20,
  bubbleText: '-',
  bgColor: styleVars.color.grayscale90,
  bubbleTextColor: styleVars.color.black60,
  outlineColor: styleVars.color.grayscale60,
  label: '',
  bubbleSubText: '',
  labelColor: styleVars.color.darkGrey,
  labelSubText: '',
  spinnerColor: styleVars.color.oceanBlue
}
