import React from 'react'
import { storiesOf } from '@storybook/react'
import { Bubble } from 'app/components/common/bubble/bubble.component'

storiesOf('Bubble ', module).add('Bubble with out Spinner', () => {
  return (
    <Bubble
      isLoading={false}
      bubbleText={9}
      onBubbleClick={() => console.log('bubble clicked')}
    />
  )
})

storiesOf('Bubble ', module).add('Bubble with Spinner', () => {
  return (
    <Bubble
      isLoading={true}
      onBubbleClick={() => console.log('bubble clicked')}
    />
  )
})
