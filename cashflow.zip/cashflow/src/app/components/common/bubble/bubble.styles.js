import styled from 'styled-components'

export const BubbleComponent = styled.div`
  width: ${({ wrapperSize }) => wrapperSize}px;
`

export const BubblesRoot = styled.div`
  width: ${({ bubbleSize }) => bubbleSize}px;
  height: ${({ bubbleSize }) => bubbleSize}px;
  border-radius: ${({ bubbleSize }) => bubbleSize / 2}px;
  border: 5px solid ${({ outlineColor }) => outlineColor};
  background-color: ${({ bgColor }) => bgColor};
  cursor: pointer;
  position: relative;
  display: inline-block;
  text-align: center;
`
export const BubbleTxt = styled.span`
  font-family: 'Myriad Pro', sans-serif;
  font-weight: bold;
  text-align: center;
  padding-top: 1em;
  font-size: ${({ bubbleTextSize }) => bubbleTextSize}px;
  color: ${({ bubbleTextColor }) => bubbleTextColor};
  display: block;
  position: relative;
`
export const BubbleSubTxt = styled.span`
  font-family: 'Myriad Pro', sans-serif;
  text-align: center;
  padding-top: 0.75em;
  font-size: ${({ bubbleTextSize }) => bubbleTextSize}px;
  color: ${({ bubbleTextColor }) => bubbleTextColor};
  display: block;
  position: relative;
`

export const LabelText = styled.div`
  font-family: 'Myriad Pro', sans-serif;
  font-weight: bold;
  padding-top: 0.5em;
  padding-bottom: 0.5em;
  font-size: ${({ labelFontSize }) => labelFontSize}px;
  color: ${({ labelColor }) => labelColor};
  text-align: center;
  width: ${({ textWidth }) => textWidth}px;
`

export const LabelSubText = styled.div`
  font-family: 'Myriad Pro', sans-serif;
  font-weight: normal;
  font-size: ${({ labelFontSize }) => labelFontSize}px;
  color: ${({ labelColor }) => labelColor};
  text-align: center;
  width: ${({ textWidth }) => textWidth}px;
`
