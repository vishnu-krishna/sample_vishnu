import styled from 'styled-components'

export const DateFieldWrapper = styled.div`
  height: 50px;
  overflow: hidden;
`

export const DateFieldContainer = styled.div`
  margin-top: -34px;
`
