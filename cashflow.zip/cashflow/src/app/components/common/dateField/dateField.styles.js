import styled from 'styled-components'
import styleVars from '@anz/styles-global'

export const DateFieldWrapper = styled.div`
  label {
    display: none;
  }
  input {
    background: ${styleVars.color.white};
  }
  margin-top: 5px;
  margin-bottom: 5px;
  ${props =>
    `[data-test-id=${props.name}_date-mask] {
              margin-top: 4px;
              z-index: 1;
              pointer-events: none;
              }`}
`
