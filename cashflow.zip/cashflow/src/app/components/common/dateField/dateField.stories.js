import React from 'react'
import { storiesOf } from '@storybook/react'
import DateField from './dateField.component'

storiesOf('Date Field', module)
  .add('Date field', () => <DateField id='date-field-id' />)
  .add('Date field with error message', () => (
    <DateField id='date-field-id' errorMessage='Date Error Message' />
  ))
  .add('Date field with red border', () => (
    <DateField id='date-field-id' isInvalid={true} />
  ))
