import React, { memo, useEffect, useState } from 'react'
import PropTypes from 'prop-types'
import AnzDateField from '@anz/date-field'
import { DateFieldWrapper } from './dateField.styles'

const DateField = ({ id, onChange, errorMessage, isInvalid, value }) => {
  const [dateValue, setDateValue] = useState('')

  const changeDate = newDateValue => {
    setDateValue(newDateValue)
    if (onChange) {
      onChange(newDateValue)
    }
  }

  useEffect(() => {
    setDateValue(value)
  }, [value])

  return (
    <DateFieldWrapper name={id}>
      <AnzDateField
        id={id}
        label=''
        placeholder='DD/MM/YYYY'
        onChange={e => changeDate(e.target.value)}
        error={errorMessage}
        value={dateValue}
        invalid={isInvalid || !!errorMessage}
        touched={true}
      />
    </DateFieldWrapper>
  )
}

DateField.propTypes = {
  id: PropTypes.string.isRequired,
  onChange: PropTypes.func,
  value: PropTypes.string,
  errorMessage: PropTypes.string,
  isInvalid: PropTypes.bool
}

export default memo(DateField, (prevProps, nextProps) => {
  return (
    prevProps.value === nextProps.value &&
    prevProps.errorMessage === nextProps.errorMessage &&
    prevProps.isInvalid === nextProps.isInvalid
  )
})
