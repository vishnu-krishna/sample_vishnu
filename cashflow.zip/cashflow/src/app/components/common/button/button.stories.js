import { storiesOf } from '@storybook/react'
import React from 'react'
import Button from './button.component'

export const defaultProps = {
  buttonLabel: 'Default',
  type: 'button'
}

export const secondaryProps = {
  buttonLabel: 'Secondary',
  isSecondary: true,
  type: 'button'
}

export const secondaryDisabledProps = {
  buttonLabel: 'Secondary Disabled',
  isSecondary: true,
  type: 'button',
  isDisabled: true
}

export const defaultDisabledProps = {
  buttonLabel: 'Default Disabled',
  type: 'button',
  isDisabled: true
}

export const confirmationProps = {
  buttonLabel: 'Confirmation',
  type: 'button',
  isConfirmation: true
}

export const disabledConfirmationProps = {
  buttonLabel: 'Disabled Confirmation',
  type: 'button',
  isDisabled: true,
  isConfirmation: true
}

export const destructiveProps = {
  buttonLabel: 'Destructive',
  type: 'button',
  isDestructive: true
}

export const disabledDestructiveProps = {
  buttonLabel: 'Disabled Destructive',
  type: 'button',
  isDisabled: true,
  isDestructive: true
}

storiesOf('Button Component', module).add('Default', () => (
  <Button {...defaultProps} />
))

storiesOf('Button Component', module).add('Default Disabled', () => (
  <Button {...defaultDisabledProps} />
))

storiesOf('Button Component', module).add('Secondary', () => (
  <Button {...secondaryProps} />
))

storiesOf('Button Component', module).add('Secondary Disabled', () => (
  <Button {...secondaryDisabledProps} />
))

storiesOf('Button Component', module).add('Confirmation', () => (
  <Button {...confirmationProps} />
))

storiesOf('Button Component', module).add('Disabled Confirmation', () => (
  <Button {...disabledConfirmationProps} />
))

storiesOf('Button Component', module).add('Destructive', () => (
  <Button {...destructiveProps} />
))

storiesOf('Button Component', module).add('Disabled Destructive', () => (
  <Button {...disabledDestructiveProps} />
))
