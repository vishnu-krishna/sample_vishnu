import styled from 'styled-components'
import styleVars from '@anz/styles-global'

export const ButtonLabel = styled.div`
  color: ${props => setLabelColor(props)};
  font-family: 'Myriad Pro', sans-serif;
  font-size: ${styleVars.dimensions.gap16};
  font-weight: 400;
`
export const ButtonWrapper = styled.div`
  min-width: 192px;
  max-width: 219px;
  display: inline-block;
`
export const ButtonContent = styled.button`
  width: 100%;
  height: ${styleVars.dimensions.gap44};
  cursor: pointer;
  border: ${props => setBorderColor(props)};
  border-radius: 3px;
  background-color: ${props => setBackgroundColor(props)};
  opacity: ${props => setOpacity(props)};

  &:hover {
    background-color: ${props => setBackgroundColorOnHover(props)};

    ${ButtonLabel} {
      color: ${({ isSecondary }) => isSecondary && styleVars.color.white};
    }
  }

  &:active,
  &:focus {
    background-color: ${props => setBackgroundColorOnFocus(props)};
    ${ButtonLabel} {
      color: ${({ isSecondary }) => isSecondary && styleVars.color.darkBlue};
    }
  }
`

function setBackgroundColorOnFocus ({
  isConfirmation,
  isDestructive,
  isSecondary
}) {
  if (isSecondary) {
    return styleVars.color.white
  }
  if (!isConfirmation && !isDestructive) {
    return styleVars.color.darkBlue
  }
}

function setBackgroundColor ({ isConfirmation, isDestructive, isSecondary }) {
  if (isConfirmation) {
    return styleVars.color.m1
  } else if (isDestructive) {
    return styleVars.color.system.error
  } else if (isSecondary) {
    return styleVars.color.white
  } else {
    return styleVars.color.oceanBlue
  }
}

function setLabelColor ({ isSecondary, isDisabled }) {
  if (isSecondary && isDisabled) {
    return '#99C7DE'
  }

  if (isSecondary) {
    return styleVars.color.oceanBlue
  }
  return styleVars.color.white
}

function setBorderColor ({
  isConfirmation,
  isDestructive,
  isSecondary,
  isDisabled
}) {
  if (isConfirmation) {
    return '1px solid #007002'
  } else if (isDestructive) {
    return '1px solid #9A413E'
  } else if (isSecondary) {
    return '1px solid #0072AC'
  } else if (isDisabled) {
    return '1px solid #99BAC9'
  }
  return '1px solid #005378'
}

function setBackgroundColorOnHover ({ isConfirmation, isDestructive }) {
  if (isConfirmation) {
    return '#54B05A'
  } else if (isDestructive) {
    return `#E6827D`
  } else {
    return styleVars.color.lightOceanBlue
  }
}

function setOpacity ({ isDisabled }) {
  return isDisabled && 0.5
}
