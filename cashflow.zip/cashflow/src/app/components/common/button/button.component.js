import React, { forwardRef } from 'react'
import PropTypes from 'prop-types'
import { ButtonContent, ButtonLabel, ButtonWrapper } from './button.styles'

export const buttonContentTestId = 'button-content'
export const buttonLabelTestId = 'button-label'

const Button = forwardRef(
  (
    {
      id,
      buttonLabel,
      buttonClicked,
      isDisabled,
      isConfirmation,
      isDestructive,
      isSecondary,
      dataTestId
    },
    ref
  ) => {
    const propsForStyledButton = {
      isDisabled,
      isConfirmation,
      isDestructive,
      isSecondary
    }
    return (
      <Button.ButtonWrapper id={id} data-test-id={dataTestId}>
        <Button.ButtonContent
          type='button'
          ref={ref}
          disabled={isDisabled}
          onClick={buttonClicked}
          data-test-id={buttonContentTestId}
          {...propsForStyledButton}
        >
          <Button.ButtonLabel
            {...propsForStyledButton}
            data-test-id={buttonLabelTestId}
          >
            {buttonLabel}
          </Button.ButtonLabel>
        </Button.ButtonContent>
      </Button.ButtonWrapper>
    )
  }
)

Button.propTypes = {
  id: PropTypes.string,
  buttonLabel: PropTypes.string,
  buttonClicked: PropTypes.func,
  isDisabled: PropTypes.bool,
  isConfirmation: PropTypes.bool,
  isDestructive: PropTypes.bool,
  isSecondary: PropTypes.bool,
  dataTestId: PropTypes.string
}

Button.defaultProps = {
  isDisabled: false,
  isConfirmation: false,
  isDestructive: false,
  isSecondary: false,
  dataTestId: 'button'
}

Button.ButtonWrapper = ButtonWrapper
Button.ButtonContent = ButtonContent
Button.ButtonLabel = ButtonLabel

export default Button
