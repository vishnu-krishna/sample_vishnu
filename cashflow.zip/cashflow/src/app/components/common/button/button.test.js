import { render } from '@testing-library/react'
import React from 'react'
import {
  confirmationProps,
  defaultDisabledProps,
  defaultProps,
  destructiveProps,
  disabledConfirmationProps,
  disabledDestructiveProps,
  secondaryDisabledProps,
  secondaryProps
} from './button.stories'
import Button, {
  buttonContentTestId,
  buttonLabelTestId
} from './button.component'

describe('Button Component', () => {
  test('Default Button', () => {
    const { getByTestId } = render(<Button {...defaultProps} />)
    const buttonElement = getByTestId(buttonContentTestId)
    const buttonLabelElement = getByTestId(buttonLabelTestId)
    expect(buttonElement).toBeInTheDocument()
    expect(buttonElement).toHaveStyleRule('background-color', '#007DBA')
    expect(buttonElement).toHaveStyleRule('border', '1px solid #005378')
    expect(buttonLabelElement).toHaveStyleRule('color', '#FFFFFF')
  })

  test('Secondary Button', () => {
    const { getByTestId } = render(<Button {...secondaryProps} />)
    const buttonElement = getByTestId(buttonContentTestId)
    const buttonLabelElement = getByTestId(buttonLabelTestId)
    expect(buttonElement).toBeInTheDocument()
    expect(buttonElement).toHaveStyleRule('background-color', '#FFFFFF')
    expect(buttonElement).toHaveStyleRule('border', '1px solid #0072AC')
    expect(buttonLabelElement).toHaveStyleRule('color', '#007DBA')
  })

  test('Default Button Disabled', () => {
    const { getByTestId } = render(<Button {...defaultDisabledProps} />)
    const buttonElement = getByTestId(buttonContentTestId)
    const buttonLabelElement = getByTestId(buttonLabelTestId)
    expect(buttonElement).toBeInTheDocument()
    expect(buttonElement).toHaveStyleRule('background-color', '#007DBA')
    expect(buttonElement).toHaveStyleRule('border', '1px solid #99BAC9')
    expect(buttonLabelElement).toHaveStyleRule('color', '#FFFFFF')
    expect(buttonElement).toBeDisabled()
  })

  test('Secondary Button Disabled', () => {
    const { getByTestId } = render(<Button {...secondaryDisabledProps} />)
    const buttonElement = getByTestId(buttonContentTestId)
    const buttonLabelElement = getByTestId(buttonLabelTestId)
    expect(buttonElement).toBeInTheDocument()
    expect(buttonElement).toHaveStyleRule('background-color', '#FFFFFF')
    expect(buttonElement).toHaveStyleRule('border', '1px solid #0072AC')
    expect(buttonLabelElement).toHaveStyleRule('color', '#99C7DE')
    expect(buttonElement).toBeDisabled()
  })

  test('Confirmation Button', () => {
    const { getByTestId } = render(<Button {...confirmationProps} />)
    const buttonElement = getByTestId(buttonContentTestId)
    const buttonLabelElement = getByTestId(buttonLabelTestId)
    expect(buttonElement).toBeInTheDocument()
    expect(buttonElement).toHaveStyleRule('background-color', '#008a02')
    expect(buttonElement).toHaveStyleRule('border', '1px solid #007002')
    expect(buttonLabelElement).toHaveStyleRule('color', '#FFFFFF')
  })

  test('Confirmation Disabled Button', () => {
    const { getByTestId } = render(<Button {...disabledConfirmationProps} />)
    const buttonElement = getByTestId(buttonContentTestId)
    const buttonLabelElement = getByTestId(buttonLabelTestId)
    expect(buttonElement).toBeInTheDocument()
    expect(buttonElement).toHaveStyleRule('background-color', '#008a02')
    expect(buttonElement).toHaveStyleRule('border', '1px solid #007002')
    expect(buttonLabelElement).toHaveStyleRule('color', '#FFFFFF')
    expect(buttonElement).toBeDisabled()
  })

  test('Destructive Button', () => {
    const { getByTestId } = render(<Button {...destructiveProps} />)
    const buttonElement = getByTestId(buttonContentTestId)
    const buttonLabelElement = getByTestId(buttonLabelTestId)
    expect(buttonElement).toBeInTheDocument()
    expect(buttonElement).toHaveStyleRule('background-color', '#D73B33')
    expect(buttonElement).toHaveStyleRule('border', '1px solid #9A413E')
    expect(buttonLabelElement).toHaveStyleRule('color', '#FFFFFF')
  })

  test('Destructive Disabled Button', () => {
    const { getByTestId } = render(<Button {...disabledDestructiveProps} />)
    const buttonElement = getByTestId(buttonContentTestId)
    const buttonLabelElement = getByTestId(buttonLabelTestId)
    expect(buttonElement).toBeInTheDocument()
    expect(buttonElement).toHaveStyleRule('background-color', '#D73B33')
    expect(buttonElement).toHaveStyleRule('border', '1px solid #9A413E')
    expect(buttonLabelElement).toHaveStyleRule('color', '#FFFFFF')
    expect(buttonElement).toBeDisabled()
  })

  test('Button should render an ID when provided', () => {
    const { container } = render(<Button id={'mybutton'} />)
    const element = container.querySelector('#mybutton')
    expect(element).toBeDefined()
  })

  test('Button should not render any ID when not explicitly provided', () => {
    const { container } = render(<Button />)
    const idAttr = container.getAttribute('id')
    expect(idAttr).toBeNull()
  })
})
