import React from 'react'
import { storiesOf } from '@storybook/react'
import FlyinWindow from './flyinWindow.component'

storiesOf('FlyinWindow ', module)
  .add('Pop a fly-in window with default is hidden', () => {
    return <FlyinWindow currentLocation='' />
  })
  .add('Popup a fly-in window with 600px width', () => {
    return (
      <FlyinWindow
        title='Search'
        isOpen={true}
        onClose={() => console.log('close search panel')}
        maxWidth={600}
        initTopPad={60}
        currentLocation=''
      />
    )
  })
  .add('Popup a fly-in window with 1200px width', () => {
    return (
      <FlyinWindow
        title='Search'
        isOpen={true}
        onClose={() => console.log('close documents panel')}
        maxWidth={1200}
        initTopPad={60}
        currentLocation=''
      />
    )
  })
