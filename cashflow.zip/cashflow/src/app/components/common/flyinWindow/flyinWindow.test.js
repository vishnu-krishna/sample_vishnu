import React from 'react'
import { render } from '@testing-library/react'
import FlyinWindow from './flyinWindow.component'
import { CURRENT_LOCATION_PAGE_TITLE, PAGES } from 'app/pages/constants'
import userEvent from '@testing-library/user-event'

describe('<FlyinWindow /> component: ', () => {
  it('should not display Documents when the current location is dashboard. ', () => {
    const { queryByText } = render(
      <FlyinWindow
        isOpen={true}
        title='Documents'
        currentLocation={PAGES.dashboard.name}
      />
    )
    const title = queryByText(CURRENT_LOCATION_PAGE_TITLE.DOCUMENTS)
    expect(title).not.toBeInTheDocument()
    expect(title).toBe(null)
  })

  it('should NOT display Comments when the current location is dashboard. ', () => {
    const { queryByText } = render(
      <FlyinWindow
        isOpen={true}
        title='Comments'
        currentLocation={PAGES.dashboard.name}
      />
    )
    const title = queryByText(CURRENT_LOCATION_PAGE_TITLE.COMMENTS)
    expect(title).not.toBeInTheDocument()
    expect(title).toBe(null)
  })

  it('should display Search even when the current location is dashboard', () => {
    const { getByText } = render(
      <FlyinWindow
        isOpen={true}
        title='Search'
        currentLocation={PAGES.dashboard.name}
      />
    )
    const title = getByText('Search')
    expect(title).toBeInTheDocument()
    expect(title).toHaveTextContent('Search')
  })

  it('WILL match <FlyinWindow /> snapshot', () => {
    const flyinWindow = render(
      <FlyinWindow currentLocation={PAGES.preProcessing.name}>
        <p>Search</p>
      </FlyinWindow>
    )
    expect(flyinWindow).toMatchSnapshot()
  })

  it('WILL display title. ', () => {
    const { getByTestId } = render(
      <FlyinWindow
        isOpen={true}
        title='Search'
        currentLocation={PAGES.dashboard.name}
      />
    )
    const title = getByTestId('flyin-window-title')
    expect(title).toBeInTheDocument()
    expect(title).toHaveTextContent('Search')
  })

  it('WILL display close button. ', () => {
    const { getByTestId } = render(
      <FlyinWindow
        isOpen={true}
        title='Search'
        currentLocation={PAGES.preProcessing.name}
      />
    )
    const closeButton = getByTestId('flyin-window-close-button')
    expect(closeButton).toBeInTheDocument()
  })

  it('WILL close the fly-in window when click on close button. ', () => {
    const onClose = jest.fn()
    const { getByTestId } = render(
      <FlyinWindow
        isOpen={true}
        title='Search'
        onClose={onClose}
        currentLocation={PAGES.preProcessing.name}
      />
    )
    const closeButton = getByTestId('flyin-window-close-button')
    expect(onClose).toHaveBeenCalledTimes(0)
    userEvent.click(closeButton)
    expect(onClose).toHaveBeenCalledTimes(1)
  })

  it('WILL have content wrap. ', () => {
    const { getByTestId } = render(
      <FlyinWindow
        isOpen={true}
        title='Search'
        currentLocation={PAGES.preProcessing.name}
      />
    )
    const contentWrap = getByTestId('flyin-window-content-wrap')
    expect(contentWrap).toBeInTheDocument()
  })
})
