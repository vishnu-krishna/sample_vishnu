import styled from 'styled-components'
import styleVars from '@anz/styles-global'
import { zIndexPriority } from 'app/utils/appUtils'

export const FlyinWindowWrap = styled.div`
  background: whitesmoke;
  box-shadow: -4px 0 12px rgba(0, 0, 0, 0.3);
  display: block;
  height: calc(100% - ${({ initTopPad }) => initTopPad}px);
  position: fixed;
  right: 0;
  width: 0;
  transition: width 250ms ease-out;
  -webkit-transform: translate3d(0, 0, 0);
  z-index: ${zIndexPriority.flyinWindow};
  &.is-open {
    width: ${({ maxWidth }) => maxWidth}px;
    max-width: 100%;
  }
`

export const FlyinWindowHeaderWrap = styled.div`
  align-items: center;
  border-bottom: 5px solid ${styleVars.color.oceanBlue};
  display: flex;
  height: 80px;
  padding: 0 28px;
`
export const FlyinWindowHeading = styled.h2`
  color: #0093d8;
  font-size: 24px;
  font-weight: 300;
  flex: 1;
  line-height: 1.5;
`

export const FlyinWindowCloseButton = styled.button`
  background: transparent;
  border: 0;
  cursor: pointer;
  padding: 0;
  opacity: 0.2;

  &:hover {
    opacity: 1;
  }
`

export const FlyinWindowContentWrap = styled.div`
  height: 100%;
`
