import React, { useEffect, useState } from 'react'
import CloseButton from '@anz/icon/dist/filled/arrows-and-symbols/cancel-fail-line'

import {
  FlyinWindowCloseButton,
  FlyinWindowContentWrap,
  FlyinWindowHeaderWrap,
  FlyinWindowHeading,
  FlyinWindowWrap
} from './flyinWindow.styles'
import { CURRENT_LOCATION_PAGE_TITLE, PAGES } from 'app/pages/constants'
import PropTypes from 'prop-types'

const FlyinWindow = ({
  title = '',
  isOpen = false,
  onClose,
  children,
  currentLocation,
  initTopPad = 0,
  maxWidth = 1200
}) => {
  const isCurrentLocationPreprocessing = currentLocation.includes(
    PAGES.preProcessing.name
  )
  const [position, setPosition] = useState(initTopPad)
  useEffect(() => {
    // TODO(Ryan): This won't be performant, add event throttling
    const scrollHandler = () => {
      setPosition(initTopPad > window.scrollY ? initTopPad - window.scrollY : 0)
    }

    window.addEventListener('scroll', scrollHandler)

    return () => {
      window.removeEventListener('scroll', scrollHandler)
    }
  })

  // NOTE: disabled click outside behaviour due to edge cases
  // present in React 16 rendering.
  // Given this feature is a "nice to have" it's been disabled for now

  // Ref to our wrapper element for `useClickOutside`
  // const wrapperRef = useRef(null)
  // Register our click to dismiss behaviour

  // useClickOutside({
  //   ref: wrapperRef,
  //   // onClickedOutside: () => onClose(false),
  //   isOpen
  // })
  if (
    !isCurrentLocationPreprocessing &&
    (title === CURRENT_LOCATION_PAGE_TITLE.DOCUMENTS ||
      title === CURRENT_LOCATION_PAGE_TITLE.COMMENTS)
  ) {
    return null
  }
  return (
    <FlyinWindowWrap
      maxWidth={maxWidth}
      initTopPad={initTopPad}
      className={isOpen && 'is-open'}
      style={{
        height: `calc(100% - ${position}px)`,
        top: `${position}px`
      }}
      // ref={wrapperRef}
    >
      <FlyinWindowHeaderWrap>
        <FlyinWindowHeading data-test-id='flyin-window-title'>
          {title}
        </FlyinWindowHeading>
        <FlyinWindowCloseButton
          onClick={() => onClose(false)}
          data-test-id='flyin-window-close-button'
        >
          <CloseButton />
        </FlyinWindowCloseButton>
      </FlyinWindowHeaderWrap>
      <FlyinWindowContentWrap data-test-id='flyin-window-content-wrap'>
        {isOpen && children}
      </FlyinWindowContentWrap>
    </FlyinWindowWrap>
  )
}
FlyinWindow.propTypes = {
  isOpen: PropTypes.bool,
  onClose: PropTypes.func,
  currentLocation: PropTypes.string.isRequired,
  initTopPad: PropTypes.number,
  maxWidth: PropTypes.number,
  children: PropTypes.node,
  title: PropTypes.any
}

export default FlyinWindow
