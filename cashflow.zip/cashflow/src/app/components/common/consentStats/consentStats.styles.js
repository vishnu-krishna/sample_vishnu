import styled from 'styled-components'
import styleVars from '@anz/styles-global'

export const ConsentStatsWrapper = styled.div`
  padding: 16px 16px;
  text-align: left;
`
export const ConsentStatsTitle = styled.label`
  padding-right: 30px;
  color: ${styleVars.color.darkGrey};
  font-weight: bold;
`
export const ConsentStatsIcon = styled.div`
  display: inline-flex;
  padding-right: 5px;
`
export const ConsentStatsIconContent = styled.label`
  padding-right: 30px;
`
