import React from 'react'
import PropTypes from 'prop-types'
import { CONSENT_STATS } from 'app/components/common/consentStats/consentStatsConfig'
import {
  ConsentStatsWrapper,
  ConsentStatsTitle,
  ConsentStatsIconContent,
  ConsentStatsIcon
} from 'app/components/common/consentStats/consentStats.styles'

export const ConsentStats = ({ consentConfigData }) => {
  const consentIconBlock = CONSENT_STATS.map(consentItem => {
    return (
      <React.Fragment key={consentItem.consentStatus}>
        <ConsentStatsIcon
          id={`consent-stats-icon-${consentItem.consentStatus}`}
          data-test-id={`consent-stats-icon-${consentItem.consentStatus}`}
        >
          {consentItem.icon}
        </ConsentStatsIcon>
        <ConsentStatsIconContent
          id={`consent-stats-content-${consentItem.consentStatus}`}
          data-test-id={`consent-stats-content-${consentItem.consentStatus}`}
        >
          {consentItem.consentStatus}:{' '}
          {(consentConfigData &&
            consentConfigData[consentItem.consentStatus]) ||
            0}
        </ConsentStatsIconContent>
      </React.Fragment>
    )
  })
  return (
    <ConsentStatsWrapper
      id='consent-stats-wrapper'
      data-test-id='consent-stats-wrapper'
    >
      <ConsentStatsTitle
        id='consent-stats-title'
        data-test-id='consent-stats-title'
      >
        Consents
      </ConsentStatsTitle>
      {consentIconBlock}
    </ConsentStatsWrapper>
  )
}

ConsentStats.propTypes = {
  consentConfigData: PropTypes.shape({
    Pending: PropTypes.number,
    Received: PropTypes.number,
    Failed: PropTypes.number,
    Expired: PropTypes.number
  }).isRequired
}
