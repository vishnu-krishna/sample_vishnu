import React from 'react'
import SuccessIcon from '@anz/icon/dist/filled/arrows-and-symbols/success'
import PendingIcon from '@anz/icon/dist/filled/arrows-and-symbols/warning-alert'
import FailureIcon from '@anz/icon/dist/filled/arrows-and-symbols/cancel-fail'
import styleVars from '@anz/styles-global'
import { CONSENT_STATUS } from 'app/pages/constants'

export const CONSENT_STATS = [
  {
    consentStatus: CONSENT_STATUS.RECEIVED,
    icon: <SuccessIcon color={styleVars.color.system.success} />
  },
  {
    consentStatus: CONSENT_STATUS.PENDING,
    icon: <PendingIcon color={styleVars.color.system.warning} />
  },
  {
    consentStatus: CONSENT_STATUS.EXPIRED,
    icon: <FailureIcon color={styleVars.color.system.error} />
  },
  {
    consentStatus: CONSENT_STATUS.FAILED,
    icon: <FailureIcon color={styleVars.color.system.error} />
  }
]
