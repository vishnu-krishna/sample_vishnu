import React from 'react'
import { storiesOf } from '@storybook/react'
import { ConsentStats } from 'app/components/common/consentStats/consentStats.component'

storiesOf('Consent Stats', module).add('Default consent stats', () => {
  return <ConsentStats id='consent-stats' consentConfigData={{ Pending: 10 }} />
})
