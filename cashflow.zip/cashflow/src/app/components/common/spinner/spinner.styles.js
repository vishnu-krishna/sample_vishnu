import AnzLotusIcon from '@anz/icon'
import styled from 'styled-components'
import { rotate, dash } from '@anz/styles-animation'

export const Loader = styled.div`
  position: relative;
  top: ${({ spinnerTop }) => spinnerTop};
  left: ${({ spinnerLeft }) => spinnerLeft};
  width: ${({ spinnerSize }) => spinnerSize}px;
  &::before {
    content: '';
    display: block;
    padding-top: 100%;
  }
  z-index: 999;
`

export const StyledSpinner = styled.svg`
  animation: ${rotate} 2s linear infinite;
  height: 100%;
  transform-origin: center center;
  width: 100%;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  z-index: 999;
`

export const StyledCircle = styled.circle`
  stroke-dasharray: 33, 200;
  stroke-dashoffset: 0;
  animation: ${dash} 1.5s ease-in-out infinite;
  stroke-linecap: round;
  stroke: ${({ color }) => color};
  z-index: 999;
`

export const Lotus = styled(AnzLotusIcon)`
  font-size: ${({ logoSize }) => logoSize}px;
  color: ${({ color }) => color};
  position: absolute;
  top: ${({ logoTop }) => logoTop}px;
  left: ${({ logoLeft }) => logoLeft}px;
  z-index: 999;
`
