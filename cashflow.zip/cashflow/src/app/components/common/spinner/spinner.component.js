import React from 'react'
import styleVars from '@anz/styles-global'
import { Loader, Lotus, StyledCircle, StyledSpinner } from './spinner.styles'
import * as uuid from 'uuid'
import { PropTypes } from 'prop-types'

export const Spinner = ({
  spinnerSize,
  spinnerLeft,
  spinnerTop,
  strokeWidth,
  logoSize,
  logoTop,
  logoLeft,
  color,
  id
}) => {
  const loaderProps = {
    spinnerSize,
    spinnerLeft,
    spinnerTop
  }
  return (
    <Loader {...loaderProps}>
      <StyledSpinner viewBox='25 25 50 50'>
        <StyledCircle
          color={color}
          className='path'
          cx='50'
          cy='50'
          r='20'
          fill='none'
          strokeWidth={strokeWidth}
          strokeMiterlimit='10'
          data-test-id={`test-${id}`}
        />
      </StyledSpinner>
      <Lotus
        logoSize={logoSize}
        logoTop={logoTop}
        logoLeft={logoLeft}
        color={color}
      />
    </Loader>
  )
}
Spinner.propTypes = {
  id: PropTypes.any,
  color: PropTypes.any,
  spinnerSize: PropTypes.any,
  spinnerLeft: PropTypes.any,
  spinnerTop: PropTypes.any,
  strokeWidth: PropTypes.any,
  logoSize: PropTypes.any,
  logoTop: PropTypes.any,
  logoLeft: PropTypes.any
}

Spinner.defaultProps = {
  id: uuid.v4(),
  color: styleVars.color.oceanBlue,
  spinnerSize: 60,
  spinnerLeft: '25%',
  spinnerTop: '25%',
  strokeWidth: 2,
  logoSize: 24,
  logoTop: 18,
  logoLeft: 18
}
