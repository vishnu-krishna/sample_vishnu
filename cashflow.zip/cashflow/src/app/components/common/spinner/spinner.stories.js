import React from 'react'
import { storiesOf } from '@storybook/react'
import { Spinner } from 'app/components/common/spinner/spinner.component'

storiesOf('Spinner ', module)
  .add('Spinner Component', () => {
    return <Spinner />
  })
  .add('Spinner Component - custom size', () => {
    return <Spinner spinnerSize={20} strokeWidth={5} logoSize={0} />
  })
