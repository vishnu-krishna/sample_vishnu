import React, { useEffect, useState } from 'react'
import {
  MonthFieldInput,
  MonthsFieldContainer,
  MonthsSymbolContainer,
  YearFieldInput,
  YearsFieldContainer,
  YearsMonthFieldWrapper,
  YearsSymbolContainer
} from 'app/components/common/yearsMonthField/yearsMonthField.styles'
import PropTypes from 'prop-types'

export const yearsMonthFieldId = 'yearsMonth-field'

const YearsMonthField = ({
  id,
  name,
  width,
  onChangeYear,
  onChangeMonth,
  years,
  months,
  readonly
}) => {
  const [yearsValue, setYearsValue] = useState('')
  const [forceYearError, setForceYearError] = useState(false)
  const [monthsValue, setMonthsValue] = useState('')
  const [forceMonthError, setForceMonthError] = useState(false)
  useEffect(() => {
    // This effect is to format the value to currency format
    // Mainly used for the pre-populating the value
    if (years !== null) validateYear(years)
    if (months !== null) validateMonth(months)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])
  const validateYear = year => {
    // validating the entered year field value it should accept only two digit number
    const yearsReg = new RegExp('^\\d{1,2}$')
    const errorStatus = yearsReg.test(year)
    setForceYearError(!errorStatus)
    setYearsValue(year)
    return errorStatus
  }
  const validateMonth = month => {
    // validating the entered Month field value it should accept only number 0 to 11
    const monthsReg = new RegExp('^([0]{0,1}[0-9]|1[01])$')
    const errorStatus = monthsReg.test(month)
    setForceMonthError(!errorStatus)
    setMonthsValue(month)
    return errorStatus
  }
  const handleYearChange = ({ target: { value } }) => {
    const enteredText = (value.replace(/\D/g, '') || '').substring(0, 2)
    if (validateYear(enteredText) && onChangeYear)
      onChangeYear(parseInt(enteredText))
  }
  const handleMonthChange = ({ target: { value } }) => {
    const enteredTextInitial = (value.replace(/\D/g, '') || '').substring(0, 2)
    const enteredText =
      enteredTextInitial.replace(
        /^(\D|([1][2-9|\D]|[2-9].))$/,
        enteredTextInitial.charAt(0)
      ) || ''
    if (validateMonth(enteredText) && onChangeMonth)
      onChangeMonth(parseInt(enteredText))
  }
  return (
    <YearsMonthFieldWrapper
      data-test-id={`${yearsMonthFieldId}-wrapper`}
      width={width}
    >
      <YearsFieldContainer data-test-id={`${yearsMonthFieldId}-year-container`}>
        <YearFieldInput
          type='text'
          name={`${name}-year`}
          id={`${id}-year`}
          data-test-id={`${id}-${yearsMonthFieldId}-year-id`}
          step='1'
          value={yearsValue}
          onChange={handleYearChange}
          disabled={readonly}
          forceError={forceYearError}
          readonly={readonly}
          maxLength={2}
        />
        <YearsSymbolContainer>Yrs</YearsSymbolContainer>
      </YearsFieldContainer>
      <MonthsFieldContainer
        data-test-id={`${yearsMonthFieldId}-month-container`}
      >
        <MonthFieldInput
          name={`${name}-month`}
          id={`${id}-month`}
          data-test-id={`${id}-${yearsMonthFieldId}-month-id`}
          type='text'
          step='1'
          value={monthsValue}
          onChange={handleMonthChange}
          disabled={readonly}
          forceError={forceMonthError}
          readonly={readonly}
          maxLength={2}
        />
        <MonthsSymbolContainer>Mts</MonthsSymbolContainer>
      </MonthsFieldContainer>
    </YearsMonthFieldWrapper>
  )
}

YearsMonthField.propTypes = {
  id: PropTypes.string.isRequired,
  name: PropTypes.string,
  width: PropTypes.string,
  onChange: PropTypes.func,
  readonly: PropTypes.bool,
  years: PropTypes.number,
  months: PropTypes.number,
  onChangeYear: PropTypes.any,
  onChangeMonth: PropTypes.any
}

YearsMonthField.defaultProps = {
  name: 'yearsMonth-field-name',
  readonly: false
}

export default YearsMonthField
