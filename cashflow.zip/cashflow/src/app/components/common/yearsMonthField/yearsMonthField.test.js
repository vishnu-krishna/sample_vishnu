import { render } from '@testing-library/react'
import React from 'react'
import YearsMonthField from 'app/components/common/yearsMonthField/yearsMonthField.component'
import JestMock from 'jest-mock'
import userEvent from '@testing-library/user-event'

describe('YearsMonth field Component', () => {
  test('YearsMonth field component fields to be displayed with default width', () => {
    const { getByTestId } = render(
      <YearsMonthField
        id='yearsMonthFieldId'
        name='yearsMonthFieldName'
        onChange={JestMock.fn()}
        years={1}
        months={2}
      />
    )
    const yearsFieldElement = getByTestId(
      'yearsMonthFieldId-yearsMonth-field-year-id'
    )
    const yearsMonthFieldWrapper = getByTestId('yearsMonth-field-wrapper')
    expect(yearsFieldElement).toBeInTheDocument()
    expect(yearsFieldElement.value).toBe('1')
    const monthFieldElement = getByTestId(
      'yearsMonthFieldId-yearsMonth-field-month-id'
    )
    expect(monthFieldElement).toBeInTheDocument()
    expect(monthFieldElement.value).toBe('2')
    expect(yearsMonthFieldWrapper).toHaveStyleRule('width', '100%')
  })
  test('YearsMonth field component fields to be displayed with custom width', () => {
    const { getByTestId } = render(
      <YearsMonthField
        id='yearsMonthFieldId'
        name='yearsMonthFieldName'
        onChange={JestMock.fn()}
        years={1}
        months={2}
        width='20%'
      />
    )
    const yearsFieldElement = getByTestId(
      'yearsMonthFieldId-yearsMonth-field-year-id'
    )
    const yearsMonthFieldWrapper = getByTestId('yearsMonth-field-wrapper')
    expect(yearsFieldElement).toBeInTheDocument()
    expect(yearsFieldElement.value).toBe('1')
    expect(yearsFieldElement).not.toHaveStyleRule('border-color')
    const monthFieldElement = getByTestId(
      'yearsMonthFieldId-yearsMonth-field-month-id'
    )
    expect(monthFieldElement).toBeInTheDocument()
    expect(monthFieldElement.value).toBe('2')
    expect(yearsFieldElement).not.toHaveStyleRule('border-color')
    expect(yearsMonthFieldWrapper).toHaveStyleRule('width', '20%')
  })
  it('should trigger the onchange event on a change of yearsMonth field', () => {
    const { getByTestId } = render(
      <YearsMonthField
        id='yearsMonthFieldId'
        name='yearsMonthFieldName'
        onChange={JestMock.fn()}
        years={1}
        months={2}
      />
    )
    const yearsFieldElement = getByTestId(
      'yearsMonthFieldId-yearsMonth-field-year-id'
    )
    userEvent.clear(yearsFieldElement)
    userEvent.type(yearsFieldElement, '10')

    expect(yearsFieldElement.value).toBe('10')
    const monthFieldElement = getByTestId(
      'yearsMonthFieldId-yearsMonth-field-month-id'
    )
    userEvent.clear(monthFieldElement)
    userEvent.type(monthFieldElement, '11')
    expect(monthFieldElement.value).toBe('11')
    userEvent.clear(yearsFieldElement)
    userEvent.type(yearsFieldElement, '$%#')
    expect(yearsFieldElement).toHaveStyleRule('border-color: #D73B33;')
    userEvent.clear(monthFieldElement)
    userEvent.type(monthFieldElement, '$%#')
    expect(monthFieldElement).toHaveStyleRule('border-color: #D73B33;')
    userEvent.clear(yearsFieldElement)
    expect(yearsFieldElement).toHaveStyleRule('border-color: #D73B33;')
    userEvent.clear(monthFieldElement)

    expect(monthFieldElement).toHaveStyleRule('border-color: #D73B33;')
  })
  it('YearsMonth field with editable set as true by default and passing value to be shown', () => {
    const { getByTestId } = render(
      <YearsMonthField
        id='yearsMonthFieldId'
        name='yearsMonthFieldName'
        onChange={JestMock.fn()}
        years={10}
        months={7}
      />
    )
    const yearsFieldElement = getByTestId(
      'yearsMonthFieldId-yearsMonth-field-year-id'
    )
    expect(yearsFieldElement.value).toBe('10')
    const monthFieldElement = getByTestId(
      'yearsMonthFieldId-yearsMonth-field-month-id'
    )
    expect(monthFieldElement.value).toBe('7')
  })
  it('YearsMonth field with editable false and value being passed to the component to be shown', () => {
    const { getByTestId } = render(
      <YearsMonthField
        id='yearsMonthFieldId'
        name='yearsMonthFieldName'
        onChange={JestMock.fn()}
        years={10}
        months={5}
        readonly
      />
    )
    const yearsFieldElement = getByTestId(
      'yearsMonthFieldId-yearsMonth-field-year-id'
    )
    expect(yearsFieldElement.value).toBe('10')
    expect(yearsFieldElement).toBeDisabled()
    const monthFieldElement = getByTestId(
      'yearsMonthFieldId-yearsMonth-field-month-id'
    )
    expect(monthFieldElement.value).toBe('5')
    expect(monthFieldElement).toBeDisabled()
  })
  it('Year input field should only accept numbers with max scope of 2 digit. ', () => {
    const { getByTestId } = render(
      <YearsMonthField
        id='yearsMonthFieldId'
        name='yearsMonthFieldName'
        onChange={JestMock.fn()}
        years={0}
        months={5}
        readonly
      />
    )
    const yearsFieldElement = getByTestId(
      'yearsMonthFieldId-yearsMonth-field-year-id'
    )
    userEvent.type(yearsFieldElement, '@9876')
    expect(yearsFieldElement.value).toBe('0')
    userEvent.type(yearsFieldElement, 'abc1@23')
    expect(yearsFieldElement.value).toBe('0')
  })

  it('Month input field should only accept numbers within range of 0 to 11. ', () => {
    const { getByTestId } = render(
      <YearsMonthField
        id='yearsMonthFieldId'
        name='yearsMonthFieldName'
        onChange={JestMock.fn()}
        years={0}
        months={5}
        readonly
      />
    )
    const monthFieldElement = getByTestId(
      'yearsMonthFieldId-yearsMonth-field-month-id'
    )
    userEvent.type(monthFieldElement, 'abc1a034')
    expect(monthFieldElement.value).toBe('5')
    userEvent.type(monthFieldElement, '1abc123')
    expect(monthFieldElement.value).not.toBe('1abc123')
  })
})
