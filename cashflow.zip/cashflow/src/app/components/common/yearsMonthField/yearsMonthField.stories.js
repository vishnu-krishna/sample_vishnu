import React from 'react'
import { storiesOf } from '@storybook/react'
import YearsMonthField from './yearsMonthField.component'

storiesOf('YearsMonth Field', module)
  .add('YearsMonth field with default mode', () => (
    <YearsMonthField name='name' id='id' />
  ))
  .add(
    'YearsMonth field with value pre-populated without field being disabled',
    () => <YearsMonthField name='name' id='id' years={10} months={1} />
  )
  .add(
    'YearsMonth field with value pre-populated with field being disabled',
    () => <YearsMonthField name='name' id='id' years={10} months={1} readonly />
  )
