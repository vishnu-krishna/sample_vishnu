import styled from 'styled-components'
import styleVars from '@anz/styles-global'

export const YearsMonthFieldWrapper = styled.div`
  width: ${props => (props.width ? props.width : '100%')};
  display: flex;
`
export const YearsFieldContainer = styled.div`
  display: flex;
`
export const YearFieldInput = styled.input`
  width: 100%;
  border: 1px solid ${styleVars.color.lightGrey};
  border-radius: 4px;
  outline: none;
  box-sizing: border-box;
  height: 44px;
  margin: 8px 0;
  ${props =>
    props.forceError ? `border-color:${styleVars.color.system.error}` : ''};
  ${props =>
    props.readonly ? `background-color:${styleVars.color.greyscale.cloud}` : ''}
  padding: 5px 10px;
  ::-webkit-inner-spin-button,
  ::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }
  ::-moz-inner-spin-button,
  ::-moz-outer-spin-button {
    -moz-appearance: none;
    margin: 0;
  }
  ::-o-inner-spin-button,
  ::-o-outer-spin-button {
    -o-appearance: none;
    margin: 0;
  }
  ::-ms-inner-spin-button,
  ::-ms-outer-spin-button {
    -ms-appearance: none;
    margin: 0;
  }
`

export const MonthsFieldContainer = styled.div`
  display: flex;
`

export const MonthFieldInput = styled.input`
  width: 100%;
  border: 1px solid ${styleVars.color.lightGrey};
  border-radius: 4px;
  outline: none;
  box-sizing: border-box;
  ${props =>
    props.forceError ? `border-color:${styleVars.color.system.error}` : ''};
  ${props =>
    props.readonly
      ? `background-color:${styleVars.color.greyscale.cloud}`
      : ''};
  margin: 8px 0;
  padding: 5px 10px;
  ::-webkit-inner-spin-button,
  ::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }
  ::-moz-inner-spin-button,
  ::-moz-outer-spin-button {
    -moz-appearance: none;
    margin: 0;
  }
  ::-o-inner-spin-button,
  ::-o-outer-spin-button {
    -o-appearance: none;
    margin: 0;
  }
  ::-ms-inner-spin-button,
  ::-ms-outer-spin-button {
    -ms-appearance: none;
    margin: 0;
  }
`

export const YearsSymbolContainer = styled.div`
  right: 0;
  top: 7px;
  padding: 8px 8px;
  color: ${styleVars.color.grayscale60};
  align-self: center;
`

export const MonthsSymbolContainer = styled.div`
  right: 0;
  top: 7px;
  padding: 8px 8px;
  color: ${styleVars.color.grayscale60};
  align-self: center;
`
