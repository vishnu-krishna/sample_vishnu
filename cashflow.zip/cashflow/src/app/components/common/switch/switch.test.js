import { render } from '@testing-library/react'
import React from 'react'
import { Switch } from 'app/components/common/switch/switch.component'
import userEvent from '@testing-library/user-event'

describe('Switch Component', () => {
  const idYes = 'test-switch-switch-group_Yes_button'
  const idNo = 'test-switch-switch-group_No_button'

  it('should render correctly', () => {
    let onChange = jest.fn()

    const { asFragment } = render(
      <Switch id='test-switch' onChange={onChange} />
    )

    expect(asFragment()).toMatchSnapshot()
  })

  it('should fire onCall function on change of switch values', () => {
    let onChange = jest.fn()

    const { getByTestId } = render(
      <Switch id='test-switch' onChange={onChange} />
    )

    const buttonYes = getByTestId(idYes)
    const buttonNo = getByTestId(idNo)
    userEvent.click(buttonYes)
    userEvent.click(buttonNo)
    expect(onChange).toHaveBeenCalledTimes(2)
  })
})
