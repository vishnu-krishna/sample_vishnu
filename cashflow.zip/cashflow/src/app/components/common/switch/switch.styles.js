import styled from 'styled-components'
import styleVars from '@anz/styles-global'

export const SwitchWrapper = styled.div`
  vertical-align: middle;
  width: ${props => (props.width ? props.width : '100%')};
  white-space: nowrap;
  padding: ${props => (props.padding ? props.padding : 'unset')};
  line-height: 44px;

  legend {
    display: none;
  }

  fieldset > div > div {
    padding: 0;
  }

  label {
    border: ${({ error, disabled }) =>
      disabled
        ? `1px solid ${styleVars.color.lightGrey}`
        : error && `1px solid ${styleVars.color.system.error}`};
    color: ${({ disabled }) => disabled && styleVars.color.labelGrey};
  }
`
