import { CONSENT_ACTION } from 'app/components/preProcessing/manageConsent/consentConstants'

export const switchValues = {
  YES: 'Yes',
  NO: 'No',
  NOT_SELECTED: ''
}

export const toBoolean = (value, reverse = false) => {
  if (reverse) {
    return value === switchValues.YES
      ? false
      : value === switchValues.NO
      ? true
      : null
  }
  return value === switchValues.YES
    ? true
    : value === switchValues.NO
    ? false
    : null
}
export const toYesNo = (value, reverse = false) => {
  if (reverse) {
    return value === true
      ? switchValues.NO
      : value === false
      ? switchValues.YES
      : switchValues.NOT_SELECTED
  }
  return value === true
    ? switchValues.YES
    : value === false
    ? switchValues.NO
    : switchValues.NOT_SELECTED
}
export const toAddRemove = value => {
  return value === switchValues.YES
    ? CONSENT_ACTION.ADD
    : value === switchValues.NO
    ? CONSENT_ACTION.REMOVE
    : null
}
