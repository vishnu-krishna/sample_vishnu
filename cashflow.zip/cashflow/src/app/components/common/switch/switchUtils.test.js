import { toYesNo, toBoolean, toAddRemove } from './switchUtils'

describe('Switch Utils', () => {
  const tests1 = [
    { input: true, output: 'Yes' },
    { input: false, output: 'No' },
    { input: '', output: '' }
  ]
  tests1.forEach(values => {
    test(`toYesNo should return ${values.output} when input is ${
      values.input
    }`, () => {
      const actualOutput = toYesNo(values.input)
      expect(actualOutput).toBe(values.output)
    })
  })

  const tests2 = [
    { input: 'Yes', output: true },
    { input: 'No', output: false },
    { input: '', output: null }
  ]
  tests2.forEach(values => {
    test(`toBoolean should return ${values.output} when input is ${
      values.input
    }`, () => {
      const actualOutput = toBoolean(values.input)
      expect(actualOutput).toBe(values.output)
    })
  })

  // //These below tests to check if reverse parameter is true (by default reverse is false)
  const tests3 = [
    { input: true, output: 'No' },
    { input: false, output: 'Yes' },
    { input: '', output: '' }
  ]
  tests3.forEach(values => {
    test(`toYesNo should return ${values.output} when input is ${
      values.input
    } and reverse is ${true}`, () => {
      const actualOutput = toYesNo(values.input, true)
      expect(actualOutput).toBe(values.output)
    })
  })

  const tests4 = [
    { input: 'Yes', output: false },
    { input: 'No', output: true },
    { input: '', output: null }
  ]
  tests4.forEach(values => {
    test(`toBoolean should return ${values.output} when input is ${
      values.input
    } and reverse is ${true}`, () => {
      const actualOutput = toBoolean(values.input, true)
      expect(actualOutput).toBe(values.output)
    })
  })

  const tests5 = [
    { input: 'Yes', output: 'add' },
    { input: 'No', output: 'remove' },
    { input: '', output: null }
  ]
  tests5.forEach(values => {
    test(`toAddRemove should return ${values.output} when input is ${
      values.input
    }`, () => {
      const actualOutput = toAddRemove(values.input)
      expect(actualOutput).toBe(values.output)
    })
  })
})
