import React, { useState, useEffect } from 'react'
import RadioGroup from '@anz/radio-group'
import PropTypes from 'prop-types'
import { SwitchWrapper } from 'app/components/common/switch/switch.styles'
import { switchValues } from './switchUtils'

export const Switch = ({
  id,
  onChange,
  value,
  width,
  padding,
  disabled = false,
  error = false,
  disabledSwitchValue = false
}) => {
  const [selectedValue, setSelectedValue] = useState(value)

  useEffect(() => {
    setSelectedValue(value)
  }, [value])

  const radioButtonDetails = [
    { label: 'Yes', value: switchValues.YES },
    { label: 'No', value: switchValues.NO }
  ]

  return (
    <SwitchWrapper
      width={width}
      padding={padding}
      data-test-id={`${id}-switch`}
      data-input-type='switch'
      error={error}
      disabled={disabled}
    >
      <RadioGroup
        name={`${id}-switch-group`}
        onChange={value => {
          if (!disabledSwitchValue) {
            setSelectedValue(value)
          }
          onChange(value)
        }}
        value={selectedValue}
        type='radio-group'
        appearance='segment-control'
        id={`${id}-switch-group`}
        desktopPerLine={2}
        laptopPerLine={2}
        tabletPerLine={2}
        mobilePerLine={2}
        buttons={radioButtonDetails}
        disabled={disabled}
      />
    </SwitchWrapper>
  )
}

Switch.propTypes = {
  id: PropTypes.string.isRequired,
  onChange: PropTypes.func,
  value: PropTypes.string,
  width: PropTypes.string,
  padding: PropTypes.string,
  disabled: PropTypes.bool,
  error: PropTypes.bool,
  disabledSwitchValue: PropTypes.bool
}
