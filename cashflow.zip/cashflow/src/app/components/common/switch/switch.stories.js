import React from 'react'
import { storiesOf } from '@storybook/react'
import { Switch } from './switch.component'

storiesOf('Switch Button', module)
  .add('Switch button', () => {
    return <Switch id='switch-button-id' />
  })
  .add('Disabled switch button', () => {
    return <Switch id='switch-button-id' disabled />
  })
