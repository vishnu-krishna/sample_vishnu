import { render } from '@testing-library/react'
import React from 'react'
import { InterestField } from 'app/components/common/interestField/interestField.component'
import { Provider } from 'react-redux'
import store from 'store'
import userEvent from '@testing-library/user-event'

describe('Interest field Component', () => {
  test('Interest field component fields to be displayed with default width', () => {
    const { getByTestId } = render(
      <InterestField
        id='interestFieldId'
        name='interestFieldName'
        onChange={() => {}}
      />
    )
    const interestFieldElement = getByTestId(
      'interestFieldId-interest-field-id'
    )
    const interestFieldWrapper = getByTestId('interest-field-wrapper')
    expect(interestFieldElement).toBeInTheDocument()
    expect(interestFieldWrapper).toHaveStyleRule('width', '100%')
  })
  test('Interest field component fields to be displayed with custom width', () => {
    const { getByTestId } = render(
      <InterestField
        id='interestFieldId'
        name='interestFieldName'
        onChange={() => {}}
        width='10%'
      />
    )
    const interestFieldElement = getByTestId(
      'interestFieldId-interest-field-id'
    )
    const interestFieldWrapper = getByTestId('interest-field-wrapper')
    expect(interestFieldElement).toBeInTheDocument()
    expect(interestFieldWrapper).toHaveStyleRule('width', '10%')
    expect(interestFieldElement).toHaveStyle('border-color: none;')
  })
  test('Interest field component fields to be displayed with forceError is thrown', () => {
    const { getByTestId } = render(
      <InterestField
        id='interestFieldId'
        name='interestFieldName'
        onChange={() => {}}
        width='10%'
        forceError={true}
      />
    )
    const interestFieldElement = getByTestId(
      'interestFieldId-interest-field-id'
    )
    const interestFieldWrapper = getByTestId('interest-field-wrapper')
    expect(interestFieldElement).toBeInTheDocument()
    expect(interestFieldWrapper).toHaveStyleRule('width', '10%')
  })
  it('should trigger the onchange event on a tap of interest filed', () => {
    const { getByTestId } = render(
      <Provider store={store}>
        <InterestField
          id='interestFieldId'
          name='interestFieldName'
          onChange={() => {}}
          width='10%'
        />
      </Provider>
    )
    const interestFieldElement = getByTestId(
      'interestFieldId-interest-field-id'
    )
    userEvent.type(interestFieldElement, '12.33')
    expect(interestFieldElement.value).toBe('12.33')
    userEvent.type(interestFieldElement, 'aaaa')
    expect(interestFieldElement).toHaveStyleRule('border-color: #D73B33;')
  })
})
