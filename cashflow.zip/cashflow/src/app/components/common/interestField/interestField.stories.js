import React from 'react'
import { storiesOf } from '@storybook/react'
import { InterestField } from './interestField.component'

storiesOf('Interest Field', module).add('Interest field', () => (
  <InterestField name='name' id='id' />
))
