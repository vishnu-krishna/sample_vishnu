import styled from 'styled-components'
import NumberFormat from 'react-number-format'
import styleVars from '@anz/styles-global'

export const InterestFieldWrapper = styled.div`
  width: ${props => (props.width ? props.width : '100%')};
  display: flex;
  align-items: center;
`
export const InterestFieldContainer = styled.div`
  position: relative;
`
export const InterestInput = styled(NumberFormat)`
  width: 100%;
  border: 1px solid ${styleVars.color.lightGrey};
  border-radius: 4px;
  margin: 8px 0;
  outline: none;
  height: 44px;
  padding: 8px;
  box-sizing: border-box;
  border-color: ${props =>
    props.error ? styleVars.color.system.error : 'none'};
  ${props =>
    props.disabled ? `background-color:${styleVars.color.greyscale.cloud}` : ''}
  ::-webkit-inner-spin-button,
  ::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }
  ::-moz-inner-spin-button,
  ::-moz-outer-spin-button {
    -moz-appearance: none;
    margin: 0;
  }
  ::-o-inner-spin-button,
  ::-o-outer-spin-button {
    -o-appearance: none;
    margin: 0;
  }
  ::-ms-inner-spin-button,
  ::-ms-outer-spin-button {
    -ms-appearance: none;
    margin: 0;
  }
`
export const InterestSymbolContainer = styled.div`
  position: relative;
  margin-left: 2px;
  color: ${styleVars.color.grayscale60};
`
