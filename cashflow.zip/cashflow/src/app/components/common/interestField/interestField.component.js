import React, { useState, useEffect } from 'react'
import {
  InterestFieldWrapper,
  InterestFieldContainer,
  InterestSymbolContainer,
  InterestInput
} from 'app/components/common/interestField/interestField.component.styles'
import PropTypes from 'prop-types'
export const interestFieldId = 'interest-field'

const MINIMUM_INTEREST_RATE = 0
const MAXIMUM_INTEREST_RATE = 100

export const InterestField = ({
  id,
  name = 'interest-field-name',
  width,
  readonly = false,
  onChange,
  places = 2,
  value = ''
}) => {
  const [interestValue, setInterestValue] = useState(value)
  const [forceError, setForceError] = useState(false)

  useEffect(() => {
    // This effect is mainly used for the pre-populating the value
    if (value !== null) validateInterest(value)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    validateInterest(interestValue)
  }, [interestValue])

  const validateInterest = interest => {
    // validating the entered interest field value it should accept only decimal places number
    var interestReg = new RegExp('^\\d{1,2}(\\.\\d{1,2})?$')
    const errorStatus = interestReg.test(interest)
    setForceError(!errorStatus)
    return errorStatus
  }

  const handleChange = ({ target: { value } }) => {
    const enteredText = value || ''
    setInterestValue(enteredText)
  }

  const handleBlur = () => {
    const interestValueNumber = Number(interestValue)
    setInterestValue(interestValueNumber)
    if (onChange) {
      onChange(interestValueNumber)
    }
  }

  return (
    <InterestFieldWrapper
      data-test-id={`${interestFieldId}-wrapper`}
      width={width}
    >
      <InterestFieldContainer data-test-id={`${interestFieldId}-container`}>
        <InterestInput
          name={name}
          id={id}
          data-test-id={`${id}-${interestFieldId}-id`}
          value={interestValue}
          onChange={handleChange}
          disabled={readonly}
          onBlur={handleBlur}
          decimalScale={places}
          error={forceError ? 1 : 0}
          isAllowed={({ value, floatValue }) => {
            return (
              value === '' ||
              (floatValue >= MINIMUM_INTEREST_RATE &&
                floatValue <= MAXIMUM_INTEREST_RATE)
            )
          }}
        />
      </InterestFieldContainer>
      <InterestSymbolContainer>%</InterestSymbolContainer>
    </InterestFieldWrapper>
  )
}

InterestField.propTypes = {
  id: PropTypes.string.isRequired,
  name: PropTypes.string,
  width: PropTypes.string,
  readonly: PropTypes.bool,
  onChange: PropTypes.func,
  places: PropTypes.number,
  value: PropTypes.oneOfType([PropTypes.string, PropTypes.number])
}
