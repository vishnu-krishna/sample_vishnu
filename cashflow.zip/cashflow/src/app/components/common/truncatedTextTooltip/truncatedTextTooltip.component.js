import React, { useState } from 'react'
import PropTypes from 'prop-types'
import ReactTooltip from 'react-tooltip'
import uuid from 'uuid'
import { WrapperTruncatedText } from './truncatedTextTooltip.styles'

export const isOverflowed = e => e.target.offsetWidth < e.target.scrollWidth

export const TruncatedTextTooltip = ({
  id = uuid.v1(),
  position = 'top',
  type = 'light',
  effect = 'solid',
  text,
  useInline
}) => {
  const [showTooltip, setShowTooltip] = useState(false)

  return (
    <WrapperTruncatedText
      id={`${id}-wrapper`}
      useInline={useInline}
      data-for={id}
      data-tip={text}
      data-test-id='textToolTip'
      onMouseEnter={e => setShowTooltip(isOverflowed(e))}
      onMouseLeave={() => setShowTooltip(false)}
    >
      {text}
      <ReactTooltip
        id={id}
        place={position}
        type={type}
        effect={effect}
        disable={!showTooltip}
      />
    </WrapperTruncatedText>
  )
}

TruncatedTextTooltip.propTypes = {
  id: PropTypes.string,
  text: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  position: PropTypes.string,
  type: PropTypes.string,
  effect: PropTypes.string,
  useInline: PropTypes.any
}
