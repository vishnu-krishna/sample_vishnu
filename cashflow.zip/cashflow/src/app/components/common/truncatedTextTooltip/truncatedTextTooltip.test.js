import React from 'react'
import { queryByAttribute, render } from '@testing-library/react'
import { TruncatedTextTooltip } from './truncatedTextTooltip.component.js'
import { isOverflowed } from './truncatedTextTooltip.component'
import userEvent from '@testing-library/user-event'

const getById = queryByAttribute.bind(null, 'id')

/**
 * Not able to fully test the tooltip, as react-test-library is using jsdom and
 * does not support layouting, therefore we are not able to create snapshot test
 * to cover actual tooltip show/hidden
 *
 * REFL: https://github.com/testing-library/react-testing-library/issues/353
 *
 */

describe('TruncatedTextTooltip', () => {
  it('TruncatedTextTooltip with default props', () => {
    const { asFragment } = render(
      <TruncatedTextTooltip text='Tooltip message to show' />
    )
    expect(asFragment()).toMatchSnapshot()
  })

  it('TruncatedTextTooltip with custom Properties', () => {
    const { asFragment } = render(
      <TruncatedTextTooltip
        id='mytest-1'
        text='Tooltip message to show'
        position='bottom'
        type='dark'
        effect='solid'
      />
    )
    expect(asFragment()).toMatchSnapshot()
  })

  it('TruncatedTextTooltip call handleHoverOn to show tooltip', async () => {
    const testId = 'mytest-1'
    const wrappedElement = render(
      <div
        style={{
          width: '50px',
          whiteSpace: 'nowrap',
          position: 'absolute'
        }}
      >
        <TruncatedTextTooltip
          id={testId}
          text={'This is a test with truncation'}
          {...TruncatedTextTooltip.defaultProps}
        />
      </div>
    )

    let target = await getById(wrappedElement.container, `${testId}-wrapper`)
    userEvent.hover(target)
    userEvent.unhover(target)
    expect(wrappedElement.asFragment()).toMatchSnapshot()
  })

  describe('isOverflow', function () {
    it('should return TRUE when text is longer than element width', () => {
      let mock = {
        target: {
          offsetWidth: 10,
          scrollWidth: 20
        }
      }
      expect(isOverflowed(mock)).toBe(true)
    })

    it('should return FALSE when text is shorter than element width', () => {
      let mock = {
        target: {
          offsetWidth: 50,
          scrollWidth: 20
        }
      }
      expect(isOverflowed(mock)).toBe(false)
    })
  })
})
