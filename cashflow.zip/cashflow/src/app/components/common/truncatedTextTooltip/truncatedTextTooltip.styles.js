import styled, { css } from 'styled-components'

export const WrapperTruncatedText = styled.div`
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow: hidden;

  ${({ useInline }) =>
    useInline &&
    css`
      display: inline-block;
      max-width: 20em;
      vertical-align: bottom;
    `}

  .truncated {
    text-overflow: ellipsis;
    overflow: hidden;
  }

  .__react_component_tooltip.type-light {
    min-width: 250px;
    max-width: 500px;
    white-space: normal;
    opacity: 1 !important;
    font-size: 16px;
    background-color: #fff;
    border-radius: 3px;
    box-shadow: 0 1px 5px #ccc;
    background-clip: padding-box;
    border: 1px solid #ccc;
    font-weight: normal;
    line-height: 1;
    color: #333 !important;
    padding: 15px;
    overflow-wrap: break-word;
  }
`
