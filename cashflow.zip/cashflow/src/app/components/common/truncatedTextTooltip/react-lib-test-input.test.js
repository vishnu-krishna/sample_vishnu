import React from 'react'
import { render } from '@testing-library/react'
import userEvent from '@testing-library/user-event'

class CostInput extends React.Component {
  state = {
    value: ''
  }

  removeDollarSign = value => (value[0] === '$' ? value.slice(1) : value)
  getReturnValue = value => (value === '' ? '' : `$${value}`)
  handleChange = ev => {
    ev.preventDefault()
    const inputtedValue = ev.currentTarget.value
    const noDollarSign = this.removeDollarSign(inputtedValue)
    if (isNaN(noDollarSign)) return
    this.setState({ value: this.getReturnValue(noDollarSign) })
  }

  render () {
    return (
      <input
        value={this.state.value}
        aria-label='cost-input'
        onChange={this.handleChange}
        onMouseEnter={() => {
          this.setState({ value: '50%' })
        }}
      />
    )
  }
}

const setup = () => {
  const utils = render(<CostInput />)
  const input = utils.getByLabelText('cost-input')
  return {
    input,
    ...utils
  }
}

test('It should keep a $ in front of the input', () => {
  const { input } = setup()
  userEvent.clear(input)
  userEvent.type(input, '23', { skipClick: true })
  expect(input.value).toBe('$23')
  userEvent.hover(input)
  expect(input.value).toBe('50%')
})
test('It should allow a $ to be in the input when the value is changed', () => {
  const { input } = setup()
  userEvent.clear(input)
  userEvent.type(input, '$23.0', { skipClick: true })
  expect(input.value).toBe('$23.0')
})

test('It should not allow letters to be inputted', () => {
  const { input } = setup()
  expect(input.value).toBe('') // empty before
  userEvent.type(input, 'Good Day', { skipClick: true })
  userEvent.clear(input)
  expect(input.value).toBe('') //empty after
})

test('It should allow the $ to be deleted', () => {
  const { input } = setup()
  userEvent.clear(input)
  userEvent.type(input, '23', { skipClick: true })
  expect(input.value).toBe('$23') // need to make a change so React registers "" as a change
  userEvent.clear(input)
  expect(input.value).toBe('')
})
