import React from 'react'
import { storiesOf } from '@storybook/react'
import { TruncatedTextTooltip } from './truncatedTextTooltip.component.js'

storiesOf('Truncated Text Tooltip', module)
  .add('With truncation', () => (
    <div
      style={{
        width: '130px',
        whiteSpace: 'nowrap',
        marginLeft: '5px',
        marginTop: '100px'
      }}
    >
      <TruncatedTextTooltip
        text={'This is a test with  truncation'}
        {...TruncatedTextTooltip.defaultProps}
      />
    </div>
  ))

  .add('Without truncation', () => (
    <div
      style={{
        width: '250px',
        whiteSpace: 'nowrap',
        marginLeft: '5px',
        marginTop: '100px'
      }}
    >
      <TruncatedTextTooltip
        text={'This is a test with no truncation'}
        {...TruncatedTextTooltip.defaultProps}
      />
    </div>
  ))
