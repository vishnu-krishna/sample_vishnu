import React from 'react'
import { render } from '@testing-library/react'
import { Warning } from './warning.component'

describe('Warning', () => {
  test('Warning component should match snapshot', () => {
    const { wrapper } = render(
      <Warning>
        <span>This is a warning</span>
      </Warning>
    )

    expect(wrapper).toMatchSnapshot()
  })
})
