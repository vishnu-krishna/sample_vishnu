import styled, { css } from 'styled-components'
import styleVars from '@anz/styles-global'

export const WARNING_COLOR = '#df7a00'

const FlexCentered = css`
  display: flex;
  align-items: center;
  justify-content: center;
`

export const WarningContainer = styled.div`
  display: flex;
  flex-direction: row;
  font-size: ${styleVars.dimensions.font16};
  color: ${WARNING_COLOR};
  padding-top: ${({ paddingTop }) => paddingTop};
  min-height: ${({ minHeight }) => minHeight};
`

export const IconContainer = styled.div`
  ${FlexCentered};
  min-height: ${({ minHeight }) => minHeight};
  margin-right: ${({ marginRight }) => marginRight};
`

export const ContentContainer = styled.div`
  ${FlexCentered};
  color: ${({ color }) => color}
  font-size: ${({ size }) => size}
`

export const WarningIconRoundStyled = styled.div`
  border-radius: 100%;
  background-color: ${styleVars.color.warningIcon};

  width: ${({ size }) => size};
  height: ${({ size }) => size};
  color: #fff;
  line-height: ${({ size }) => size};
  font-size: ${({ size }) => size};
  text-align: center;
`
