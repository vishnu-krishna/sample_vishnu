import React from 'react'
import WarningIcon from '@anz/icon/dist/filled/arrows-and-symbols/warning-alert'
import styleVars from '@anz/styles-global'
import PropTypes from 'prop-types'
import {
  ContentContainer,
  IconContainer,
  WARNING_COLOR,
  WarningContainer
} from './warning.styles'
import { WarningIconRoundStyled } from 'app/components/common/warning/warning.styles'

export const warningTestId = 'warning'

export const Warning = ({
  icon = {},
  text = {},
  paddingTop = styleVars.dimensions.gap20,
  children
}) => {
  const {
    iconSize = styleVars.dimensions.height32,
    iconType = Warning.iconType.default,
    iconMinHeight = styleVars.dimensions.height60,
    iconMarginRight = styleVars.dimensions.gap20
  } = icon
  const { textColor = 'inherit', textSize = 'inherit' } = text
  return (
    <WarningContainer data-test-id={warningTestId}>
      <IconContainer
        minHeight={iconMinHeight}
        marginRight={iconMarginRight}
        paddingTop={paddingTop}
      >
        {iconType === Warning.iconType.round ? (
          <WarningIconRound iconSize={iconSize} />
        ) : (
          <WarningIcon color={WARNING_COLOR} size={iconSize} />
        )}
      </IconContainer>
      <ContentContainer color={textColor} size={textSize}>
        {children}
      </ContentContainer>
    </WarningContainer>
  )
}

Warning.iconType = {
  default: 'default',
  round: 'round'
}

Warning.propTypes = {
  icon: PropTypes.shape({
    iconType: PropTypes.oneOf(Object.keys(Warning.iconType)),
    iconSize: PropTypes.string,
    iconMinHeight: PropTypes.string,
    iconMarginRight: PropTypes.string
  }),
  text: PropTypes.shape({
    textSize: PropTypes.string,
    textColor: PropTypes.string
  }),
  paddingTop: PropTypes.string,
  children: PropTypes.any
}
/* eslint-disable react/prop-types */
const WarningIconRound = ({ iconSize }) => {
  return <WarningIconRoundStyled size={iconSize}>!</WarningIconRoundStyled>
}
/* eslint-disable react/prop-types */
