import { storiesOf } from '@storybook/react'
import React from 'react'
import { Warning } from './warning.component'

storiesOf('Warning Component', module).add('Warning', () => (
  <Warning>
    <span>
      <strong>This application is currently assigned to BANKERFULLNAME.</strong>{' '}
      Please check with BANKERFULLNAME before self-assigning this application to
      prevent unsaved changes from being lost.
    </span>
  </Warning>
))
