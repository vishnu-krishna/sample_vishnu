import React from 'react'
import { storiesOf } from '@storybook/react'
import CurrencyField from './currencyField.component'

storiesOf('Currency Field', module)
  .add('Currency field with default editable and with no default value', () => (
    <CurrencyField name='name' id='id' />
  ))
  .add('Currency field with default editable and with default value', () => (
    <CurrencyField name='name' id='id' value='33510.9' />
  ))
  .add('Currency field with non editable and with default value', () => (
    <CurrencyField
      name='name'
      id='id'
      displayAsTextField={false}
      value='100000'
    />
  ))
