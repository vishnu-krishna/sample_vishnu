import styled from 'styled-components'
import styleVars from '@anz/styles-global'
import NumberFormat from 'react-number-format'

export const CurrencyFieldWrapper = styled.div`
  width: ${props => (props.width ? props.width : '100%')};
`
export const CurrencyFieldContainer = styled.div`
  position: relative;
`
export const CurrencyFieldLabel = styled.div`
  width: 100%;
  padding: 18px 10px 20px 16px;
`
export const CurrencySymbolContainer = styled.div`
  position: absolute;
  left: 0;
  padding: 18px 8px;
  color: ${styleVars.color.grayscale60};
`
export const CurrencyInput = styled(NumberFormat)`
    width: 100%;
    border: 1px solid ${styleVars.color.lightGrey};
    border-radius: 4px;
    margin: 8px 0;
    outline: none;
    padding: 8px 10px 8px 16px
    box-sizing: border-box;
    height: 44px;
    border-color: ${props =>
      props.error ? styleVars.color.system.error : 'none'};
    ${props =>
      props.disabled
        ? `background-color:${styleVars.color.greyscale.cloud}`
        : ''}
`
