import { render } from '@testing-library/react'
import React from 'react'
import CurrencyField from 'app/components/common/currencyField/currencyField.component'
import userEvent from '@testing-library/user-event'

describe('Currency field Component', () => {
  test('Currency field component fields to be displayed with default width', () => {
    const { getByTestId } = render(
      <CurrencyField
        id='currencyFieldId'
        name='currencyFieldName'
        onChange={() => {}}
      />
    )
    const currencyFieldElement = getByTestId(
      'currencyFieldId-currency-field-id'
    )
    const currencyFieldWrapper = getByTestId(
      'currencyFieldId-currency-field-wrapper'
    )
    expect(currencyFieldElement).toBeInTheDocument()
    expect(currencyFieldElement.value).toBe('')
    expect(currencyFieldWrapper).toHaveStyleRule('width', '100%')
  })
  test('Currency field component fields to be displayed with custom width', () => {
    const { getByTestId } = render(
      <CurrencyField
        id='currencyFieldId'
        name='currencyFieldName'
        onChange={() => {}}
        width='10%'
      />
    )
    const currencyFieldElement = getByTestId(
      'currencyFieldId-currency-field-id'
    )
    const currencyFieldWrapper = getByTestId(
      'currencyFieldId-currency-field-wrapper'
    )
    expect(currencyFieldElement).toBeInTheDocument()
    expect(currencyFieldWrapper).toHaveStyleRule('width', '10%')
    expect(currencyFieldElement).toHaveStyle('border-color: none;')
    expect(currencyFieldElement.value).toBe('')
  })
  it('should trigger the onchange event on a change of currency field', () => {
    const { getByTestId } = render(
      <CurrencyField
        id='currencyFieldId'
        name='currencyFieldName'
        onChange={() => {}}
        width='10%'
      />
    )
    const currencyFieldElement = getByTestId(
      'currencyFieldId-currency-field-id'
    )

    userEvent.type(currencyFieldElement, '10000')
    expect(currencyFieldElement.value).toBe('10,000')
    userEvent.clear(currencyFieldElement)
    expect(currencyFieldElement).toHaveStyleRule('border-color: #D73B33;')
  })
  it('should trigger the onchange event on a change of currency field -- with unfinished decimal points', () => {
    const { getByTestId } = render(
      <CurrencyField
        id='currencyFieldId'
        name='currencyFieldName'
        onChange={() => {}}
        width='10%'
      />
    )
    const currencyFieldElement = getByTestId(
      'currencyFieldId-currency-field-id'
    )
    userEvent.type(currencyFieldElement, '10000.')
    expect(currencyFieldElement.value).toBe('10,000.')
  })
  it('should trigger the onchange event on a change of currency field -- with decimal points', () => {
    const { getByTestId } = render(
      <CurrencyField
        id='currencyFieldId'
        name='currencyFieldName'
        onChange={() => {}}
        width='10%'
      />
    )
    const currencyFieldElement = getByTestId(
      'currencyFieldId-currency-field-id'
    )
    userEvent.type(currencyFieldElement, '10000.12')
    expect(currencyFieldElement.value).toBe('10,000.12')
  })
  it('Currency field with editable set as true by default and passing value to be shown', () => {
    const { getByTestId } = render(
      <CurrencyField
        id='currencyFieldId'
        name='currencyFieldName'
        onChange={() => {}}
        width='10%'
        value={9999}
      />
    )
    const currencyFieldElement = getByTestId(
      'currencyFieldId-currency-field-id'
    )
    expect(currencyFieldElement.value).toBe('9,999')
  })
  it('Currency field with editable false and value being passed to the component to be shown', () => {
    const { getByTestId } = render(
      <CurrencyField
        id='currencyFieldId'
        name='currencyFieldName'
        onChange={() => {}}
        width='10%'
        value={9999}
        displayAsTextField={false}
      />
    )
    const currencyFieldLabelElement = getByTestId(
      'currencyFieldId-currency-field-label'
    )
    expect(currencyFieldLabelElement).toBeInTheDocument()
    expect(currencyFieldLabelElement.textContent).toBe('9,999')
  })
})
