import React, { useState, useEffect } from 'react'
import {
  CurrencyFieldWrapper,
  CurrencyFieldContainer,
  CurrencySymbolContainer,
  CurrencyFieldLabel,
  CurrencyInput
} from 'app/components/common/currencyField/currencyField.styles'
import PropTypes from 'prop-types'
import { isNil } from 'lodash'
import numeral from 'numeral'
import NumberFormat from 'react-number-format'
export const currencyFieldId = 'currency-field'

const DECIMAL_SCALE = 2

const CurrencyField = ({
  id,
  name = 'currency-field-name',
  width,
  value,
  displayAsTextField = true,
  onChange,
  readonly = false,
  error
}) => {
  const [currencyValue, setCurrencyValue] = useState('')
  const [forceError, setForceError] = useState(false)
  useEffect(() => {
    if (error) {
      setForceError(true)
    }
  }, [error])
  useEffect(() => {
    // This effect is to format the value to currency format
    // Mainly used for the pre-populating the value
    if (!isNil(value)) validateCurrency(value.toString())
  }, [value])
  const handleChange = ({ target: { value } }) => {
    const enteredText = value || ''
    if (validateCurrency(enteredText) && onChange) {
      const currency = numeral(enteredText)
      onChange(currency._value)
    }
  }
  const validateCurrency = currency => {
    // currency.value() --> will return the numeric value
    let isValid = /^(?:\d+|\d{1,3}(?:,\d{3})+)(?:(\.|,)\d{1,2})?$/.test(
      currency
    )
    // set valid if empty string, but still show red error
    if (currency.length === 0) {
      isValid = true // why?!
      setForceError(true)
    } else {
      setForceError(!isValid)
    }
    setCurrencyValue(currency)
    return isValid
  }

  let currencyInputType
  if (displayAsTextField) {
    currencyInputType = (
      <CurrencyInput
        name={name}
        id={id}
        decimalScale={DECIMAL_SCALE}
        data-test-id={`${id}-${currencyFieldId}-id`}
        thousandSeparator={true}
        displayType={'input'}
        value={currencyValue}
        onChange={handleChange}
        disabled={readonly}
        error={forceError ? 1 : 0}
      />
    )
  } else {
    currencyInputType = (
      <CurrencyFieldLabel
        id='label'
        data-test-id={`${id}-${currencyFieldId}-label`}
      >
        <NumberFormat
          value={currencyValue}
          displayType='text'
          renderText={value => value}
          thousandSeparator={true}
          decimalScale={DECIMAL_SCALE}
        />
      </CurrencyFieldLabel>
    )
  }
  return (
    <CurrencyFieldWrapper
      id='wrapper'
      data-test-id={`${id}-${currencyFieldId}-wrapper`}
      width={width}
    >
      <CurrencyFieldContainer
        id='container'
        data-test-id={`${id}-${currencyFieldId}-container`}
      >
        <CurrencySymbolContainer>$</CurrencySymbolContainer>
        {currencyInputType}
      </CurrencyFieldContainer>
    </CurrencyFieldWrapper>
  )
}

CurrencyField.propTypes = {
  id: PropTypes.string.isRequired,
  name: PropTypes.string,
  width: PropTypes.string,
  value: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  displayAsTextField: PropTypes.bool,
  onChange: PropTypes.func,
  readonly: PropTypes.bool,
  error: PropTypes.bool
}

export default CurrencyField
