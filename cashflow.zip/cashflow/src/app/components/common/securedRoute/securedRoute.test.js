import React from 'react'
import { render } from '@testing-library/react'
import { Provider } from 'react-redux'

import { PAGES } from 'app/pages/constants'
import { SecuredRoute } from './securedRoute.component'
import { AppContext } from 'app/app'
import store from 'store'

jest.mock('app/pages/preProcessingPage/preProcessingPage.component', () => {
  return () => <div />
})

describe('SecuredRoute component', () => {
  it('secured Route component snapshot testing', () => {
    const userInfo = null
    const authenticating = true
    const { asFragment } = render(
      <AppContext.Provider value={{ userInfo, authenticating }}>
        <Provider store={store}>
          <SecuredRoute path={PAGES.dashboard.path} default />
        </Provider>
      </AppContext.Provider>
    )
    expect(asFragment()).toMatchSnapshot()
  })

  it('component should show authenticating modal', () => {
    const userInfo = null
    const authenticating = true
    const { getByTestId } = render(
      <AppContext.Provider value={{ userInfo, authenticating }}>
        <Provider store={store}>
          <SecuredRoute path={PAGES.dashboard.path} default />
        </Provider>
      </AppContext.Provider>
    )
    expect(getByTestId('loading-message')).toHaveTextContent(
      'Authenticating...'
    )
  })
  it('component should render defaultPage when no page is passed', () => {
    const userInfo = {
      token: '123456'
    }
    const authenticating = false
    const { getByTestId } = render(
      <Provider store={store}>
        <AppContext.Provider value={{ userInfo, authenticating }}>
          <SecuredRoute path={PAGES.dashboard.path} default />
        </AppContext.Provider>
      </Provider>
    )
    expect(getByTestId('defaultPage')).toBeDefined()
  })

  it('component should render correct page when pagename is passed', () => {
    const userInfo = {
      token: '123456'
    }
    const authenticating = false
    const { getByTestId } = render(
      <Provider store={store}>
        <AppContext.Provider value={{ userInfo, authenticating }}>
          <SecuredRoute
            path={PAGES.dashboard.path}
            pageName={PAGES.dashboard.name}
            default
          />
        </AppContext.Provider>
      </Provider>
    )
    expect(getByTestId('cfDashboard')).toBeDefined()
  })

  it('component should render correct preprocessing page when pagename is passed', () => {
    const userInfo = {
      token: '123456'
    }
    const authenticating = false
    const { getByTestId } = render(
      <Provider store={store}>
        <AppContext.Provider value={{ userInfo, authenticating }}>
          <SecuredRoute
            path={PAGES.preProcessing.path}
            pageName={PAGES.preProcessing.name}
            default
          />
        </AppContext.Provider>
      </Provider>
    )
    expect(getByTestId('preProcessing')).toBeDefined()
  })
})
