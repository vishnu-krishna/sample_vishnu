import React, { lazy, Suspense, useContext } from 'react'
import Spinner from '@anz/spinner'
import { AppContext } from 'app/app'
import CfDashboardPage from 'app/pages/cfDashboardPage/cfDashboardPage.connect'
import { PAGES } from 'app/pages/constants'
const PreProcessingPage = lazy(() =>
  import('app/pages/preProcessingPage/preProcessingPreLoadTasks.component')
)

const getPage = (pageName, routeProps) => {
  switch (pageName) {
    case PAGES.dashboard.name:
      return (
        <div data-test-id='cfDashboard'>
          <CfDashboardPage {...routeProps} />
        </div>
      )
    case PAGES.preProcessing.name:
      return (
        <div data-test-id='preProcessing'>
          <Suspense fallback={<div>Loading...</div>}>
            <PreProcessingPage appId={routeProps.appId} />
          </Suspense>
        </div>
      )
    default:
      return <div data-test-id='defaultPage'>This is the default page</div>
  }
}

const renderContent = (currentContext, pageName, routeProps) => {
  return (
    <div id={pageName}>
      {currentContext.authenticating && (
        <Spinner
          message='Authenticating...'
          show={currentContext.authenticating}
        />
      )}
      {currentContext.userInfo && getPage(pageName, routeProps)}
    </div>
  )
}

export const SecuredRoute = ({ pageName, ...routeProps }) => {
  const currentContext = useContext(AppContext)
  return renderContent(currentContext, pageName, routeProps)
}
