import styled from 'styled-components'

export const FlaggedContainer = styled.div`
  display: flex;
  align-items: center;
  width: 100%;
`

export const ContentContainer = styled.div`
  flex: 2;
`

export const IconContainer = styled.div`
  margin-left: 10px;
  margin-top: ${props => (props.disableMarginFix ? 'initial' : '24px')};
  visibility: ${props => (props.show ? 'visible' : 'hidden')};
`
