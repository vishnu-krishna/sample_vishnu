import React from 'react'
import PropTypes from 'prop-types'
import FlagIcon from '@anz/icon/dist/filled/generic/flag'
import InfoIcon from '@anz/icon/dist/filled/arrows-and-symbols/information'
import {
  ContentContainer,
  FlaggedContainer,
  IconContainer
} from './flagged.styles'
import styleVars from '@anz/styles-global'
import { setModifiedNotesSection } from 'app/pages/preProcessingPage/actions'
import { trimValue } from 'app/utils/appUtils'

export const iconContainerTestId = 'icon-container-test-id'
let count = {}

export function isFlagged (
  currentFieldValue,
  proposedValue,
  fieldName,
  dispatch,
  isAppReadOnly
) {
  if (isAppReadOnly) {
    return false
  }
  const comparisonValue = currentFieldValue || ''
  const proposedValueToCompare = proposedValue || ''

  const isDifferent =
    trimValue(proposedValueToCompare) !== trimValue(comparisonValue)

  if (fieldName) {
    count[fieldName] = isDifferent
  }
  if (dispatch) {
    dispatch(setModifiedNotesSection(count))
  }
  return isDifferent
}

export const Flagged = ({ showFlag, type, children, disableMarginFix }) => {
  let icon = null

  switch (type) {
    case 'info':
      icon = <InfoIcon color={styleVars.color.oceanBlue} />
      break
    case 'warning':
      icon = <FlagIcon color={styleVars.color.warningIcon} />
      break
    default:
      break
  }

  return (
    <FlaggedContainer>
      <ContentContainer>{children}</ContentContainer>
      <IconContainer
        show={showFlag}
        disableMarginFix={disableMarginFix}
        data-test-id={iconContainerTestId}
        data-icon-type={type}
      >
        {icon}
      </IconContainer>
    </FlaggedContainer>
  )
}

Flagged.propTypes = {
  showFlag: PropTypes.bool,
  disableMarginFix: PropTypes.bool,
  type: PropTypes.any,
  children: PropTypes.any
}

Flagged.defaultProps = {
  showFlag: false,
  disableMarginFix: false
}
