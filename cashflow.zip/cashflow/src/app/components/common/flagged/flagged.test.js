import React from 'react'
import { render } from '@testing-library/react'
import { Flagged, iconContainerTestId, isFlagged } from './flagged.component'
import AnzTextField from '@anz/text-field'

describe('Flagged', () => {
  test('Flagged component should display a flag icon when set', () => {
    const { getByTestId } = render(
      <Flagged showFlag>
        <AnzTextField
          label={'aaa'}
          name='anzTextField'
          type='text'
          id='anzTextField'
        />
      </Flagged>
    )

    const container = getByTestId(iconContainerTestId)
    expect(container).toBeDefined()
  })

  test('Flagged component should not display an icon when unset', () => {
    const { queryByTestId } = render(
      <Flagged>
        <AnzTextField
          label={'aaa'}
          name='anzTextField'
          type='text'
          id='anzTextField'
        />
      </Flagged>
    )

    const container = queryByTestId(iconContainerTestId)

    expect(container.children.length).toEqual(0)
  })

  test('Flagged component should display an info icon when explicitly set', () => {
    const { getByTestId } = render(
      <Flagged showFlag type='info'>
        <AnzTextField
          label={'aaa'}
          name='anzTextField'
          type='text'
          id='anzTextField'
        />
      </Flagged>
    )

    const container = getByTestId(iconContainerTestId)
    expect(container.dataset.iconType).toEqual('info')
  })

  test('Should set the margin to initial when disableMarginFix is truthy ', () => {
    const { getByTestId } = render(
      <Flagged showFlag disableMarginFix={true}>
        <AnzTextField
          label={'aaa'}
          name='anzTextField'
          type='text'
          id='anzTextField'
        />
      </Flagged>
    )

    const container = getByTestId(iconContainerTestId)
    expect(container).toHaveStyleRule('margin-top', 'initial')
  })

  test('Should set the margin to 24px when disableMarginFix is falsy or omitted ', () => {
    const { getByTestId } = render(
      <Flagged showFlag>
        <AnzTextField
          label={'aaa'}
          name='anzTextField'
          type='text'
          id='anzTextField'
        />
      </Flagged>
    )

    const container = getByTestId(iconContainerTestId)
    expect(container).toHaveStyleRule('margin-top', '24px')
  })

  test('isFlagged returns false when the application is read-only', () => {
    const result = isFlagged('aaaa', 'aaaa', 'xxxx', jest.fn(), true)
    expect(result).toBe(false)
  })

  test('isFlagged returns true when the parameters differ', () => {
    const result = isFlagged('aaaa', 'bbbb', 'xxxx', jest.fn(), false)
    expect(result).toBe(true)
  })

  test('isFlagged returns false when the parameters are equal', () => {
    const result = isFlagged('aaaa', 'aaaa', 'xxxx', jest.fn(), false)
    expect(result).toBe(false)
  })

  test('isFlagged calls the dispatch with the correct action', () => {
    const mockDispatch = jest.fn()

    isFlagged('aaaa', 'aaaa', 'xxxx', mockDispatch, false)
    expect(mockDispatch).toHaveBeenLastCalledWith({
      type: 'SET_MODIFIED_NOTES_COUNT',
      value: {
        xxxx: false
      }
    })
  })
})
