import { storiesOf } from '@storybook/react'
import React from 'react'
import { Flagged } from './flagged.component'
import AnzTextField from '@anz/text-field'
import TextAreaField from '@anz/textarea-field'

storiesOf('Flagged Component', module).add(
  'Flagged textfield (warning)',
  () => (
    <Flagged showFlag type={'warning'}>
      <AnzTextField
        name='anzTextField'
        type='text'
        id='anzTextField'
        label='test'
      />
    </Flagged>
  )
)

storiesOf('Flagged Component', module).add('Flagged textfield (info)', () => (
  <Flagged showFlag type={'info'}>
    <AnzTextField
      name='anzTextField'
      type='text'
      id='anzTextField'
      label='test'
    />
  </Flagged>
))

storiesOf('Flagged Component', module).add('Flagged textarea (warning)', () => (
  <Flagged showFlag type={'warning'}>
    <TextAreaField name='anzTextAreaField' id='anzTextField' label='' />
  </Flagged>
))

storiesOf('Flagged Component', module).add('Not flagged', () => (
  <Flagged>
    <AnzTextField
      name='anzTextField'
      type='text'
      id='anzTextField'
      label='test'
    />
  </Flagged>
))

storiesOf('Flagged Component', module).add(
  'Without margin fix (warning)',
  () => (
    <Flagged showFlag disableMarginFix={true} type={'warning'}>
      <input placeholder={'ANZ Bank'} />
    </Flagged>
  )
)
