import styled, { css } from 'styled-components'
import styleVars from '@anz/styles-global'

export const StyledTable = styled.table`
  width: 100%;
  border-collapse: collapse;
`

const colStyle = () => css`
  text-align: left;
  border-bottom: 1px solid ${styleVars.color.lightGrey};
  ${props =>
    props.customPadding
      ? `padding:${props.customPadding}`
      : 'padding: 10px 20px'} ${({ showOutsideBorder }) =>
    showOutsideBorder &&
    `
    border-top: 1px solid ${styleVars.color.lightGrey};
    
    :first-child {
      border-left: 1px solid ${styleVars.color.lightGrey};
    }
    :last-child {
      border-right: 1px solid ${styleVars.color.lightGrey};
    }
  `}
`
export const StyledTd = styled.td`
  ${colStyle}
`

export const StyledTh = styled.th`
  ${colStyle};
  position: ${({ stickyHeader }) => (stickyHeader ? 'sticky' : 'static')};
  top: 0px;
  background: #ffffff;
  ${props => (props.minWidth ? `min-width:${props.minWidth}` : '')}
  :before {
    content: ' ';
    ${({ showOutsideBorder }) =>
      showOutsideBorder &&
      `
      border-top: 1px solid ${styleVars.color.lightGrey};
    `};
    width: 100%;
    height: 1px;
    position: absolute;
    top: -1px;
    left: 0px;
  }
  :after {
    content: ' ';
    border-bottom: 1px solid ${styleVars.color.lightGrey};
    width: 100%;
    height: 1px;
    bottom: -1px;
    left: 0px;
  }
`

export const EmptyTd = styled.td.attrs(({ colSpan }) => ({ colSpan }))`
  :first-child {
    text-align: center;
  }
`
