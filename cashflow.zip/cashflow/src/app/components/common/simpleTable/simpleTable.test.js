import React from 'react'
import { queryByTestId, render } from '@testing-library/react'
import { SimpleTable } from './simpleTable.component'

describe('SimpleTable component', () => {
  it('Should Display data in the table', () => {
    const tableConfig = {
      headers: ['Date and Time', 'Application status', 'Staff member'],
      data: [
        {
          createdDate: '2019-09-13',
          orderState: 'PENDING_NEW',
          assigneeName: 'Adam Treloar'
        },
        {
          createdDate: '2019-09-15',
          orderState: 'NEW',
          assigneeName: 'Adam Treloar'
        }
      ]
    }
    const { container, asFragment } = render(
      <SimpleTable tableConfig={tableConfig} />
    )

    expect(queryByTestId(container, 'app-history-no-data')).toBeNull()
    expect(asFragment()).toMatchSnapshot()
  })

  it('Should display no data message', () => {
    const tableConfig = {
      headers: ['Date and Time', 'Application status', 'Staff member'],
      data: []
    }
    const { container, asFragment } = render(
      <SimpleTable tableConfig={tableConfig} />
    )
    expect(queryByTestId(container, 'app-history-no-data')).toBeDefined()
    expect(asFragment()).toMatchSnapshot()
  })
})
