import PropTypes from 'prop-types'
import React from 'react'
import { EmptyTd, StyledTable, StyledTd, StyledTh } from './simpleTable.styles'

export const SimpleTable = ({
  tableConfig,
  showOutsideBorder,
  stickyHeader,
  customPadding,
  forceShowEmptyState
}) => {
  const headers = tableConfig.headers
  const data = tableConfig.data
  const emptyState = (
    <tr>
      <EmptyTd data-test-id='app-history-no-data' colSpan={headers.length}>
        No data to be displayed
      </EmptyTd>
    </tr>
  )

  return (
    <StyledTable>
      <thead>
        <tr>
          {headers.map(headerData => {
            const tableHeading = headerData.heading || headerData
            const tableMinWidth = headerData.minwidth || false
            return (
              <StyledTh
                key={tableHeading}
                showOutsideBorder={showOutsideBorder}
                stickyHeader={stickyHeader}
                minWidth={tableMinWidth}
                customPadding={customPadding}
              >
                {tableHeading}
              </StyledTh>
            )
          })}
        </tr>
      </thead>
      <tbody>
        {data.length === 0 ? (
          emptyState
        ) : (
          <>
            {forceShowEmptyState && emptyState}
            {data.map((rowData, index) => (
              <tr key={index}>
                {Object.keys(rowData).map((key, index) => {
                  const colSpan = rowData[key].colSpan || 1
                  const value = rowData[key].value || rowData[key]
                  return (
                    <StyledTd
                      colSpan={colSpan}
                      key={`${rowData[key]}-${index}`}
                      showOutsideBorder={showOutsideBorder}
                      customPadding={customPadding}
                    >
                      {value}
                    </StyledTd>
                  )
                })}
              </tr>
            ))}
          </>
        )}
      </tbody>
    </StyledTable>
  )
}

SimpleTable.propTypes = {
  tableConfig: PropTypes.shape({
    headers: PropTypes.arrayOf(
      PropTypes.oneOfType([PropTypes.object, PropTypes.string])
    ).isRequired,
    data: PropTypes.array.isRequired
  }),
  showOutsideBorder: PropTypes.bool,
  stickyHeader: PropTypes.bool,
  customPadding: PropTypes.oneOfType([PropTypes.bool, PropTypes.string]),
  forceShowEmptyState: PropTypes.bool
}

SimpleTable.defaultProps = {
  tableConfig: null,
  showOutsideBorder: false,
  stickyHeader: false,
  customPadding: false,
  forceShowEmptyState: false
}
