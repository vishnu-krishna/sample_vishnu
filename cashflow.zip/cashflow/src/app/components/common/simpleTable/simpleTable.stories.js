import React from 'react'
import { storiesOf } from '@storybook/react'
import { SimpleTable } from './simpleTable.component'

storiesOf('SimpleTable', module)
  .add('with data', () => {
    const tableConfig = {
      headers: ['Date and Time', 'Application status', 'Staff member'],
      data: [
        {
          createdDate: '2019-09-13T02:03:07.767Z',
          orderState: 'PENDING_NEW',
          assigneeName: 'Adam Treloar'
        },
        {
          createdDate: '2019-09-15T02:03:33.267Z',
          orderState: 'NEW',
          assigneeName: 'Adam Treloar'
        }
      ]
    }
    return <SimpleTable tableConfig={tableConfig} />
  })

  .add('with no data', () => {
    const tableConfig = {
      headers: ['Date and Time', 'Application status', 'Staff member'],
      data: []
    }
    return <SimpleTable tableConfig={tableConfig} />
  })
