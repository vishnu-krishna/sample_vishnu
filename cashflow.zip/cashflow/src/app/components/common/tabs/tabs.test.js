import { render } from '@testing-library/react'
import React from 'react'
import { Tab, Tabs } from './tabs.component'
import userEvent from '@testing-library/user-event'

describe('Tabs Component', () => {
  it('should render correctly when provided tabs as children', () => {
    const { asFragment } = render(
      <Tabs id='tab-test'>
        <Tab label='My Tab' name='My Tab'>
          Content
        </Tab>
        <Tab label='My Other Tab' name='My Other Tab'>
          More Content
        </Tab>
      </Tabs>
    )

    expect(asFragment()).toMatchSnapshot()
  })

  it('should call the onTabSwitch function when clicking a tab', () => {
    const onClickFunction = jest.fn()
    const { queryByTestId } = render(
      <Tabs id='tab-test' onTabSwitch={onClickFunction}>
        <Tab label='My Tab' name='My Tab'>
          Content
        </Tab>
        <Tab label='My Other Tab' name='My Other Tab'>
          More Content
        </Tab>
      </Tabs>
    )

    const button = queryByTestId(/tab-item-My Other Tab/i)
    userEvent.click(button)
    expect(onClickFunction).toHaveBeenCalled()
  })

  test('the active tab should have bolded text', () => {
    const onClickFunction = () => true
    const { queryByTestId } = render(
      <Tabs id='tab-test' onTabSwitch={onClickFunction}>
        <Tab label='My Tab' name='My Tab'>
          Content
        </Tab>
        <Tab label='My Other Tab' name='My Other Tab'>
          More Content
        </Tab>
      </Tabs>
    )

    const tab1Button = queryByTestId(/tab-item-My Tab/i)
    const tab2Button = queryByTestId(/tab-item-My Other Tab/i)
    userEvent.click(tab2Button)
    expect(tab1Button).not.toHaveStyleRule('font-weight', 'bold')
    expect(tab2Button).toHaveStyleRule('font-weight', 'bold')
  })

  it('should display the correct children content of the active tab', () => {
    const onClickFunction = () => true
    const { queryByText, queryByTestId } = render(
      <Tabs id='tab-test' onTabSwitch={onClickFunction}>
        <Tab label='My Tab' name='My Tab'>
          Content
        </Tab>
        <Tab label='My Other Tab' name='My Other Tab'>
          More Content
        </Tab>
      </Tabs>
    )

    const tab2Button = queryByTestId(/tab-item-My Other Tab/i)
    userEvent.click(tab2Button)
    expect(queryByText('Content')).not.toBeInTheDocument()
    expect(queryByText('More Content')).toBeInTheDocument()
  })
})
