import styled, { css } from 'styled-components'

export const StyledTabList = styled.ol`
  background: linear-gradient(to right, #5e91b1, #225570);
  padding: 0;
  margin: 0;
`
export const StyledTabListItem = styled.li`
  display: inline-block;
  list-style: none;
  margin-bottom: -1px;
  padding: 12px 12px;
`

export const TabButton = styled.button`
  border: none;
  background: transparent;
  color: white;
  cursor: pointer;
  font-weight: 300;
  font-size: 18px;
  :focus {
    outline: 0;
  }

  ${props =>
    props.active &&
    css`
      font-weight: bold;
    `}
`
