import { storiesOf } from '@storybook/react'
import React from 'react'
import { Tabs, Tab } from 'app/components/common/tabs/tabs.component'
import { action } from '@storybook/addon-actions'

storiesOf('Tabs', module).add('with tab content', () => (
  <Tabs id='testing' onTabSwitch={action('Tab Changed from => to')}>
    <Tab label='Tab Title 1' name='tab1'>
      This is the contents for Tab Title 1
    </Tab>
    <Tab label='Tab Title 2' name='tab2'>
      This is the contents for Tab Title 2
    </Tab>
  </Tabs>
))
