import React, { useEffect, useState } from 'react'
import PropTypes from 'prop-types'
import { StyledTabList, StyledTabListItem, TabButton } from './tabs.styles'
import * as uuid from 'uuid'

export const Tabs = ({ id, onTabSwitch, children, activeIndex }) => {
  const [selectedTabIndex, setSelectedTabIndex] = useState(activeIndex)
  const tabContent = children[selectedTabIndex]

  useEffect(() => {
    setSelectedTabIndex(activeIndex)
  }, [activeIndex])

  return (
    <>
      <StyledTabList>
        {children.map((child, index) => {
          const { label, name } = child.props
          return (
            <TabItem
              active={selectedTabIndex === index}
              key={`${id}_tabs_${name}`}
              label={label}
              name={name}
              onClick={() => {
                if (onTabSwitch(selectedTabIndex, index)) {
                  setSelectedTabIndex(index)
                }
              }}
            />
          )
        })}
      </StyledTabList>
      {tabContent}
    </>
  )
}

Tabs.propTypes = {
  id: PropTypes.string.isRequired,
  onTabSwitch: PropTypes.func,
  children: PropTypes.arrayOf(PropTypes.node).isRequired,
  activeIndex: PropTypes.number
}

Tabs.defaultProps = {
  activeIndex: 0,
  onTabSwitch: () => true
}
/* eslint-disable react/prop-types */
const TabItem = ({ active, label, onClick, name }) => {
  return (
    <StyledTabListItem>
      <TabButton
        active={active}
        onClick={onClick}
        data-test-id={`tab-item-${name}`}
      >
        {label}
      </TabButton>
    </StyledTabListItem>
  )
}
/* eslint-disable react/prop-types */

export const Tab = ({ children }) => children

Tab.propTypes = {
  label: PropTypes.any.isRequired,
  name: PropTypes.string
}

Tab.defaultProps = {
  name: uuid.v4()
}
