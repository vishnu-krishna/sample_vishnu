import {
  ANZ_SOURCE_SYSTEM,
  commentTypesDefaultText,
  commentTypesOrderedList
} from './commentTypes.data'
import { isNullOrUndefined } from 'app/utils/appUtils'
import format from 'date-fns/format'

const timeFormatWhileSaving = 'yyyy-MM-dd HH:mm:ss.SSS'

const htmlRegularExpression = new RegExp('(<([^>]+)>)', 'gi')

export const normaliseComments = (
  commentList = [],
  commentTypes,
  userDetails
) => {
  const commentType = commentTypesOrderedList
    .map(commentTypeId =>
      commentTypes.find(ct => ct.commentTypeId === commentTypeId)
    )
    .filter(ct => !!ct)

  const normalisedComments = commentType.map((commentType, index) => {
    const { commentTypeId } = commentType
    let comment = commentList.find(
      comment => comment.commentsType === commentTypeId
    )
    if (!comment) {
      comment = {}
    }
    return {
      ...comment,
      id: !isNullOrUndefined(comment.id) ? comment.id : 0,
      data: !isNullOrUndefined(comment.data)
        ? comment.data
        : commentTypesDefaultText[commentTypeId],
      commentTypeId,
      commentsType: commentTypeId,
      firstName: userDetails.firstName,
      lastName: userDetails.lastName,
      tabIndex: index,
      format: 'Text',
      sourceSystem: ANZ_SOURCE_SYSTEM
    }
  })

  return {
    normalisedComments,
    commentType
  }
}

export const setCurrentTimeStamp = () =>
  format(+new Date(), timeFormatWhileSaving)

export const isDefaultCommentsModified = (commentList, applicationComments) => {
  if (!commentList) {
    return false
  }
  if (commentList.length > applicationComments.length) {
    return true
  }

  return applicationComments.some(applicationComment =>
    commentList.find(
      comment =>
        comment.commentsType === applicationComment.commentsType &&
        comment.data.replace(htmlRegularExpression, '') !==
          applicationComment.data.replace(htmlRegularExpression, '')
    )
  )
}

//check for the updated record only
export const getValidCommentsToUpdate = commentList =>
  commentList
    .filter(
      cm =>
        cm.data.replace(htmlRegularExpression, '') !==
        commentTypesDefaultText[cm.commentsType].replace(
          htmlRegularExpression,
          ''
        )
    )
    .map(commentList => ({
      ...commentList,
      createdDate: setCurrentTimeStamp()
    }))
