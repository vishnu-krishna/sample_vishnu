import React from 'react'

import {
  NavFillerLink,
  NavFillerText
} from './tabbedRichText/tabbedRichText.styles'

import agriQuestions from './assets/agri-questions.pdf'
import generalQuestions from './assets/general-questions.pdf'
import healthQuestions from './assets/health-questions.pdf'

const generalLendingPdfs = [
  {
    label: 'General Lending',
    location: generalQuestions
  },
  {
    label: 'Health Lending',
    location: healthQuestions
  },
  {
    label: 'Agri Lending',
    location: agriQuestions
  }
]

const NavigationLinks = () => (
  <div data-test-id={`navigation-links`}>
    <NavFillerText>Click for more information</NavFillerText>
    {generalLendingPdfs.map((pdf, index) => (
      <NavFillerLink
        key={index}
        href={pdf.location}
        data-test-id={`${pdf.label.toLocaleLowerCase().replace(/ /, '-')}`}
      >
        {pdf.label}
      </NavFillerLink>
    ))}
  </div>
)

export default NavigationLinks
