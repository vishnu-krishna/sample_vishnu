import { getByText, render } from '@testing-library/react'
import configureStore from 'redux-mock-store'
import { Provider } from 'react-redux'

import React from 'react'

import Comments from './comments.component'

const mockStore = configureStore([])

const store = {
  dashboardData: {
    userDetails: {
      firstName: 'abc'
    }
  },
  preProcessingData: {
    isAppReadOnly: false,
    normalisedComments: {
      normalisedComments: [
        {
          commentsType: '02',
          data: ''
        }
      ],
      commentType: [
        {
          commentTypeId: '02',
          name: 'Business proposal',
          description: 'Proposal'
        }
      ]
    }
  }
}

jest.mock('./tabbedRichText/tabbedRichText.component', () => {
  return {
    __esModule: true,
    /* eslint-disable react/prop-types */
    default: ({
      tabNames,
      onChange,
      tabValues = [],
      isAppReadOnly,
      children
    }) => {
      /* eslint-disable react/prop-types */
      return (
        <div>
          {tabValues.map(content => (
            <textarea
              key={tabNames}
              disabled={isAppReadOnly}
              data-test-id='test-rte'
              onChange={onChange}
              value={content.data}
            >
              {content.data}
            </textarea>
          ))}
          {children}
        </div>
      )
    }
  }
})

describe('Comments Component', () => {
  it('should match comments napshot', () => {
    const commentsComponent = render(
      <Provider store={mockStore(store)}>
        <Comments />
      </Provider>
    )
    expect(commentsComponent).toMatchSnapshot()
  })

  it('should render comment text when application comments or default comments from normalised comments exists', () => {
    const appdata = {
      ...store,
      preProcessingData: {
        isAppReadOnly: false,
        normalisedComments: {
          normalisedComments: [
            {
              commentsType: '02',
              data: 'dummy comment text'
            }
          ],
          commentType: [
            {
              commentTypeId: '02',
              name: 'Business proposal',
              description: 'Proposal'
            }
          ]
        }
      }
    }
    render(
      <Provider store={mockStore(appdata)}>
        <Comments />
      </Provider>
    )
    expect(getByText(document.body, /dummy comment text/)).not.toBeNull()
  })

  it('check if navigation links exists', () => {
    const { getByTestId } = render(
      <Provider store={mockStore(store)}>
        <Comments />
      </Provider>
    )
    expect(getByTestId('navigation-links')).toBeDefined()
  })

  it('should render empty text when commentsList is not present', () => {
    const mockData = {
      ...store,
      preProcessingData: {
        isAppReadOnly: false
      }
    }
    render(
      <Provider store={mockStore(mockData)}>
        <Comments />
      </Provider>
    )
    expect(document.body.textContent).toBe('')
  })
})
