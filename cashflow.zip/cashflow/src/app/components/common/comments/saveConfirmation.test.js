import { render } from '@testing-library/react'
import React from 'react'
import { CommentsSaveConfirmation } from 'app/components/common/comments/saveConfirmation.component'
import { Provider } from 'react-redux'
import createMockStore from 'redux-mock-store'
import { hideAppModalAction } from 'app/actions'
import userEvent from '@testing-library/user-event'
import {
  saveCommentsAction,
  saveCommentsActionFromModal,
  updateNormalisedCommentsAction
} from 'app/components/common/comments/actions'

describe('Comments Save Confirmation Component ', () => {
  const mockStore = createMockStore([])
  const store = mockStore({})
  mockStore.dispatch = jest.fn()
  const setCommentsFlyinVisible = jest.fn()
  it('should hide modal(1 action) when cancel button is clicked', () => {
    const { getByText } = render(
      <Provider store={store}>
        <CommentsSaveConfirmation
          setCommentsFlyinVisible={setCommentsFlyinVisible}
        />
      </Provider>
    )

    const cancelButton = getByText('Cancel')
    userEvent.click(cancelButton)
    expect(store.getActions()[0]).toEqual(hideAppModalAction())
  })

  it('should call 4 actions when Save button is clicked', () => {
    const { getByText } = render(
      <Provider store={store}>
        <CommentsSaveConfirmation
          setCommentsFlyinVisible={setCommentsFlyinVisible}
        />
      </Provider>
    )
    const saveButton = getByText('Save')
    userEvent.click(saveButton)
    expect(store.getActions()[0]).toEqual(hideAppModalAction())
    expect(store.getActions()[1]).toEqual(saveCommentsActionFromModal())
    expect(store.getActions()[2]).toEqual(saveCommentsAction())
    expect(store.getActions()[3]).toEqual(updateNormalisedCommentsAction())
  })
})
