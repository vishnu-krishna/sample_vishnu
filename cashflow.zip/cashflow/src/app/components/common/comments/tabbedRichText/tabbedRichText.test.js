import React from 'react'
import { render, wait } from '@testing-library/react'

import TabbedRichText from './tabbedRichText.component'
import { Provider } from 'react-redux'
import store from 'store'
import userEvent from '@testing-library/user-event'
import { createStore } from 'redux'
import preProcessingReducer from 'app/pages/preProcessingPage/reducer'
import { commentsActions } from 'app/components/common/comments/actions'
import { timeDelay } from 'app/components/common/comments/tabbedRichText/tabbedRichText.component'
import { saveCommentsResult } from 'app/pages/preProcessingPage/constants'
import { SERVER_CALL_STATES } from 'app/services/constants'

jest.mock('./RichTextEditor.component', () => {
  /* eslint-disable react/prop-types */
  return {
    __esModule: true,
    default: ({ defaultValue, onChange, isAppReadOnly = false }) => (
      <textarea
        disabled={isAppReadOnly}
        data-test-id='test-rte'
        onChange={onChange}
        value={defaultValue}
      >
        {defaultValue}
      </textarea>
    )
  }
})
/* eslint-disable react/prop-types */

const tabNames = [
  'Business proposal',
  'Additional notes',
  'Character',
  'Capacity',
  'Capital/Collateral'
]

const tabValues = [
  {
    data: '<h1>Hi</h1>',
    tabIndex: 0
  },
  {
    data: '<h1>Second tab</h1>',
    tabIndex: 1
  },
  {
    data: '<p>third tab</p>',
    tabIndex: 2
  },
  {
    data: '<p>Fourth tab</p>',
    tabIndex: 3
  },
  {
    data: '<p>Fifth tab</p>',
    tabIndex: 4
  }
]

describe('<tabbedRichText /> component: ', () => {
  it('WILL match snapshot with data', () => {
    const el = render(
      <Provider store={store}>
        <TabbedRichText
          tabNames={tabNames}
          tabValues={tabValues}
          isAppReadOnly={false}
        />
      </Provider>
    )
    expect(el).toMatchSnapshot()
  })
  it('WILL respond to tabData prop change', () => {
    const el = render(
      <Provider store={store}>
        <TabbedRichText tabNames={tabNames} tabValues={tabValues} />
      </Provider>
    )
    expect(el.getByText(tabValues[0].data)).not.toBeNull()
  })
  it('WILL change tabs on click', async () => {
    const onTabChange = jest.fn()
    const el = render(
      <Provider store={store}>
        <TabbedRichText
          tabNames={tabNames}
          tabValues={tabValues}
          onTabChange={onTabChange}
        />
      </Provider>
    )
    // Simple, manual test
    const button = el.getByText(/Additional notes/)
    userEvent.click(button)
    await wait(() => {
      expect(button).toHaveAttribute('aria-selected', 'true')
      expect(onTabChange).toHaveBeenCalled()
    })
  })
  it('WILL handle multiple tab changes and update on RTE changes', async () => {
    const onChange = jest.fn()
    const el = render(
      <Provider store={store}>
        <TabbedRichText
          tabNames={tabNames}
          tabValues={tabValues}
          onChange={onChange}
        />
      </Provider>
    )
    const rte = el.getByTestId('test-rte')
    await userEvent.type(rte, 'new data')

    await wait(() => {
      expect(rte.innerHTML).not.toEqual('First tab body')
      expect(onChange).toHaveBeenCalled()
    })
  })

  const userComments = [
    {
      commentTypeId: '02',
      commentsType: '02',
      createdDate: '2020-11-16 11:33:40.268',
      data:
        '<p><strong>What is the purpose of the proposed funding?</strong></p><p>(E.g. purchase of business/property, working capital, business expansion, if a refinance, confirm original loan purpose etc.)</p><p>&nbsp;</p><p><strong>Provide a breakdown of the funding being requested?</strong></p><p>(E.g. start-up costs, goodwill, stock, plant &amp; equipment, IG etc.)',
      firstName: 'Adam',
      format: 'Text',
      id: 0,
      lastName: 'Treloar',
      sourceSystem: 'BBD_CASHFLOW_APP',
      tabIndex: 0
    }
  ]
  const doRender = (
    saveResultValue,
    userComments = undefined,
    tabValues = [],
    applicationComments = undefined,
    isSavingComments = false
  ) => {
    const mockStore = createStore(preProcessingReducer, {
      preProcessingData: {
        saveCommentsResult: saveResultValue,
        applicationComments,
        isSavingComments
      }
    })
    mockStore.dispatch = jest.fn()
    const onChange = jest.fn()
    const { queryByText, getByTestId, queryByTestId } = render(
      <Provider store={mockStore}>
        <TabbedRichText
          tabNames={tabNames}
          tabValues={tabValues}
          onChange={onChange}
          isAppReadOnly={false}
          userComments={userComments}
        />
      </Provider>
    )

    return { queryByText, mockStore, getByTestId, queryByTestId }
  }
  describe('Success Criteria', () => {
    it('Should show the success alert message from userComments when the saveResult is success', () => {
      const { queryByText } = doRender(
        saveCommentsResult.SUCCESS,
        userComments,
        tabValues
      )
      expect(
        queryByText('Comments last saved on 16/11/2020 at 11:33 am')
      ).toBeInTheDocument()
    })

    it('Should show the success alert message from tabValues if createdDate present(when fresh save is not initiated)', () => {
      const modifiedData = {
        data: '<p>Sixth tab</p>',
        tabIndex: 5,
        createdDate: '2020-11-17 11:33:40.268'
      }
      const modifiedTabValues = [...tabValues, modifiedData]
      const { queryByText } = doRender(
        saveCommentsResult.SUCCESS,
        undefined,
        modifiedTabValues
      )
      expect(
        queryByText('Comments last saved on 17/11/2020 at 11:33 am')
      ).toBeInTheDocument()
    })

    it('Should show the success alert message from tabValues if createdDate present(consequent comments save - should pick from tabValues createdDate and NOT from userComments', () => {
      const modifiedData = {
        data: '<p>Sixth tab</p>',
        tabIndex: 5,
        createdDate: '2020-11-17 11:33:40.268'
      }
      const userComments = [
        {
          commentTypeId: '02',
          commentsType: '02',
          createdDate: '2020-11-16 11:44:40.268',
          data: '<p>Test</p>',
          firstName: 'Adam',
          format: 'Text',
          id: 0,
          lastName: 'Treloar',
          sourceSystem: 'BBD_CASHFLOW_APP',
          tabIndex: 0
        }
      ]
      const modifiedTabValues = [...tabValues, modifiedData]
      const { queryByText } = doRender(
        saveCommentsResult.SUCCESS,
        userComments,
        modifiedTabValues
      )
      expect(
        queryByText('Comments last saved on 17/11/2020 at 11:33 am')
      ).toBeInTheDocument()
    })

    it('Should dispatch the saveResult reset after 5 seconds when the saveResult is success', () => {
      jest.useFakeTimers()
      const { mockStore } = doRender(
        saveCommentsResult.SUCCESS,
        userComments,
        tabValues
      )
      jest.advanceTimersByTime(timeDelay)
      expect(mockStore.dispatch).toHaveBeenCalledWith({
        type: commentsActions.SAVE_APPLICATION_COMMENTS_RESET
      })
    })
  })

  describe('Failure Criteria', () => {
    it('Should dispatch the saveResult reset after 5 seconds when the saveResult is failure', () => {
      jest.useFakeTimers()
      const { mockStore } = doRender(
        saveCommentsResult.FAILURE,
        userComments,
        tabValues
      )
      jest.advanceTimersByTime(timeDelay)
      expect(mockStore.dispatch).toHaveBeenCalledWith({
        type: commentsActions.SAVE_APPLICATION_COMMENTS_RESET
      })
    })
    it('should set failure message', () => {
      const { queryByText } = doRender(
        saveCommentsResult.FAILURE,
        userComments,
        tabValues
      )
      expect(
        queryByText(
          `Failed to save comments. Please try again. If the issue persists, please contact tech assist on 13 10 58.`
        )
      ).toBeInTheDocument()
    })

    it('Should NOT show the success/failure alert message when the user opens for the first time (There is no createdDate field in tabValues or userComments)', () => {
      const { queryByText } = doRender(null, undefined, tabValues)
      expect(queryByText(/Comments last saved on/)).not.toBeInTheDocument()
      expect(
        queryByText(
          `Failed to save comments. Please try again. If the issue persists, please contact tech assist on 13 10 58.`
        )
      ).not.toBeInTheDocument()
    })

    it('Should NOT dispatch the saveResult reset after 5 seconds when the createdDate is not present in userComments or tabValues', () => {
      const modifiedUserComments = [
        {
          commentTypeId: '02',
          commentsType: '02',
          data:
            '<p><strong>What is the purpose of the proposed funding?</strong></p><p>(E.g. purchase of business/property, working capital, business expansion, if a refinance, confirm original loan purpose etc.)</p><p>&nbsp;</p><p><strong>Provide a breakdown of the funding being requested?</strong></p><p>(E.g. start-up costs, goodwill, stock, plant &amp; equipment, IG etc.)',
          firstName: 'Adam',
          format: 'Text',
          id: 0,
          lastName: 'Treloar',
          sourceSystem: 'BBD_CASHFLOW_APP',
          tabIndex: 0
        }
      ]
      jest.useFakeTimers()
      const { mockStore } = doRender(null, modifiedUserComments, tabValues)
      jest.advanceTimersByTime(timeDelay)
      expect(mockStore.dispatch).not.toHaveBeenCalledWith({
        type: commentsActions.SAVE_APPLICATION_COMMENTS_RESET
      })
    })
  })

  describe('Button clicks', () => {
    it('Should NOT dispatch save comments when the user comments and normalised comments are same', () => {
      const applicationComments = [
        {
          commentTypeId: '02',
          commentsType: '02',
          createdDate: '2020-11-16 11:33:40.268',
          data:
            '<p><strong>What is the purpose of the proposed funding?</strong></p><p>(E.g. purchase of business/property, working capital, business expansion, if a refinance, confirm original loan purpose etc.)</p><p>&nbsp;</p><p><strong>Provide a breakdown of the funding being requested?</strong></p><p>(E.g. start-up costs, goodwill, stock, plant &amp; equipment, IG etc.)',
          firstName: 'Adam',
          format: 'Text',
          id: 0,
          lastName: 'Treloar',
            sourceSystem: 'BBD_CASHFLOW_APP',
            tabIndex: 0
          }
        ]

      const { getByTestId, mockStore } = doRender(
        saveCommentsResult.SUCCESS,
        userComments,
        tabValues,
        applicationComments
      )
      const saveButton = getByTestId('save_button')
      userEvent.click(saveButton)
      expect(mockStore.dispatch).not.toHaveBeenCalledWith({
        type: commentsActions.SAVE_COMMENTS
      })
      expect(mockStore.dispatch).not.toHaveBeenCalledWith({
        type: commentsActions.UPDATE_NORMALISED_COMMENTS
      })
    })

    it('Should dispatch save comments when the user comments and normalised comments are NOT same', () => {
      const applicationComments = [
        {
          commentTypeId: '02',
          commentsType: '02',
          createdDate: '2020-11-16 11:33:40.268',
          data: '<p>something else</p>',
          firstName: 'Adam',
          format: 'Text',
          id: 0,
          lastName: 'Treloar',
          sourceSystem: 'BBD_CASHFLOW_APP',
            tabIndex: 0
          }
        ]

      const { getByTestId, mockStore, queryByText, queryByTestId } = doRender(
        saveCommentsResult.SUCCESS,
        userComments,
        tabValues,
        applicationComments
      )
      const saveButton = getByTestId('save_button')
      userEvent.click(saveButton)
      expect(queryByText('Saving')).not.toBeInTheDocument()
      expect(queryByTestId('save-spinner')).not.toBeInTheDocument()
      expect(mockStore.dispatch).toHaveBeenCalledWith({
        type: commentsActions.SAVE_APPLICATION_COMMENTS_STARTED
      })
      expect(mockStore.dispatch).toHaveBeenCalledWith({
        type: commentsActions.SAVE_COMMENTS
      })
      expect(mockStore.dispatch).toHaveBeenCalledWith({
        type: commentsActions.UPDATE_NORMALISED_COMMENTS
      })
    })

    it('Should change the text of save button, disable save button and show spinner when the user starts saving', () => {
      const applicationComments = [
        {
          commentTypeId: '02',
          commentsType: '02',
          createdDate: '2020-11-16 11:33:40.268',
          data: '<p>something else</p>',
          firstName: 'Adam',
          format: 'Text',
          id: 0,
          lastName: 'Treloar',
          sourceSystem: 'BBD_CASHFLOW_APP',
            tabIndex: 0
          }
        ]
      const { queryByText, queryByTestId } = doRender(
        saveCommentsResult.SUCCESS,
        userComments,
        tabValues,
        applicationComments,
        true
      )
      expect(queryByText('Saving')).toBeInTheDocument()
      expect(queryByTestId('save-spinner')).toBeInTheDocument()
      expect(queryByText('Save')).not.toBeInTheDocument()
    })

    it('Should dispatch reset saveCommentsResult on alert close button click', () => {
      const { getByTestId, mockStore } = doRender(
        saveCommentsResult.SUCCESS,
        userComments,
        tabValues
      )
      const alertCloseButton = getByTestId(
        `${SERVER_CALL_STATES.SUCCESS}_closeButton`
      )
      userEvent.click(alertCloseButton)
      expect(mockStore.dispatch).toHaveBeenCalledWith({
        type: commentsActions.SAVE_APPLICATION_COMMENTS_RESET
      })
    })
  })
})
