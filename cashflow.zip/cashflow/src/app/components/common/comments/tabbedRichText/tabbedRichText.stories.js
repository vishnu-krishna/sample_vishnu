import React from 'react'
import { storiesOf } from '@storybook/react'
import { Provider } from 'react-redux'
import store from 'store'
import TabbedRichtext from './tabbedRichText.component'

const tabNames = [
  'Business proposal',
  'Additional notes',
  'Character',
  'Capacity',
  'Capital/Collateral'
]

const normalisedComments = [
  {
    data: '<h1>Hi</h1>',
    tabIndex: 0
  },
  {
    data: '<h1>Second tab</h1>',
    tabIndex: 1
  },
  {
    data: '<p>third tab</p>',
    tabIndex: 2
  },
  {
    data: '<p>Fourth tab</p>',
    tabIndex: 3
  },
  {
    data: '<p>Fifth tab</p>',
    tabIndex: 4
  }
]

storiesOf('comments/inner/tabbedRichText', module).add('Standard', () => {
  const onCommentsEdit = ({ tabIndex }) => {
    console.log(`On Edit Triggered for Tab: ${tabIndex}`)
  }

  return (
    <Provider store={store}>
      <TabbedRichtext
        tabNames={tabNames}
        tabValues={normalisedComments}
        isAppReadOnly={false}
        onChange={onCommentsEdit}
      />
    </Provider>
  )
})
