import React from 'react'
import { storiesOf } from '@storybook/react'

import {
  Container,
  Navigation,
  NavItem,
  BodyContainer,
  Body
} from './tabbedRichText.styles'

import RichTextEditor from './RichTextEditor.component.js'

import { makeTabs } from './Tabs.helper'
const { Tabs, Tab, EditorPanel } = makeTabs()

storiesOf('comments/inner/Tabs', module).add('Standard', () => {
  return (
    <Container>
      <Tabs
        onTabChange={idx => console.log('changed tabs', idx)}
        onChange={({ index, value }) => console.log({ index, value })}
        onChangeAll={(...args) => console.log(args)}
      >
        <Navigation fixedWidth='20em'>
          <Tab>
            <NavItem>First</NavItem>
          </Tab>
          <Tab>
            <NavItem>Second</NavItem>
          </Tab>
          <Tab>
            <NavItem>Third</NavItem>
          </Tab>
        </Navigation>
        <BodyContainer>
          <Body>
            <EditorPanel>
              <RichTextEditor />
            </EditorPanel>
            <EditorPanel>
              <RichTextEditor />
            </EditorPanel>
            <EditorPanel>
              <RichTextEditor />
            </EditorPanel>
          </Body>
        </BodyContainer>
      </Tabs>
    </Container>
  )
})
