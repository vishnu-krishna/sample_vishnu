import styled from 'styled-components'

export const EditorContainer = styled.div`
  /**
  Sticky the top toolbar of the sun-editor
  Used in conjunction with 'stickyToolbar: true' in ./RichTextEditor.component.js
  **/

  .sun-editor {
    height: 625px;
    overflow-y: scroll;
  }

  .sun-editor .se-toolbar {
    position: sticky;
    top: 0;
  }

  width: 100%;
`
