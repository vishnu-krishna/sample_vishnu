import React, {
  cloneElement,
  createContext,
  isValidElement,
  useContext,
  useMemo,
  useReducer,
  useState
} from 'react'
import { devLog } from 'app/utils/devUtils'
import { PropTypes } from 'prop-types'

function useConstant (fn) {
  const ref = React.useRef()

  if (!ref.current) {
    ref.current = { val: fn() }
  }

  return ref.current.val
}

const makeTabs = () => {
  const TabState = createContext()
  const Elements = createContext()
  const EditorState = createContext()

  const reducer = (state, action) => {
    switch (action.type) {
      case 'update':
        const newValues = [...state.values]
        newValues[action.index] = action.value
        return {
          ...state,
          values: newValues
        }
      default:
        devLog('Tabs.helper: invalid action:', { state, action })
    }
  }

  /**
   * Tabs component
   * Provides top-level state to all tabs and panels via contexts
   */
  const Tabs = ({
    tabs,
    panels,
    editors,
    onTabChange,
    onChange,
    onChangeAll,
    children
  }) => {
    const currentTab = useState(0)
    const elements = useConstant(() => ({
      tabs,
      panels,
      editors
    }))
    const [editorValueState, dispatch] = useReducer(reducer, {
      values: []
    })

    return (
      <Elements.Provider value={elements}>
        <EditorState.Provider
          value={{ editorValueState, dispatch, onChange, onChangeAll }}
        >
          <TabState.Provider value={{ tabState: currentTab, onTabChange }}>
            {children}
          </TabState.Provider>
        </EditorState.Provider>
      </Elements.Provider>
    )
  }

  Tabs.propTypes = {
    tabs: PropTypes.any,
    panels: PropTypes.any,
    editors: PropTypes.any,
    onTabChange: PropTypes.any,
    onChange: PropTypes.any,
    onChangeAll: PropTypes.any,
    children: PropTypes.any
  }

  /**
   * @typedef {Object} TabState
   * @property {boolean} isActive - whether the tab is currently active
   * @property {function} onClick - optional function to call when clicked
   */
  /**
   * Provides state to tabs (navigation buttons)
   *
   * @return {TabState}
   */
  const useTabState = tabIndex => {
    const { tabState, onTabChange } = useContext(TabState)
    const [currentTab, setCurrentTab] = tabState

    const onClick = useConstant(() => () => {
      setCurrentTab(tabIndex)
      onTabChange && onTabChange(tabIndex)
    })

    const state = useMemo(
      () => ({
        isActive: currentTab === tabIndex,
        onClick
      }),
      [currentTab, onClick, tabIndex]
    )

    return state
  }

  /**
   * Provides state to panels
   *
   * @return {boolean} whether the panel is active
   */
  const usePanelState = panelIndex => {
    const { tabState } = useContext(TabState)
    const [currentTab] = tabState

    return panelIndex === currentTab
  }

  /**
   * @typedef {Object} EditorState
   * @property {number} editorIndex - index of this editor
   * @property {string} value - the current value
   * @property {function} onChange - called when changed with current editor's data
   * @property {fucntion} onChangeAll - called when changed with data from _all editors_
   */
  /**
   * Provides state to editors
   *
   * @return {EditorState}
   */
  const useEditorState = (editorIndex, initialValue = '') => {
    const { editorValueState, dispatch, onChange, onChangeAll } = useContext(
      EditorState
    )
    editorValueState.values[editorIndex] = initialValue

    return {
      editorIndex,
      value: editorValueState.values[editorIndex] || initialValue,
      onChange: val => {
        dispatch({
          type: 'update',
          index: editorIndex,
          value: val
        })
        onChange && onChange({ tabIndex: editorIndex, value: val })
        onChangeAll && onChangeAll(editorValueState.values)
      }
    }
  }

  /**
   * Tab component is a wrapper for your tab buttons
   * Simply handles some state and forwards tab state
   * to its children via props
   * @reference TabState
   *
   * @param {*} children
   */
  const Tab = ({ tabIndex, children, ...otherProps }) => {
    const state = useTabState(tabIndex)

    return isValidElement(children)
      ? cloneElement(children, {
          ...otherProps,
          ...state
        })
      : children
  }

  /**
   * Panel component is a wrapper for content associated with a
   * tab (yup... the panel)
   * It only renders its children when its PanelState is true
   * @reference PanelState
   * @param {*} children
   */
  const Panel = ({ panelIndex, children }) => {
    const isActive = usePanelState(panelIndex)

    return isActive ? children : null
  }

  /**
   * Editor panel is a generic wrapper for components which handle
   * editing (strings only currently)
   *
   * It works with `Tabs` and `reducer` to internally store all state
   * while forwarding it along to any child components
   *
   * @reference EditorState
   * @reference PanelState
   *
   * @param {string} defaultValue a value to set at initialisation
   * @param {*} children
   */
  const EditorPanel = ({
    panelIndex,
    editorIndex,
    defaultValue = '',
    children,
    ...otherProps
  }) => {
    const isActive = usePanelState(panelIndex)
    const { value, onChange } = useEditorState(editorIndex, defaultValue)

    return isActive
      ? cloneElement(children, {
          ...otherProps,
          value,
          onChange: onChange
        })
      : null
  }

  return {
    Tabs,
    Tab,
    Panel,
    EditorPanel,
    useTabState,
    usePanelState,
    useEditorState
  }
}

export { makeTabs }
