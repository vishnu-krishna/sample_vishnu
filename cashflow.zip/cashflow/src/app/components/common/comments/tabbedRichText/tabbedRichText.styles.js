import styled, { css } from 'styled-components'

import styleVars from '@anz/styles-global'
import { P1 } from '@anz/text'

const color = name => styleVars.color[name] || '#f0f'

const SaveAlertWrapper = styled.div`
  width: 80%;
`
const styleOverrides = css`
  .quill {
    width: 100%;

    .ql-toolbar.ql-snow {
      border: none;
      box-shadow: 0 8px 8px rgba(0, 0, 0, 0.2);
      background: ${'#e8e8e8'};

      button,
      .ql-picker {
        width: 32px;
        height: 32px;
        padding: 6px;
        background: #fff;
        border: 1px solid ${'#eee'};

        .ql-picker-label {
          padding: 0;
        }
      }

      .ql-picker {
        padding: 2px;
        padding-bottom: -2px;
      }
    }

    .ql-container.ql-snow {
      border: none;
    }
  }
`

const Container = styled.div`
  display: flex;
  flex-direction: row;
  height: 100%;
  ${styleOverrides}
`

const Navigation = styled.div.attrs(props => ({
  role: 'tablist',
  'aria-label': props.label || 'tab navigation',
  'data-test-id': 'tablist-comment-category'
}))`
  display: flex;
  flex-direction: column;
  overflow-y: auto;

  ${({ fixedWidth }) =>
    fixedWidth &&
    css`
      width: ${fixedWidth};
      flex-grow: 0;
      flex-shrink: 0;
    `}
`

const NavItemText = styled(P1).attrs({
  as: 'div'
})`
  border: none;
  border-bottom: 1px solid #ddd;
  background: #fff;
  margin: 0;
  padding: 0;

  font-family: 'Myriad Pro', sans-serif;
  text-align: left;
`

const NavItem = styled(NavItemText).attrs(props => ({
  as: 'button',
  'aria-selected': !!props.isActive,
  // Accessibility
  role: 'tab'
}))`
  display: inline-flex;
  align-items: center
  flex-grow: 0;

  margin: 0;
  padding: 1.5rem;
  padding-left: 1.5rem;

  cursor: pointer;
  transition: 0.1s ease background, 0.1s ease color;

  &:active, &:hover {
    background: #f8f8f8;
  }

  &[aria-selected=true] {
    background: ${color('darkBlue')};
    color: #fff;
    &:active,
    &:hover {
      background: ${color('darkBlue')};
      color: #fff;
    }
  }
`

const NavFiller = styled(NavItem).attrs({
  as: 'div'
})`
  flex-basis: auto;
  flex-grow: 1;
  height: auto;
  display: block;

  border: none;
  cursor: unset;

  &:hover,
  &active {
    background: #fff;
  }
`

const NavFillerText = styled(NavItemText).attrs({
  as: 'p'
})`
  display: block;

  border: none;
  font-size: 0.9rem;
`

const NavFillerLink = styled(NavFillerText).attrs({
  as: 'a',
  target: '_blank'
})`
  color: ${color('oceanBlue')};

  &:hover {
    color: ${color('darkBlue')};
  }
`

const BodyContainer = styled.div`
  background: #fff;
  display: flex;
  flex-grow: 1;
`

const Body = styled.div`
  flex-grow: 1;
  display: flex;
  flex-direction: column;
`
const StyledButtonSection = styled.div`
  display: flex;
  justify-content: flex-end;
  margin-right: 20px;
  margin-top: 20px;
`
const StyledTabbedRichButton = styled.div`
  margin-left: auto;
  display: flex;
`
const StyledSaveCommentsButton = styled.div`
  width: 138px;
`
const StyledSpinnerWrapper = styled.div`
  position: relative;
  top: 7px;
  left: 42px;
`
export {
  Container,
  Navigation,
  NavItem,
  NavFiller,
  BodyContainer,
  Body,
  NavFillerText,
  NavFillerLink,
  StyledButtonSection,
  SaveAlertWrapper,
  StyledTabbedRichButton,
  StyledSaveCommentsButton,
  StyledSpinnerWrapper
}
