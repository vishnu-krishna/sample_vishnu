import React from 'react'
import SunEditor from 'suneditor-react'
import 'suneditor/dist/css/suneditor.min.css'
import { EditorContainer } from './RichTextEditor.styles'
import PropTypes from 'prop-types'

const editorOptions = {
  buttonList: [
    ['bold', 'italic', 'underline', 'strike'],
    ['fontColor', 'hiliteColor'],
    ['list', 'table', 'link', 'image'],
    ['undo', 'redo']
  ],
  resizingBar: false,
  stickyToolbar: true // this needs to be used in conjunction with sticky toolbar css in ./RichTextEditor.styles
}

const BasicEditor = ({ defaultValue, onChange, isAppReadOnly, index }) => {
  return (
    <EditorContainer>
      <SunEditor
        data-test-id={`editor-${index}`}
        setContents={defaultValue}
        setOptions={editorOptions}
        onChange={onChange}
        disable={isAppReadOnly}
      />
    </EditorContainer>
  )
}

BasicEditor.propTypes = {
  defaultValue: PropTypes.any,
  onChange: PropTypes.any,
  isAppReadOnly: PropTypes.any,
  index: PropTypes.any
}

export default BasicEditor
