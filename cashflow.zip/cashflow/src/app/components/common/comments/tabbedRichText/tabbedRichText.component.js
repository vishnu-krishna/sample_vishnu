/**
 * tabbedRichText provides a specialisation of VerticalTabs
 * which includes a Richtext editor in a single body
 *
 * Handles the internal state of:
 *
 * - tab changes
 * - richtext internal state(s) (1 per tab)
 */
import React from 'react'
import PropTypes from 'prop-types'
import format from 'date-fns/format'
import { motion } from 'framer-motion'
import { Body, BodyContainer, Container, NavFiller, Navigation, NavItem, StyledSaveCommentsButton, StyledSpinnerWrapper } from './tabbedRichText.styles'
import BasicEditor from './RichTextEditor.component'
import { makeTabs } from './Tabs.helper'
import { SaveAlertWrapper, StyledButtonSection, StyledTabbedRichButton } from 'app/components/common/comments/tabbedRichText/tabbedRichText.styles'
import { useDispatch, useSelector } from 'react-redux'
import { saveCommentsAction, saveCommentsResultReset, saveCommentsStartAction, updateNormalisedCommentsAction } from 'app/components/common/comments/actions'
import { pickValue } from 'app/utils/appUtils'
import { saveCommentsResult } from 'app/pages/preProcessingPage/constants'
import Alert from '@anz/alert'
import { SERVER_CALL_STATES } from 'app/services/constants'
import { isDefaultCommentsModified } from 'app/components/common/comments/comments.utils'
import Button from '@anz/button'

const { Tabs, Tab, EditorPanel } = makeTabs()

export const timeDelay = 5000
/* eslint-disable react/prop-types */
const TabInfo = ({ label, children }) => {
  return (
    <NavFiller key='filler' label={label}>
      {children}
    </NavFiller>
  )
}
/* eslint-disable react/prop-types */

const TabNavigation = ({ tabNames = [], children }) => {
  return (
    <Navigation fixedWidth='16rem'>
      {tabNames.map((tabName, idx) => (
        <Tab
          tabIndex={idx}
          key={idx}
          data-test-id={`tab-${tabName.toLocaleLowerCase().replace(/ /, '-')}`}
        >
          <NavItem>{tabName}</NavItem>
        </Tab>
      ))}
      <TabInfo
        key='additional'
        label='Additional content'
        data-test-id={`additional-content-section`}
      >
        {children}
      </TabInfo>
    </Navigation>
  )
}

const Editors = ({ tabValues = [], isAppReadOnly, ...props }) => {
  return tabValues.map((tabValue, idx) => {
    return (
      <EditorPanel panelIndex={idx} editorIndex={idx} key={idx} {...props}>
        <BasicEditor
          isAppReadOnly={isAppReadOnly}
          index={idx}
          defaultValue={tabValue.data}
        />
      </EditorPanel>
    )
  })
}

export const lastSavedSectionJSX = (
  tabValues,
  userComments,
  saveCommentsResultantValue,
  dispatch
) => {
  const dateFormat = `dd/MM/yyyy`
  const timeFormat = `h:mm aaaaa'm'`
  let lastSavedDate = tabValues
    .map(tabValue => tabValue.createdDate)
    .find(createdDate => !!createdDate)

  if (
    userComments &&
    saveCommentsResultantValue === saveCommentsResult.SUCCESS &&
    !lastSavedDate
  ) {
    lastSavedDate = userComments
      .map(userComment => userComment.createdDate)
      .find(createdDate => !!createdDate)
  }
  const failureMessage = `Failed to save comments. Please try again. If the issue persists, please contact tech assist on 13 10 58.`
  const successMessage =
    lastSavedDate &&
    `Comments last saved on ${format(
      new Date(lastSavedDate),
      dateFormat
    )} at ${format(new Date(lastSavedDate), timeFormat)}`
  if (
    lastSavedDate ||
    saveCommentsResultantValue === saveCommentsResult.FAILURE
  ) {
    setTimeout(() => {
      dispatch(saveCommentsResultReset())
    }, timeDelay)
  }
  const alertJSX = (reason, message) => (
    <SaveAlertWrapper>
      <Alert
        id={`${reason}`}
        reason={reason}
        closable={true}
        onClose={() => dispatch(saveCommentsResultReset())}
      >
        {message}
      </Alert>
    </SaveAlertWrapper>
  )

  if (saveCommentsResultantValue === saveCommentsResult.FAILURE) {
    return alertJSX(SERVER_CALL_STATES.ERROR, failureMessage)
  }
  return lastSavedDate && alertJSX(SERVER_CALL_STATES.SUCCESS, successMessage)
}

const onSaveClick = (userComments, applicationComments, dispatch) => {
  if (isDefaultCommentsModified(userComments, applicationComments)) {
    dispatch(saveCommentsStartAction())
    dispatch(saveCommentsAction())
    dispatch(updateNormalisedCommentsAction())
  }
}

const TabbedRichText = ({
  tabNames,
  tabValues,
  onChange,
  onTabChange,
  children,
  isAppReadOnly,
  userComments
}) => {
  const commentsSaveButtonVariants = {
    initial: {
      display: 'block',
      width: 25,
      height: 25,
      border: '3px solid #FFFFFF',
      borderTop: '3px solid #017eba',
      borderRadius: '50%',
      top: 0,
      left: 0
    },
    animate: {
      rotate: 360,
      transition: {
        loop: Infinity,
        ease: 'linear',
        duration: 1
      }
    }
  }

  const saveCommentsResultantValue = useSelector(state =>
    pickValue(state, 'preProcessingData.saveCommentsResult')
  )

  const isSavingComments = useSelector(state =>
    pickValue(state, 'preProcessingData.isSavingComments')
  )

  const applicationComments = useSelector(state =>
    pickValue(state, 'preProcessingData.applicationComments')
  )

  // then in the tabbedRichText component, we need to check if the commentList is having a mismatch with the applicationComments - if so, then it is dirty.
  // commentsType is common

  const dispatch = useDispatch()
  return (
    <Container>
      <Tabs
        tabs={tabNames.length}
        panels={tabNames.length}
        editors={tabValues.length}
        onChange={onChange}
        onTabChange={onTabChange}
      >
        <TabNavigation tabNames={tabNames}>{children}</TabNavigation>
        <BodyContainer>
          <Body>
            <Editors tabValues={tabValues} isAppReadOnly={isAppReadOnly} />
            <StyledButtonSection>
              {!!saveCommentsResultantValue &&
                lastSavedSectionJSX(
                  tabValues,
                  userComments,
                  saveCommentsResultantValue,
                  dispatch
                )}
              <StyledTabbedRichButton>
                {isSavingComments && (
                  <StyledSpinnerWrapper>
                    <motion.span
                      variants={commentsSaveButtonVariants}
                      initial='initial'
                      animate='animate'
                      data-test-id='save-spinner'
                    />
                  </StyledSpinnerWrapper>
                )}
                <StyledSaveCommentsButton>
                  <Button
                    fullWidth
                    appearance='primary'
                    type='button'
                    size='small'
                    onClick={() =>
                      onSaveClick(userComments, applicationComments, dispatch)
                    }
                    id={'save'}
                    buttonLabel='Save'
                  >
                    {isSavingComments ? 'Saving' : 'Save'}
                  </Button>
                </StyledSaveCommentsButton>
              </StyledTabbedRichButton>
            </StyledButtonSection>
          </Body>
        </BodyContainer>
      </Tabs>
    </Container>
  )
}

TabbedRichText.propTypes = {
  tabNames: PropTypes.arrayOf(PropTypes.string),
  tabValues: PropTypes.arrayOf(PropTypes.object),
  onTabChange: PropTypes.any,
  isAppReadOnly: PropTypes.bool,
  children: PropTypes.node,
  onChange: PropTypes.func,
  userComments: PropTypes.arrayOf(PropTypes.object)
}

export { TabbedRichText as default }
