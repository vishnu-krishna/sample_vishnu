/**
 * comments component proffers very little functionality in and of itself
 *
 * Leans heavily on `tabbedRichText`
 * Purpose of this component is exclusivey:
 *
 * - integration with application and data APIs
 * - specialised overrides and events
 * - hard-coded content at the bottom of the navigation tabs
 *
 */
import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'

import TabbedRichtext from './tabbedRichText/tabbedRichText.component'
import { Body } from './comments.styles'
import { getValidCommentsToUpdate } from './comments.utils'
import { pickValue } from 'app/utils/appUtils'
import { getApplicationCommentsAction, updateCommentsAction, updateNormalisedCommentsAction } from './actions'
import NavigationLinks from './navigationLinks.component'

const Comments = () => {
  const dispatch = useDispatch()

  const preProcessingData = useSelector(state =>
    pickValue(state, 'preProcessingData')
  )

  const userComments = useSelector(state =>
    pickValue(state, 'preProcessingData.commentList')
  )

  const commentsObject = useSelector(state =>
    pickValue(state, 'preProcessingData.normalisedComments')
  )
  const { isAppReadOnly } = preProcessingData

  useEffect(() => {
    dispatch(getApplicationCommentsAction())
  }, [ dispatch ])

  const onTabChange = () => {
    dispatch(updateNormalisedCommentsAction())
  }

  const onCommentsEdit = ({ tabIndex, value }) => {
    let newComments = []
    newComments = commentsObject.normalisedComments.map(comment => {
      if (comment.tabIndex === tabIndex) {
        comment.data = value
      }
      return comment
    })
    const existingComment =
      userComments &&
      userComments.find(userComment => userComment.tabIndex === tabIndex)
    if (!existingComment) {
      //triggered due to change in tab, so retain other tab comments
      newComments = newComments.map(updatedComment => {
        const comment =
          userComments &&
          userComments.find(
            userComment => userComment.tabIndex === updatedComment.tabIndex
          )
        if (comment) {
          updatedComment.data = comment.data
        }
        return updatedComment
      })
    }
    const commentsToUpdate = getValidCommentsToUpdate(newComments)
    if (commentsToUpdate && commentsToUpdate.length > 0) {
      dispatch(updateCommentsAction(commentsToUpdate))
    }
  }
  return (
    <Body>
      {commentsObject &&
        commentsObject.normalisedComments &&
        commentsObject.commentType && (
          <TabbedRichtext
            onTabChange={onTabChange}
            tabNames={commentsObject.commentType.map(ct => ct.name)}
            tabValues={commentsObject.normalisedComments}
            isAppReadOnly={isAppReadOnly}
            onChange={onCommentsEdit}
            userComments={userComments}
          >
            <NavigationLinks />
          </TabbedRichtext>
        )}
    </Body>
  )
}

const AttachedComments = props => {
  return <Comments {...props} />
}

export { AttachedComments as default }
