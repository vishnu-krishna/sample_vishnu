export const commentsActions = {
  SAVE_COMMENTS: 'SAVE_COMMENTS',
  UPDATE_COMMENTS: 'UPDATE_COMMENTS',
  SAVE_APPLICATION_COMMENTS: 'SAVE_APPLICATION_COMMENTS',
  SAVE_APPLICATION_COMMENTS_STARTED: 'SAVE_APPLICATION_COMMENTS_STARTED',
  SAVE_APPLICATION_COMMENTS_COMPLETED: 'SAVE_APPLICATION_COMMENTS_COMPLETED',
  SAVE_APPLICATION_COMMENTS_FROM_MODAL: 'SAVE_APPLICATION_COMMENTS_FROM_MODAL',
  SAVE_APPLICATION_COMMENTS_SUCCESS: 'SAVE_APPLICATION_COMMENTS_SUCCESS',
  SAVE_APPLICATION_COMMENTS_FAILURE: 'SAVE_APPLICATION_COMMENTS_FAILURE',
  SAVE_APPLICATION_COMMENTS_RESET: 'SAVE_APPLICATION_COMMENTS_RESET',
  GET_APPLICATION_COMMENTS: 'GET_APPLICATION_COMMENTS',
  UPDATE_COMMENT_IDS: 'UPDATE_COMMENT_IDS',
  UPDATE_NORMALISED_COMMENTS: 'UPDATE_NORMALISED_COMMENTS',
  SAVE_NORMALISED_COMMENTS: 'SAVE_NORMALISED_COMMENTS',
  GET_COMMENT_TYPES: 'GET_COMMENT_TYPES',
  GET_COMMENT_TYPES_SUCCESS: 'GET_COMMENT_TYPES_SUCCESS',
  GET_COMMENT_TYPES_FAILURE: 'GET_COMMENT_TYPES_FAILURE'
}

export const saveCommentsAction = () => ({
  type: commentsActions.SAVE_COMMENTS
})

export const saveCommentsStartAction = () => ({
  type: commentsActions.SAVE_APPLICATION_COMMENTS_STARTED
})

export const saveCommentsActionFromModal = () => ({
  type: commentsActions.SAVE_APPLICATION_COMMENTS_FROM_MODAL
})

export const saveCommentsResultReset = () => ({
  type: commentsActions.SAVE_APPLICATION_COMMENTS_RESET
})

export const getApplicationCommentsAction = () => ({
  type: commentsActions.GET_APPLICATION_COMMENTS
})

export const updateNormalisedCommentsAction = () => ({
  type: commentsActions.UPDATE_NORMALISED_COMMENTS
})

export const updateCommentsAction = (commentList = []) => ({
  type: commentsActions.UPDATE_COMMENTS,
  value: commentList
})

export const getCommentTypesAction = () => ({
  type: commentsActions.GET_COMMENT_TYPES
})

export const getCommentTypesSuccess = response => ({
  type: commentsActions.GET_COMMENT_TYPES_SUCCESS,
  value: response
})

export const getCommentTypesFailure = () => ({
  type: commentsActions.GET_COMMENT_TYPES_FAILURE
})
