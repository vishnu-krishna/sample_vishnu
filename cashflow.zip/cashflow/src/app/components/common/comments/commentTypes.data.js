/**
 * Comment types _may_ come in from the back end in different order,
 * and our tabs are dynamically created based on this data
 *
 * For consistency of user experience we must store the expected ordering
 *
 * Intuitively one assumes a numeric sort of the IDs would be enough, but
 * without clear requirements we can't assume intuitiveness :)
 */
export const commentTypesOrderedList = [
  '02', // Business proposal,
  '11', // Character
  '12', // Capacity
  '13', // Capital/Collateral
  '10' // Additional notes
]

export const ANZ_SOURCE_SYSTEM = 'BBD_CASHFLOW_APP'
/**
 * NULL comments get a default template of text inserted
 * This structure contains mapping from `commentTypeId` to expected
 * default text
 *
 * This seems more like functionality which should be in the BFF
 */
export const commentTypesDefaultText = {
  // Business proposal
  '02': `<p><strong>What is the purpose of the proposed funding?</strong></p><p>(E.g. purchase of business/property, working capital, business expansion, if a refinance, confirm original loan purpose etc.)</p><p>&nbsp;</p><p><strong>Provide a breakdown of the funding being requested?</strong></p><p>(E.g. start-up costs, goodwill, stock, plant &amp; equipment, IG etc.)</p><p>&nbsp;</p><p><strong>Comment on the proposed loan term and interest only term, if applicable?</strong></p><p>(Are the terms in line with Lease/Franchise terms, loan purpose etc. Provide commentary on any variances, explain why customer has sought interest only period.)</p><p>&nbsp;</p><p><strong>What contribution is the customer making to the proposal?&nbsp;<br /> If cash, how much and where is the contribution being sourced from?</strong></p><p>(E.g. savings, borrowings/gift from family (if borrowings, what terms are associated with this?, if gift, what evidence is available?.)</p><p>&nbsp;</p><p><strong>Why are you recommending approval of this proposal?</strong></p><p>(Highlight some of the factors that make this application appealing to ANZ.)</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p>`,
  // Additional notes
  '10': `<p><strong>Are you seeking any waivers, exceptions or AST's as part of your application?</strong></p><p>(If so, please provide a detailed explanation of why and provide supporting documents where applicable.)</p><p>&nbsp;</p>`,
  // Character
  '11': `<p><strong>Who is the customer?</strong></p><p>(Provide background of the owners, directors, shareholders, trustee(s), beneficiaries and their experience and/or influence on the management/decision making of the business.)</p><p>&nbsp;</p><p><strong>Is this a start-up application?</strong></p><p>(If so, provide detailed commentary on business plan including any risks highlighted by customer.)</p><p>&nbsp;</p><p><strong>Describe the primary activities of the business and the environment in which they operate within?</strong></p><p>(Product/service they provide, the trends of the industry, location and experience of management/directors in the industry/role.)</p><p>&nbsp;</p><p><strong>Is there any adverse account conduct evident either with ANZ or an OFI?&nbsp;<br /> If so, are there any mitigants?</strong></p><p>(Provide evidence where possible.)</p><p>&nbsp;</p><p><strong>Does the customer have any outstanding tax/statutory payments or legal action pending/underway?</strong></p><p>(If so, please provide detailed commentary and supporting documentation, where available.)</p><p>&nbsp;</p><p>&nbsp;</p>`,
  // Capacity
  '12': `<p><strong>Is capacity to service evident according to standardised CTS policy?</strong></p><p>(Explain how UMI has been derived, including commentary on any addbacks, justifications or considerations to the CTS calculation e.g. rent not continuing.)</p><p>&nbsp;</p><p><strong>Explain any trends in the businesses financials, both positive and negative, highlighting any substantial variations</strong></p><p>(Revenue, profit, expenses, assets or liabilities.)</p><p>&nbsp;</p><p><strong>Are all liabilities on the Balance Sheet and PPSR Search correctly disclosed?</strong></p><p>(E.g. business loans, asset finance/hire purchase, overdrafts, credit cards, director/s &amp;/or other party loans etc.)</p><p>&nbsp;</p><p><strong>If Cash flow forecast is required, have you reviewed and tested whether it is realistic and achievable?&nbsp;<br /> Comment on assumptions and crucial aspects of the forecast.</strong></p><p>(Consider reviewing relevant IBIS Industry Report/s.)</p><p>&nbsp;</p><p><strong>If this proposal is for a panel franchise system, have the Key Performance indicators (KPIs) been tested against franchise insights?</strong></p><p>(Provide commentary and detail of any variances.)</p><p>&nbsp;</p><p>&nbsp;</p>`,
  // Capital/Collateral
  '13': `<p><strong>Is there security being provided as part of this proposal?</strong></p><p>(If so, comment on the suitability of the security and any risk/exposure to ANZ.)</p><p>&nbsp;</p><p><strong>Will there be any third party guarantor(s) as part of this proposal?&nbsp;<br />If so, review and comment on the suitability of the guarantee/s?</strong></p><p>(E.g. benefits to guarantor, ability for guarantor to repay etc.)</p><p>&nbsp;</p><p><strong>Is a GSA being taken over the business? If not, why are you seeking a waiver?</strong></p>(Refer to Small Business Credit Requirements for current policy.)</p><p>&nbsp;</p><p>&nbsp;</p>`
}
