import React from 'react'
import { storiesOf } from '@storybook/react'
import { Provider } from 'react-redux'
import configureStore from 'redux-mock-store'
import commentTypes from 'app/pages/preProcessingPage/testdata/commentTypes'
import PopupSidebar from 'app/components/common/flyinWindow/flyinWindow.component'
import Comments from './comments.component'

const mockStore = configureStore([])

const store = {
  dashboardData: {
    userDetails: {
      firstName: 'abc'
    }
  },
  preProcessingData: {
    isAppReadOnly: false,
    commentList: [],
    commentTypes: commentTypes
  }
}

storiesOf('Comments', module).add('Comment in fly-in window', () => {
  return (
    <Provider store={mockStore(store)}>
      <PopupSidebar
        contentTitle='Comments'
        contentType='comments'
        isOpen
        currentLocation=''
      >
        <Comments />
      </PopupSidebar>
    </Provider>
  )
})
