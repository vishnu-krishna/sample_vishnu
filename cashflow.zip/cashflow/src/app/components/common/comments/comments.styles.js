import styled from 'styled-components'

const Body = styled.div`
  height: 100%;
`

export { Body }
