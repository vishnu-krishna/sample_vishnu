import { getValidCommentsToUpdate, normaliseComments } from './comments.utils'
import { isDefaultCommentsModified, setCurrentTimeStamp } from 'app/components/common/comments/comments.utils'

let commentTypes, defaultCommentsList

describe('Comments Utils', () => {
  beforeEach(() => {
    commentTypes = [
      {
        commentTypeId: '02',
        name: 'Business proposal',
        description: ''
      }
    ]
    defaultCommentsList = [
      {
        id: 0,
        data:
          '<p><strong>What is the purpose of the proposed funding?</strong></p><p>(E.g. purchase of business/property, working capital, business expansion, if a refinance, confirm original loan purpose etc.)</p><p>&nbsp;</p><p><strong>Provide a breakdown of the funding being requested?</strong></p><p>(E.g. start-up costs, goodwill, stock, plant &amp; equipment, IG etc.)</p><p>&nbsp;</p><p><strong>Comment on the proposed loan term and interest only term, if applicable?</strong></p><p>(Are the terms in line with Lease/Franchise terms, loan purpose etc. Provide commentary on any variances, explain why customer has sought interest only period.)</p><p>&nbsp;</p><p><strong>What contribution is the customer making to the proposal?&nbsp;<br> If cash, how much and where is the contribution being sourced from?</strong></p><p>(E.g. savings, borrowings/gift from family (if borrowings, what terms are associated with this?, if gift, what evidence is available?.)</p><p>&nbsp;</p><p><strong>Why are you recommending approval of this proposal?</strong></p><p>(Highlight some of the factors that make this application appealing to ANZ.)</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p>',
        commentTypeId: '02',
        commentsType: '02',
        firstName: 'Adam',
        lastName: 'Treloar',
        tabIndex: 0,
        format: 'Text',
        sourceSystem: 'BBD_CASHFLOW_APP'
      },
      {
        id: 0,
        data:
          "<p><strong>Are you seeking any waivers, exceptions or AST's as part of your application?</strong></p><p>(If so, please provide a detailed explanation of why and provide supporting documents where applicable.)</p><p>&nbsp;</p>",
        commentTypeId: '10',
        commentsType: '10',
        firstName: 'Adam',
        lastName: 'Treloar',
        tabIndex: 1,
        format: 'Text',
        sourceSystem: 'BBD_CASHFLOW_APP'
      },
      {
        id: 0,
        data:
          '<p><strong>Who is the customer?</strong></p><p>(Provide background of the owners, directors, shareholders, trustee(s), beneficiaries and their experience and/or influence on the management/decision making of the business.)</p><p>&nbsp;</p><p><strong>Is this a start-up application?</strong></p><p>(If so, provide detailed commentary on business plan including any risks highlighted by customer.)</p><p>&nbsp;</p><p><strong>Describe the primary activities of the business and the environment in which they operate within?</strong></p><p>(Product/service they provide, the trends of the industry, location and experience of management/directors in the industry/role.)</p><p>&nbsp;</p><p><strong>Is there any adverse account conduct evident either with ANZ or an OFI?&nbsp;<br /> If so, are there any mitigants?</strong></p><p>(Provide evidence where possible.)</p><p>&nbsp;</p><p><strong>Does the customer have any outstanding tax/statutory payments or legal action pending/underway?</strong></p><p>(If so, please provide detailed commentary and supporting documentation, where available.)</p><p>&nbsp;</p><p>&nbsp;</p>',
        commentTypeId: '11',
        commentsType: '11',
        firstName: 'Adam',
        lastName: 'Treloar',
        tabIndex: 2,
        format: 'Text',
        sourceSystem: 'BBD_CASHFLOW_APP'
      },
      {
        id: 0,
        data:
          '<p><strong>Is capacity to service evident according to standardised CTS policy?</strong></p><p>(Explain how UMI has been derived, including commentary on any addbacks, justifications or considerations to the CTS calculation e.g. rent not continuing.)</p><p>&nbsp;</p><p><strong>Explain any trends in the businesses financials, both positive and negative, highlighting any substantial variations</strong></p><p>(Revenue, profit, expenses, assets or liabilities.)</p><p>&nbsp;</p><p><strong>Are all liabilities on the Balance Sheet and PPSR Search correctly disclosed?</strong></p><p>(E.g. business loans, asset finance/hire purchase, overdrafts, credit cards, director/s &amp;/or other party loans etc.)</p><p>&nbsp;</p><p><strong>If Cash flow forecast is required, have you reviewed and tested whether it is realistic and achievable?&nbsp;<br /> Comment on assumptions and crucial aspects of the forecast.</strong></p><p>(Consider reviewing relevant IBIS Industry Report/s.)</p><p>&nbsp;</p><p><strong>If this proposal is for a panel franchise system, have the Key Performance indicators (KPIs) been tested against franchise insights?</strong></p><p>(Provide commentary and detail of any variances.)</p><p>&nbsp;</p><p>&nbsp;</p>',
        commentTypeId: '12',
        commentsType: '12',
        firstName: 'Adam',
        lastName: 'Treloar',
        tabIndex: 3,
        format: 'Text',
        sourceSystem: 'BBD_CASHFLOW_APP'
      },
      {
        id: 0,
        data:
          '<p><strong>Is there security being provided as part of this proposal?</strong></p><p>(If so, comment on the suitability of the security and any risk/exposure to ANZ.)</p><p>&nbsp;</p><p><strong>Will there be any third party guarantor(s) as part of this proposal?&nbsp;<br />If so, review and comment on the suitability of the guarantee/s?</strong></p><p>(E.g. benefits to guarantor, ability for guarantor to repay etc.)</p><p>&nbsp;</p><p><strong>Is a GSA being taken over the business? If not, why are you seeking a waiver?</strong></p>(Refer to Small Business Credit Requirements for current policy.)</p><p>&nbsp;</p><p>&nbsp;</p>',
        commentTypeId: '13',
        commentsType: '13',
        firstName: 'Adam',
        lastName: 'Treloar',
        tabIndex: 4,
        format: 'Text',
        sourceSystem: 'BBD_CASHFLOW_APP'
      }
    ]
  })

  it('should return default comments for all the commentTypes', () => {
    const defaultComment =
      '<p><strong>What is the purpose of the proposed funding?</strong></p><p>(E.g. purchase of business/property, working capital, business expansion, if a refinance, confirm original loan purpose etc.)</p><p>&nbsp;</p><p><strong>Provide a breakdown of the funding being requested?</strong></p><p>(E.g. start-up costs, goodwill, stock, plant &amp; equipment, IG etc.)</p><p>&nbsp;</p><p><strong>Comment on the proposed loan term and interest only term, if applicable?</strong></p><p>(Are the terms in line with Lease/Franchise terms, loan purpose etc. Provide commentary on any variances, explain why customer has sought interest only period.)</p><p>&nbsp;</p><p><strong>What contribution is the customer making to the proposal?&nbsp;<br /> If cash, how much and where is the contribution being sourced from?</strong></p><p>(E.g. savings, borrowings/gift from family (if borrowings, what terms are associated with this?, if gift, what evidence is available?.)</p><p>&nbsp;</p><p><strong>Why are you recommending approval of this proposal?</strong></p><p>(Highlight some of the factors that make this application appealing to ANZ.)</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p>'
    const normalizedComments = normaliseComments([], commentTypes, {
      firstName: 'first',
      lastName: 'last'
    })
    const { normalisedComments, commentType } = normalizedComments
    expect(commentType.length).toBe(1)
    expect(normalisedComments[0].commentsType).toBe('02')
    expect(normalisedComments[0].data).toBe(defaultComment)
  })

  it('should return saved comments along with default comments for all the commentTypes', () => {
    let appCommentList = [
      {
        id: 1,
        commentsType: '02',
        data: '<p><strong>sample comment</strong></p>'
      }
    ]
    commentTypes.push({
      commentTypeId: '11',
      name: 'Additional notes',
      description: ''
    })
    const normalizedComments = normaliseComments(appCommentList, commentTypes, {
      firstName: 'first',
      lastName: 'last'
    })
    const { normalisedComments, commentType } = normalizedComments
    expect(commentType.length).toBe(2)
    expect(normalisedComments[0].data).toBe(appCommentList[0].data)
    expect(normalisedComments[1].data).toBe(
      '<p><strong>Who is the customer?</strong></p><p>(Provide background of the owners, directors, shareholders, trustee(s), beneficiaries and their experience and/or influence on the management/decision making of the business.)</p><p>&nbsp;</p><p><strong>Is this a start-up application?</strong></p><p>(If so, provide detailed commentary on business plan including any risks highlighted by customer.)</p><p>&nbsp;</p><p><strong>Describe the primary activities of the business and the environment in which they operate within?</strong></p><p>(Product/service they provide, the trends of the industry, location and experience of management/directors in the industry/role.)</p><p>&nbsp;</p><p><strong>Is there any adverse account conduct evident either with ANZ or an OFI?&nbsp;<br /> If so, are there any mitigants?</strong></p><p>(Provide evidence where possible.)</p><p>&nbsp;</p><p><strong>Does the customer have any outstanding tax/statutory payments or legal action pending/underway?</strong></p><p>(If so, please provide detailed commentary and supporting documentation, where available.)</p><p>&nbsp;</p><p>&nbsp;</p>'
    )
  })

  it('should return zero records if we have only default comments', () => {
    const validComments = getValidCommentsToUpdate(defaultCommentsList)
    expect(validComments.length).toBe(0)
  })

  it('should return the current timestamp set based on mock', () => {
    const mockDate = new Date(1466424490000)
    const dateSpy = jest
      .spyOn(global, 'Date')
      .mockImplementation(() => mockDate)
    const timeStampWhichHasBeenSet = setCurrentTimeStamp()
    expect(timeStampWhichHasBeenSet).toBe('2016-06-20 12:08:00.000')
    dateSpy.mockRestore()
  })

  it('should return only records if we have comments that is different from defaults and also append the createdDate to the comments object', () => {
    let commentsList = [...defaultCommentsList]
    const mockDate = new Date(1466424490000)
    const dateSpy = jest
      .spyOn(global, 'Date')
      .mockImplementation(() => mockDate)
    commentsList[0].data = '<p><strong>sample comment</strong></p>'
    const validComments = getValidCommentsToUpdate(commentsList)
    expect(validComments.length).toBe(1)
    expect(validComments[0].createdDate).toBe('2016-06-20 12:08:00.000')
    dateSpy.mockRestore()
  })

  const commentList = [
    {
      id: 0,
      data: '<p>Test</p>',
      commentTypeId: '02',
      commentsType: '02',
      firstName: 'Adam',
      lastName: 'Treloar',
      tabIndex: 0,
      format: 'Text',
      sourceSystem: 'BBD_CASHFLOW_APP'
    }
  ]

  it('should return FALSE when the commentList is not present', () => {
    const applicationComments = [
      {
        id: 0,
        data: '<p>Test1</p>',
        commentTypeId: '02',
        commentsType: '02',
        firstName: 'Adam',
        lastName: 'Treloar',
        tabIndex: 0,
        format: 'Text',
        sourceSystem: 'BBD_CASHFLOW_APP'
      }
    ]
    expect(isDefaultCommentsModified(undefined, applicationComments)).toBe(
      false
    )
  })


  it(`should return TRUE when the commentList's length is greater than applicationComments length`, () => {
    const applicationComments = [
      {
        id: 0,
        data: '<p>Test1</p>',
        commentTypeId: '02',
        commentsType: '02',
        firstName: 'Adam',
        lastName: 'Treloar',
        tabIndex: 0,
        format: 'Text',
        sourceSystem: 'BBD_CASHFLOW_APP'
      }
    ]

    const modifiedCommentList = [
      {
        id: 0,
        data: '<p>Test</p>',
        commentTypeId: '02',
        commentsType: '02',
        firstName: 'Adam',
        lastName: 'Treloar',
        tabIndex: 0,
        format: 'Text',
        sourceSystem: 'BBD_CASHFLOW_APP'
      },
      {
        id: 1,
        data: '<p>Test</p>',
        commentTypeId: '03',
        commentsType: '03',
        firstName: 'Adam',
        lastName: 'Treloar',
        tabIndex: 0,
        format: 'Text',
        sourceSystem: 'BBD_CASHFLOW_APP'
      }
    ]
    expect(isDefaultCommentsModified(modifiedCommentList, applicationComments)).toBe(
      true
    )
  })

  it('should return TRUE when the default comments are modified', () => {
    const applicationComments = [
      {
        id: 0,
        data: '<p>Test1</p>',
        commentTypeId: '02',
        commentsType: '02',
        firstName: 'Adam',
        lastName: 'Treloar',
        tabIndex: 0,
        format: 'Text',
        sourceSystem: 'BBD_CASHFLOW_APP'
      }
    ]
    expect(isDefaultCommentsModified(commentList, applicationComments)).toBe(
      true
    )
  })

  it('should return FALSE when the default comments are NOT modified', () => {
    const applicationComments = [
      {
        id: 0,
        data: '<p>Test</p>',
        commentTypeId: '02',
        commentsType: '02',
        firstName: 'Adam',
        lastName: 'Treloar',
        tabIndex: 0,
        format: 'Text',
        sourceSystem: 'BBD_CASHFLOW_APP'
      }
    ]

    expect(isDefaultCommentsModified(commentList, applicationComments)).toBe(
      false
    )
  })
})
