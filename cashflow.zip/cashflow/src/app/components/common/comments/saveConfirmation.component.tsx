import React, { FC, Dispatch } from 'react'
import { ContentPane } from 'app/components/app/appModal/appModal.styles'
import { Heading } from 'app/common/main.styles'
import { ButtonPanel } from 'app/components/ButtonPanel/buttonPanel.component'
import { hideAppModalAction } from 'app/actions'
import { saveCommentsAction, updateNormalisedCommentsAction, saveCommentsActionFromModal } from 'app/components/common/comments/actions'
import { useDispatch } from 'react-redux'

interface SaveConfirmationProps {
  setCommentsFlyinVisible: Dispatch<boolean>,
}

export const CommentsSaveConfirmation: FC<SaveConfirmationProps> = ({ setCommentsFlyinVisible }) => {
  const dispatch = useDispatch()
  const onPrimaryButtonClick = () => {
    dispatch(saveCommentsActionFromModal())
    dispatch(saveCommentsAction())
    dispatch(updateNormalisedCommentsAction())
    dispatch(hideAppModalAction())
    setCommentsFlyinVisible(false)
  }

  return (
    <ContentPane data-test-id='modal-save-confirmation-application'>
      <Heading>Changes have been made to the comments section, do you want to save?</Heading>
      <ButtonPanel
        primaryButtonText='Save'
        primaryButtonClicked={onPrimaryButtonClick}
        secondaryButtonText='Cancel'
        secondaryButtonClicked={() => {
          dispatch(hideAppModalAction())
        }}
        isSecondaryButtonDisabled={false}
      />
    </ContentPane>
  )
}