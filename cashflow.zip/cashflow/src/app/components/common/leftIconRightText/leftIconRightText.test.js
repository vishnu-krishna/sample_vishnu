import { render } from '@testing-library/react'
import React from 'react'
import { LeftIconRightText } from 'app/components/common/leftIconRightText/leftIconRightText.component'

function performAssertion (container, element) {
  const selectedElement = container.querySelector(`.${element}`)
  expect(selectedElement).toBeInTheDocument()
}

describe('LeftIconRightText Component', () => {
  test('should contain success icon', () => {
    const { container } = render(
      <LeftIconRightText rightText={'Some Right Text'} iconType={'Success'} />
    )
    performAssertion(container, 'success')
  })
  test('should contain warning icon', () => {
    const { container } = render(
      <LeftIconRightText rightText={'Some Right Text'} iconType={'Warning'} />
    )
    performAssertion(container, 'warning')
  })
  test('should contain failure icon', () => {
    const { container } = render(
      <LeftIconRightText rightText={'Some Right Text'} iconType={'Failure'} />
    )
    performAssertion(container, 'failure')
  })
  test('should contain checkbox icon', () => {
    const { container } = render(
      <LeftIconRightText rightText={'Some Right Text'} iconType={'Checkbox'} />
    )
    performAssertion(container, 'checkbox')
  })
})
