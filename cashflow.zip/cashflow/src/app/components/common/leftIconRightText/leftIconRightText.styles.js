import styled from 'styled-components'

export const LeftIconRightTextWrapper = styled.div`
  display: flex;
  padding: 10px 0;
`
export const RightText = styled.div`
  padding-left: 10px;
  font-weight: ${props => (props.bold ? 'bold' : 'normal')};
`

export const IconWrapper = styled.div`
  margin: 0 20px;
`
