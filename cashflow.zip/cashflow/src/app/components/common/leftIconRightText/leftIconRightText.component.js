import React from 'react'
import PropTypes from 'prop-types'
import {
  IconWrapper,
  LeftIconRightTextWrapper,
  RightText
} from 'app/components/common/leftIconRightText/leftIconRightText.styles'
import WarningIcon from '@anz/icon/dist/filled/arrows-and-symbols/warning-alert'
import styleVars from '@anz/styles-global'
import SuccessIcon from '@anz/icon/dist/filled/arrows-and-symbols/success'
import CancelIcon from '@anz/icon/dist/filled/arrows-and-symbols/cancel-fail-line'
import SuccessIconLine from '@anz/icon/dist/filled/arrows-and-symbols/success-line'

export const iconTypes = ['Success', 'Failure', 'Warning', 'Checkbox']
const iconJsx = {
  Success: (
    <SuccessIcon color={styleVars.color.system.success} className='success' />
  ),
  Failure: (
    <CancelIcon color={styleVars.color.system.error} className='failure' />
  ),
  Warning: (
    <WarningIcon color={styleVars.color.system.warning} className='warning' />
  ),
  Checkbox: (
    <SuccessIconLine
      color={styleVars.color.core.linkBlue}
      className='checkbox'
    />
  )
}

function setIconBasedOnIconType (inputIconType) {
  const matchedIconType = iconTypes.find(iconType => iconType === inputIconType)
  return matchedIconType && iconJsx[matchedIconType]
}

export const LeftIconRightText = ({
  iconType = 'Success',
  rightText = '',
  bold = false
}) => {
  return (
    <LeftIconRightTextWrapper>
      <IconWrapper>{setIconBasedOnIconType(iconType)}</IconWrapper>
      <RightText bold={bold}>{rightText}</RightText>
    </LeftIconRightTextWrapper>
  )
}

LeftIconRightText.propTypes = {
  iconType: PropTypes.oneOf(iconTypes),
  rightText: PropTypes.string,
  bold: PropTypes.bool
}
