import React from 'react'
import PropTypes from 'prop-types'
import { SearchForCapIdContainer } from './searchForCapId.styles'
import TextField from '@anz/text-field'
import SearchIcon from '@anz/icon/dist/filled/generic/search'

const MAX_CAP_ID_LENGTH = '10'

export const searchForCapIdTestIdContainer = 'search-cap-id-container'

export const SearchForCapId = ({
  id = 'search-cap-id',
  value,
  onChange,
  labelTop,
  labelBottom,
  invalid = false,
  placeholder = 'Enter customer number (CAP)'
}) => {
  return (
    <SearchForCapIdContainer
      data-input-type='input'
      id={`${id}-container`}
      data-test-id={searchForCapIdTestIdContainer}
      error={invalid}
    >
      <TextField
        id={id}
        afterField={<SearchIcon />}
        type='text'
        value={value}
        onChange={onChange}
        label={labelTop}
        subLabel={labelBottom}
        maxLength={MAX_CAP_ID_LENGTH}
        placeholder={placeholder}
      />
    </SearchForCapIdContainer>
  )
}

SearchForCapId.propTypes = {
  id: PropTypes.string,
  value: PropTypes.any,
  name: PropTypes.string,
  labelTop: PropTypes.string,
  labelBottom: PropTypes.oneOfType([PropTypes.string, PropTypes.node]),
  onChange: PropTypes.func,
  invalid: PropTypes.bool,
  placeholder: PropTypes.string
}
