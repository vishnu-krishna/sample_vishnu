import { render } from '@testing-library/react'
import React from 'react'
import { SearchForCapId } from './searchForCapId.component'
import { defaultProps } from './searchForCapId.stories'

const labelTop = 'Display ANZ customer information (CAP ID)'

describe('SearchForCapId Component', () => {
  test('SearchForCapId has a 10-char limit', async () => {
    const wrapper = render(
      <SearchForCapId labelTop={labelTop} {...defaultProps} />
    )
    const { getByTestId } = wrapper
    const input = getByTestId(`${defaultProps.id}_input`)

    expect(input).toHaveAttribute('maxlength', '10')
  })
})
