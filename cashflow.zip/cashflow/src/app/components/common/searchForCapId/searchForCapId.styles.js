import styled from 'styled-components'
import styleVars from '@anz/styles-global'

export const SearchForCapIdContainer = styled.div`
  display: flex;
  flex-flow: column;
  justify-content: center;

  input {
    border: ${({ error }) =>
      error && `1px solid ${styleVars.color.system.error}`};
  }
`
