import { storiesOf } from '@storybook/react'
import React from 'react'
import { SearchForCapId } from './searchForCapId.component'

export const defaultProps = {
  id: 'search-cap-id',
  name: 'search-cap-name',
  labelTop: 'ANZ'
}

export const withCustomTopAndBottomLabelsProps = {
  id: 'search-cap-id',
  name: 'search-cap-name',
  labelTop: 'ANZ',
  labelBottom: 'Australia and New Zealand Banking Group'
}

export const withResultProps = {
  id: 'search-cap-id',
  name: 'search-cap-name',
  results: [
    {
      label: 'CAP ID 0123456789'
    }
  ],
  labelTop: "Search using borrowing entity's CAP ID",
  labelBottom: 'Enter CAP ID to search or change the information below',
  onChange: e => console.log(e.target.value),
  onResultSelect: selectedItem => {
    alert(selectedItem)
  }
}

storiesOf('SearchForCapId Component', module).add('Default', () => (
  <SearchForCapId {...defaultProps} />
))

storiesOf('SearchForCapId Component', module).add('With custom labels', () => (
  <SearchForCapId {...withCustomTopAndBottomLabelsProps} />
))
