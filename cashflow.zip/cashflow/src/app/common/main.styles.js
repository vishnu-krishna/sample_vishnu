import styled, { css } from 'styled-components'
import styleVars from '@anz/styles-global'

export const PrimaryFont = css`
  font-family: 'Myriad Pro', sans-serif;
`

/* Preprocessing */
export const AlternateRowBackground = (colorOdd, colorEven) => css`
  background-color: ${colorEven};
  &:nth-of-type(odd) {
    background-color: ${colorOdd};
  }
`

export const Heading = styled.span`
  display: block;
  font-size: 22px;
  padding: 0 10px 15px;
  font-weight: 400;
  svg {
    color: ${styleVars.color.core.linkBlue};
    margin-right: 5px;
    height: 24px;
    width: 24px;
  }
`

export const ColumnWrapper = styled.div`
  flex: 0 0 33.33%;
  margin-bottom: 30px;
`

export const ColumnInnerContainer = styled.div`
  padding: 0 20px;
`

export const StaticContent = styled.div`
  margin-left: 15px;
`
export const SectionWrapper = styled.div`
  margin-top: 48px;
`
export const TitleWrapper = styled.div`
  max-width: 11em;
  vertical-align: bottom;
  display: inline-block;
`
