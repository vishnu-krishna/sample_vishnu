export const AppActions = {
  AUTHENTICATION_PASSED: 'app.authentication.passed',
  AUTHENTICATION_FAILED: 'app.authentication.failed',
  SHOW_MODAL: 'app.modal.show',
  HIDE_MODAL: 'app.modal.hide',
  SHOW_BACKGROUND_SPINNER: 'app.spinner.background.show',
  HIDE_BACKGROUND_SPINNER: 'app.spinner.background.hide',
  SHOW_ALERT: 'app.alert.show',
  HIDE_ALERT: 'app.alert.hide',
  GET_PARTY_REFERENCES: 'app.party.references.get',
  GET_PARTY_REFERENCES_SUCCESS: 'app.party.references.get.success',
  GET_PARTY_REFERENCES_FAILURE: 'app.party.references.get.failure'
}

export const showAppModalAction = content => ({
  type: AppActions.SHOW_MODAL,
  value: content
})
export const hideAppModalAction = () => ({
  type: AppActions.HIDE_MODAL
})
export const showAppBgSpinnerAction = () => ({
  type: AppActions.SHOW_BACKGROUND_SPINNER
})
export const hideAppBgSpinnerAction = () => ({
  type: AppActions.HIDE_BACKGROUND_SPINNER
})
export const showAlertAction = (reason, content) => ({
  type: AppActions.SHOW_ALERT,
  value: { reason, content }
})
export const hideAlertAction = () => ({
  type: AppActions.HIDE_ALERT
})
export const getPartyReferencesAction = () => ({
  type: AppActions.GET_PARTY_REFERENCES
})
export const getPartyReferencesSuccessAction = partyProperties => ({
  type: AppActions.GET_PARTY_REFERENCES_SUCCESS,
  value: partyProperties
})
export const getPartyReferencesFailureAction = () => ({
  type: AppActions.GET_PARTY_REFERENCES_FAILURE
})
