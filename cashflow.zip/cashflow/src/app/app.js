import React, { useEffect, useState } from 'react'
import { useSelector } from 'react-redux'
import { LocationProvider, Router } from '@reach/router'

import usrMgr, { authenticateFormFallback, authorize } from '@anz/user-manager'

import { SecuredRoute } from 'app/components/common/securedRoute/securedRoute.component'
import { PAGES } from 'app/pages/constants'
import {
  AppActions,
  getPartyReferencesAction,
  showAppModalAction
} from 'app/actions'
import { AppContainer, StickyFooter, Wrapper } from 'app/app.styles'
import AppModal from './components/app/appModal/appModal.connect'
import { AppHeader } from 'app/components/app/appHeader/appHeader.component'
import { AppAlert } from 'app/components/app/appAlert/appAlert.component'
import FlyinWindow from 'app/components/common/flyinWindow/flyinWindow.component'
import Comments from 'app/components/common/comments/comments.component'
import { getCommentTypesAction } from 'app/components/common/comments/actions'
import Documents from 'app/components/preProcessing/documents/documents.component'
import { SearchAside } from 'app/search/search.component'
import { pickValue } from 'app/utils/appUtils'
import { getUserInfoDetailsAction } from 'app/pages/cfDashboardPage/actions'
import { isDefaultCommentsModified } from 'app/components/common/comments/comments.utils'
import { CommentsSaveConfirmation } from 'app/components/common/comments/saveConfirmation.component'
import PropTypes from 'prop-types'

export const AppContext = React.createContext(null)

export const App = ({
  modal,
  alert,
  userInfo,
  authenticating,
  showBgSpinner,
  dispatch
}) => {
  const commentList = useSelector(state => state.preProcessingData.commentList)
  const applicationComments = useSelector(state =>
    pickValue(state, 'preProcessingData.applicationComments')
  )
  const [isDocumentsFlyinVisible, setDocumentsFlyinVisibility] = useState(false)
  const [isCommentsFlyinVisible, setCommentsFlyinVisible] = useState(false)

  const [isSearchFlyinVisible, setSearchFlyinVisible] = useState(false)
  window.setSearchFlyinVisible = setSearchFlyinVisible

  const applicationId = useSelector(state =>
    pickValue(
      state,
      'preProcessingData.olaApplication.application.applicationId'
    )
  )

  const toggleSpinner = loading => {
    if (loading) {
      dispatch({ type: AppActions.SHOW_BACKGROUND_SPINNER })
    } else {
      dispatch({ type: AppActions.HIDE_BACKGROUND_SPINNER })
    }
  }

  const closeCommentsAndSaveApp = setCommentsFlyinVisible => {
    if (isDefaultCommentsModified(commentList, applicationComments)) {
      dispatch(
        showAppModalAction({
          content: (
            <CommentsSaveConfirmation
              setCommentsFlyinVisible={setCommentsFlyinVisible}
            />
          )
        })
      )
    } else {
      setCommentsFlyinVisible(false)
    }
  }

  useEffect(() => {
    authorize(usrMgr).payload.catch(() => {
      dispatch({ type: AppActions.AUTHENTICATION_FAILED })
      authenticateFormFallback(usrMgr)
    })

    usrMgr.events.addUserLoaded(oidcUserInfo => {
      // TODO: validate the user scope and then set the state.
      dispatch({ type: AppActions.AUTHENTICATION_PASSED, value: oidcUserInfo })
      dispatch(getPartyReferencesAction())
      dispatch(getCommentTypesAction())
      dispatch(getUserInfoDetailsAction())
    })

    usrMgr.events.addSilentRenewError(() => {
      dispatch({ type: AppActions.AUTHENTICATION_FAILED })
      authenticateFormFallback(usrMgr)
    })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const onSearchClick = () => {
    if (isDefaultCommentsModified(commentList, applicationComments)) {
      closeCommentsAndSaveApp(setCommentsFlyinVisible)
    } else {
      setDocumentsFlyinVisibility(false)
      setSearchFlyinVisible(!isSearchFlyinVisible)
      setCommentsFlyinVisible(false)
    }
  }

  const onDocumentsClick = () => {
    if (isDefaultCommentsModified(commentList, applicationComments)) {
      closeCommentsAndSaveApp(setCommentsFlyinVisible)
    } else {
      setDocumentsFlyinVisibility(!isDocumentsFlyinVisible)
      setSearchFlyinVisible(false)
      setCommentsFlyinVisible(false)
    }
  }

  const onCommentsClick = () => {
    setDocumentsFlyinVisibility(false)
    setSearchFlyinVisible(false)
    setCommentsFlyinVisible(!isDocumentsFlyinVisible)
  }
  return (
    <LocationProvider>
      {({ location }) => {
        const currentLocation = location.pathname
        return (
          <AppContext.Provider value={{ userInfo, authenticating }}>
            <Wrapper>
              <AppHeader
                currentLocation={currentLocation}
                showSpinner={showBgSpinner}
                applicationId={applicationId}
                onSearchClick={onSearchClick}
                onDocumentsClick={onDocumentsClick}
                onCommentsClick={onCommentsClick}
              />
              <AppContainer>
                <Router>
                  <SecuredRoute
                    path={PAGES.preProcessing.path}
                    pageName={PAGES.preProcessing.name}
                  />
                  <SecuredRoute
                    path={PAGES.dashboard.path}
                    pageName={PAGES.dashboard.name}
                    default
                  />
                </Router>
              </AppContainer>
              <StickyFooter maxWidth='auto' />
              {modal && <AppModal modal={modal} />}
              {alert && <AppAlert {...alert} />}
              <FlyinWindow
                title='Documents'
                currentLocation={currentLocation}
                isOpen={isDocumentsFlyinVisible}
                onClose={setDocumentsFlyinVisibility}
                initTopPad={60}
                maxWidth={1200}
              >
                {isDocumentsFlyinVisible && (
                  <Documents
                    applicationId={applicationId}
                    toggleSpinner={toggleSpinner}
                  />
                )}
              </FlyinWindow>
              <FlyinWindow
                title='Comments'
                currentLocation={currentLocation}
                isOpen={isCommentsFlyinVisible}
                onClose={() => closeCommentsAndSaveApp(setCommentsFlyinVisible)}
                initTopPad={60}
                maxWidth={1200}
              >
                <Comments />
              </FlyinWindow>

              <FlyinWindow
                title='Search'
                currentLocation={currentLocation}
                isOpen={isSearchFlyinVisible}
                onClose={setSearchFlyinVisible}
                initTopPad={60}
                maxWidth={700}
              >
                <SearchAside setSearchFlyinVisible={setSearchFlyinVisible} />
              </FlyinWindow>
            </Wrapper>
          </AppContext.Provider>
        )
      }}
    </LocationProvider>
  )
}
App.propTypes = {
  modal: PropTypes.any,
  alert: PropTypes.any,
  userInfo: PropTypes.any,
  authenticating: PropTypes.any,
  showBgSpinner: PropTypes.any,
  dispatch: PropTypes.any
}
