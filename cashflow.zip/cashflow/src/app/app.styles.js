import styled from 'styled-components'
import Footer from '@anz/footer'

export const Wrapper = styled.div`
  font-family: 'Myriad Pro', sans-serif;
  font-weight: 400;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  min-height: 100vh;
`

export const StickyFooter = styled(Footer)`
  align-self: flex-end;
  width: 100%;
`
export const AppContainer = styled.div`
  min-height: 80vh;
`
