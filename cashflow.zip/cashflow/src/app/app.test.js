import React from 'react'
import { render } from '@testing-library/react'
import { Provider } from 'react-redux'
import mockUsrMgr, { authenticateFormFallback } from '@anz/user-manager'
import App from 'app/app.connect'
import store from 'store'
import { LocationProvider } from '@reach/router'

jest.mock('app/components/preProcessing/documents/httpConfig', () => ({
  __esModule: true,
  axios: jest.mock('axios', () => ({
    __esModule: true,
    get: jest.fn(() => Promise.resolve({ data: 'data' })),
    default: jest.fn(() => Promise.resolve({ data: 'data' }))
  })),
  setAuthorization: jest.fn()
}))

jest.mock('@anz/user-manager', () => {
  const eventCallbacks = {}
  return {
    __esModule: true,
    default: {
      events: {
        addUserLoaded: fn => {
          eventCallbacks.loaded = fn
        },
        addSilentRenewError: fn => {
          eventCallbacks.error = fn
        }
      },
      mockAction: {
        loaded: oidcUserInfo => eventCallbacks.loaded(oidcUserInfo),
        renewError: () => eventCallbacks.error(),
        expired: () => eventCallbacks.expired(),
        unloaded: () => eventCallbacks.unloaded()
      },
      stopSilentRenew: () => {},
      signoutRedirect: () => {
        return {
          then: fn => {
            fn()
          }
        }
      }
    },
    authenticateFormFallback: jest.fn(),
    authorize: () => ({
      payload: Promise.reject('usrMgr authentication error')
    })
  }
})

describe('App Root authentication and authorisation', () => {
  it('Check if App header exists', () => {
    const { getByTestId } = render(
      <LocationProvider>
        <Provider store={store}>
          <App />
        </Provider>
      </LocationProvider>
    )
    expect(getByTestId('header')).toBeDefined()
  })

  it('Check if App Footer exists', () => {
    const { getByTestId } = render(
      <LocationProvider>
        <Provider store={store}>
          <App />
        </Provider>
      </LocationProvider>
    )
    expect(getByTestId('footer')).toBeDefined()
  })

  it('App component Validate Login Success - Load dashboard component', () => {
    const oidcUserInfo = { id_token: '1234' }
    const { getByTestId } = render(
      <LocationProvider>
        <Provider store={store}>
          <App />
        </Provider>
      </LocationProvider>
    )
    mockUsrMgr.mockAction.loaded(oidcUserInfo)
    expect(getByTestId('cfDashboard')).toBeDefined()
  })

  it('App component Validate Login Failure - Redirect to authentication Form Login Screen', () => {
    mockUsrMgr.mockAction.renewError('unAuthorized')
    expect(authenticateFormFallback).toHaveBeenCalled()
  })
})
