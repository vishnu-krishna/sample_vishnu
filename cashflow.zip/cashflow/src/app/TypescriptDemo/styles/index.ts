import styled from 'styled-components'

type MainProps = {
    changeBackground: boolean;
};
// TodoApp Component
export const StyledMainWrapper = styled.button<MainProps>`
  position: absolute;
  width: 300px;
  left: 25px;
  top: 400px;
  z-index: 999;
  background: ${({ changeBackground }) => (changeBackground ? '#334752' : '#334751')};
`

// TodoList Component
export const StyledUnorderedList = styled.ul`
  list-style: none;
  width: 90%;
  max-width: 40rem;
  margin: 2rem auto;
  padding: 0;
`

export const StyledList = styled.li`
  margin: 1rem 0;
  padding: 1rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.26);
  border-radius: 6px;
  display: flex;
  justify-content: space-between;
  align-items: center;
`

export const StyledSpan = styled.span`
  color: #F0CA4D;
  font-weight: bold;
`

// NewTodo Component
export const StyledFormControl = styled.div`
  margin-bottom: 1rem;
`

export const StyledForm = styled.form`
  width: 90%;
  max-width: 40rem;
  margin: 2rem auto;
`
export const StyledLabel = styled.label`
   display: block;
   width: 100%;
   font-weight: bold;
   color: #F0CA4D;
   margin-bottom: 10px;
`
export const StyledInput = styled.input`
   display: block;
   width: 100%;
   font: inherit;
   border: 1px solid #CCCCCC;
   padding: 0.25rem;
     &:focus {
       outline: none;
       border-color: #DE4F3C;
      }
`

export const StyledDemoButton = styled.button`
   background: #DE4F3C;
   border: 1px solid #DE4F3C;
   color: white;
   padding: 0.5rem 1.5rem;
   cursor: pointer;
     &:focus {
        outline: none;
     }
     &:hover,:active {
        background: #DE4F3C;
        border-color: #DE4F3C;
     }
`
