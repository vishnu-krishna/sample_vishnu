import React, { useRef, FC } from 'react'
import { StyledInput, StyledFormControl, StyledForm, StyledLabel, StyledDemoButton } from '../styles'

interface NewTodoProps {
    onAddTodo: (todoText: string) => void;
    someOptionalProperty?: boolean
}

export const NewTodo: FC<NewTodoProps> = ({ onAddTodo }) => {
    const textInputRef = useRef<HTMLInputElement>(null)

    const todoSubmitHandler = (event: React.FormEvent) => {
        event.preventDefault()
        const enteredText = textInputRef.current!.value
        !!textInputRef.current!.value && onAddTodo(enteredText)
        textInputRef.current!.value = ''
    }

    return (
        <StyledForm onSubmit={todoSubmitHandler}>
            <StyledFormControl>
                <StyledLabel htmlFor="todo-text">Enter your Todo list below:</StyledLabel>
                <StyledInput type="text" id="todo-text" ref={textInputRef}/>
            </StyledFormControl>
            <StyledDemoButton type="submit">ADD TODO</StyledDemoButton>
        </StyledForm>
    )
}
