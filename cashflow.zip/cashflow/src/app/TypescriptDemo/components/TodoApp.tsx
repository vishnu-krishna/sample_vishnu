import React, { useState, FC } from 'react'
import { StyledMainWrapper } from '../styles'
import { NewTodo } from './NewTodo'
import { TodoList } from './TodoList'

interface Todo {
    id: string;
    text: string;
}

export const TodoApp: FC = () => {
    const [todos, setTodos] = useState<Todo[]>([])

    const todoAddHandler = (text: string) => setTodos(prevTodos => [
        ...prevTodos,
        { id: Math.random().toString(), text: text }
    ])

    const todoDeleteHandler = (todoId: string) => setTodos(prevTodos => prevTodos.filter(todo => todo.id !== todoId))
    return (
        <StyledMainWrapper changeBackground={false}>
            <NewTodo onAddTodo={todoAddHandler}/>
            <TodoList items={todos} onDeleteTodo={todoDeleteHandler}/>
        </StyledMainWrapper>
    )
}

