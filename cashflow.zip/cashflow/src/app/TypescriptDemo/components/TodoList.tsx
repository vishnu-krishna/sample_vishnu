import React, { FC } from 'react'
import { StyledUnorderedList, StyledList, StyledSpan, StyledDemoButton } from '../styles'

type itemModel = {
    id: string;
    text: string
}

interface TodoListPropsModel {
    items: itemModel[];
    onDeleteTodo: (id: string) => void;
}

export const TodoList: FC<TodoListPropsModel> = ({ items, onDeleteTodo }) => (
    <StyledUnorderedList>
        {items.map(todo => (
            <StyledList key={todo.id}>
                <StyledSpan>{todo.text}</StyledSpan>
                <StyledDemoButton onClick={() => onDeleteTodo(todo.id)}>
                    DELETE
                </StyledDemoButton>
            </StyledList>
        ))}
    </StyledUnorderedList>
)
