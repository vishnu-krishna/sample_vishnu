let utils = {
  // clean request.query before passing into find matching response
  cleanRequestQuery (requestQuery) {
    let reqQuery = JSON.stringify(requestQuery)
    let cleanedQueryString = reqQuery.replace(/\\"/g, '"')
    cleanedQueryString = cleanedQueryString
      .replace(':"{', ':{')
      .replace('}}"', '}}')
      .replace('}"}', '}}')
    return JSON.parse(cleanedQueryString)
  }
}

module.exports = utils
