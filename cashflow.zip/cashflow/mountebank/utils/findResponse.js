const _ = require('lodash')
const jexl = require('jexl')
const jwt_decode = require('jwt-decode')

let findMatchUtility = {
  /**
     *
     * @param {logger} logger
     * @param {json} request json object containing the request
     * @param {object} lookupObj
     * @param {string} lookupObj.applicableTo name to refer to the endpoint
     * @param {boolean} lookupObj.defaultResponse true/false to indicate if the response is a default response
     * @param {string} lookupObj.responseFile location of the response file within 'Templates' folder
     * @param {string} lookupObj.sideEffectRedisRequest (optional) name of redis channel to output request messages to
     * @param {string} lookupObj.sideEffectRedisResponse (optional) name of redis channel to output responses messages to
     * @param {object} lookupObj.requestMatcher object array containing matchers
     * @param {string} lookupObj.requestMatcher.match value contained in the request to be used to match against
     * @param {string} lookupObj.requestMatcher.value the expected value
     * @param {string} lookupObj.requestMatcher.comparator - if comparator has the keyword 'contains' then will match against entire xml instead
     * @param {string} lookupObj.requestMatcher.stateMatch value contained in the request to be used to match against value in stateConfig json
     * @param {string} lookupObj.requestMatcher.mapUpdates value contained in the request to be used to add/update stateConfig json
     * @param {string} lookupObj.requestMatcher.expression the xml path to look for mapUpdate within xmldoc
     * @param {string} applicableTo string value to match applicableTo against in lookupObj
     * @param {object} param object containing param values that will be replaced in request matchers
     * @param {string} param.name name of parameter to be matched to requestMatcher value
     * @param {string} param.value value of parameter to be matched to requestMatcher value
     *
     * sample lookupObj:
      {
        "applicableTo": "retrieve-all",
        "defaultResponse": false,
        "delay": "0",
        "responseFile": "aocm/AOCM-AllOrg-BUS-200000220.xml",
        "sideEffectRedisRequest": "AOCM",
        "sideEffectRedisResponse": "AOCM_response",
        "requestMatcher": [
          {
            "match": "IdentificationNumber",
            "value": "16095691213"
          }
        ]
      }
     */
  findMatchingResponseForJSON (
    logger,
    request,
    lookupObj,
    applicableTo,
    param
  ) {
    let findMatch = false
    let hasParam = false

    // ensure applicableTo is a value before continuing else return default findMatch value
    if (applicableTo || applicableTo === '') {
      let filteredMatches = _.filter(lookupObj, match => {
        return match.applicableTo === applicableTo
      })
      if (filteredMatches.length > 0) {
        logger.info(`match > applicable-to: ${applicableTo}`)

        // find matches
        findMatch = _.find(filteredMatches, match => {
          let matchesFound = false
          _.forEach(match.requestMatcher, (requestMatch, index) => {
            let matchFound = false
            let requestString = JSON.stringify(request.body)
            // logger.info(JSON.stringify(request.path))
            // let regex = RegExp(`${requestMatch.match}"\s*:\s*"(.*)`,'g');

            if (requestMatch.type == 'jexl') {
              // match using jexl request expression
              matchFound = findMatchUtility.evaluateJexlRequestExpression(
                logger,
                requestMatch,
                request,
                param
              )
            } else {
              logger.info(`Unknown request match type: ${requestMatch.type}`)
              matchFound = false
            }

            // collate results together (for mulitple request expressions)
            if (index === 0) {
              matchesFound = matchFound
            } else {
              matchesFound = matchesFound && matchFound
            }
          })

          // logger.info(`FINAL: matchesFound: ${matchesFound}`)
          return matchesFound
        })
      }
    } else {
      logger.info(`No match found in mapper file for [${applicableTo}]`)
    }

    // return match
    return findMatch
  },

  /**
   *
   * @param {logger} logger
   * @param {string} convertToCase string containing one of the options: equalsIgnoreCase, toLowerCase, to UpperCase
   * @param {string} left left string value to compare with
   * @param {string} right right string value to compare with
   * @param {boolean} hasContains true/false value to indicate if comparison is a 'contains' match
   *
   * **/
  jexlConvertToCase (convertToCase, left, right, hasContains) {
    let evalResult = false
    // setup jexl transforms
    jexl.addBinaryOp(
      '_=',
      20,
      (left, right) => left.toLowerCase() === right.toLowerCase()
    )
    jexl.addBinaryOp(
      '^=',
      20,
      (left, right) => left.toUpperCase() === right.toUpperCase()
    )
    jexl.addBinaryOp('~=', 20, (left, right) => left.indexOf(right) >= 0)
    if (convertToCase == 'equalsIgnoreCase' || convertToCase == 'toLowerCase') {
      if (hasContains) {
        evalResult = jexl.evalSync(
          `"${left.toLowerCase()}" ~= "${right.toLowerCase()}"`
        )
      } else {
        evalResult = jexl.evalSync(`"${left}" _= "${right}"`)
      }
    } else if (convertToCase == 'toUpperCase') {
      if (hasContains) {
        evalResult = jexl.evalSync(
          `"${left.toUpperCase()}" ~= "${right.toUpperCase()}"`
        )
      } else {
        evalResult = jexl.evalSync(`"${left}" ^= "${right}"`)
      }
    }
    return evalResult
  },

  /**
   *
   * @param {logger} logger
   * @param {object} reqExpression request expression string from mapper object
   * @param {object} request json object containing the request
   * @param {object} param object containing param values that will be replaced in request matchers
   * @param {string} param.name name of parameter to be matched to requestMatcher value
   * @param {string} param.value value of parameter to be matched to requestMatcher value
   *
   * **/
  evaluateJexlRequestExpression (logger, reqExpressionObj, request, param) {
    let jwt
    let finalResult = false
    let evalResult = false
    let queryString = JSON.stringify(request.query)
    let reqExpression = reqExpressionObj.value
    // set up transforms for jexl expressions
    jexl.addBinaryOp(
      '_=',
      20,
      (left, right) => left.toLowerCase() === right.toLowerCase()
    )
    jexl.addBinaryOp(
      '^=',
      20,
      (left, right) => left.toUpperCase() === right.toUpperCase()
    )
    jexl.addBinaryOp('~=', 20, (left, right) => left.indexOf(right) >= 0)

    // clean up reqExpression
    reqExpression = reqExpression.replace(
      /httpRequest.queryString\(\)/g,
      'queryString'
    )
    reqExpression = reqExpression.replace(/\.\?/g, '.')
    reqExpression = reqExpression.replace(/ and /g, ' && ')
    reqExpression = reqExpression.replace(/ or /g, ' || ')
    let evalFinalString = reqExpression

    // evaluate contains in the reqExpression and does not contain request.body
    // request.body needs to be handled differently
    if (reqExpression.indexOf('contains') >= 0) {
      // evaluate contains
      let containsRegExpGlobal = /(\w+).?(toUpperCase|toLowerCase|ignoreCase)?\(?\)? contains \'(\w+)\'/g
      let match = reqExpression.match(containsRegExpGlobal)
      // due to possiblity of mulitple matches,
      //  need to loop through to extract out all individual grouped matches for regex
      if (match != null && match.length > 0) {
        match.forEach((m, i) => {
          let findContainsMatch = containsRegExpGlobal.exec(m)
          let evalContains = false
          if (findContainsMatch == null) {
            let containsRegExp = /(\w+).?(toUpperCase|toLowerCase|ignoreCase)?\(?\)? contains \'(\w+)\'/
            findContainsMatch = containsRegExp.exec(m)
          }
          // evaluate and replace contains
          // findContainsMatch[0] // requestExpression string
          // findContainsMatch[1] // queryString
          // findContainsMatch[2] // upperCase | lowerCase | ignoreCase
          // findContainsMatch[3] // externalId
          if (findContainsMatch.length == 4) {
            if (findContainsMatch[1] == 'queryString') {
              // if need to convertCase
              if (findContainsMatch[2]) {
                let cleanedQueryString = `${queryString.replace(/"/g, '\\"')}`
                evalResult = findMatchUtility.jexlConvertToCase(
                  findContainsMatch[2],
                  cleanedQueryString,
                  findContainsMatch[3],
                  true
                )
                // evaluate and replace jwtObjString in rqExpression
                evalFinalString = evalFinalString.replace(
                  findContainsMatch[0],
                  evalResult
                )
              } else {
                // remove escape any " in the queryString
                let myString = `"${queryString.replace(
                  /"/g,
                  '\\"'
                )}" ~= "${findContainsMatch[3].replace(/"/g, '\\"')}"`
                // use evalSync with request object
                evalContains = jexl.evalSync(myString, request)
                evalFinalString = evalFinalString.replace(
                  findContainsMatch[0],
                  evalContains
                )
              }
            } else if (param) {
              // check if matching again request.body
              if (findContainsMatch[1] == 'body') {
                // evaluate request expression using request object
                evalContains = jexl.evalSync(
                  `"${findContainsMatch[1]}" ~= "${findContainsMatch[3]}"`,
                  request
                )
                // replace the jexl eval result with 'request.body()' instead of just 'body()'
                if (evalFinalString.indexOf('request.body()') >= 0) {
                  let regex = RegExp(`request.${findContainsMatch[0]}`, 'g')
                  evalFinalString = evalFinalString.replace(regex, evalContains)
                } else {
                  evalFinalString = evalFinalString.replace(
                    `${findContainsMatch[0]}`,
                    evalContains
                  )
                }
              } else {
                // handle standard case where 'body' in the request expression
                evalContains = jexl.evalSync(
                  `"${param.value}" ~= "${findContainsMatch[3]}"`
                )
                evalFinalString = evalFinalString.replace(
                  findContainsMatch[0],
                  evalContains
                )
              }
            } else {
              logger.info(`UNABLE to evaluate expression: ${m}`)
            }
          }
        })
      }
    }
    // evaluate jwt token
    //  extract jwt token from request if it's required AND exist
    if (reqExpression.indexOf('jwt.') >= 0) {
      let decodedjwtObj = {}
      if (request.headers && request.headers.hasOwnProperty('JWT-Token')) {
        let auth = request.headers['JWT-Token']
        if (auth.indexOf('Bearer ') >= 0) {
          // strip out 'Bearer ' from jwt token
          jwt = auth.replace('Bearer ', '')

          // handle requestExpression with jwt
          decodedjwtObj = jwt_decode(jwt)
        }
      }

      // extract out jwt.claims expression
      let jwtObjectRegExp = /([\w\.]+)\.(equalsIgnoreCase|toUpperCase|toLowerCase)(\(\) == '([\w@.]+)'|\('([\w@.]+)'\))/
      let jwtObjFindMatch = evalFinalString.match(jwtObjectRegExp)
      // if match found then jwtObjFindMatch == 6
      if (jwtObjFindMatch != null && jwtObjFindMatch.length == 6) {
        // jwtObjFindMatch[0] => sub-match request expression
        // jwtObjFindMatch[1] => jwt object
        // jwtObjFindMatch[2] => equalsIgnoreCase || toUpperCase || toLowerCase
        // jwtObjFindMatch[5] => "equalsIgnoreCase('CSPUsr7') == true" ==> CSPUsr7
        // OR
        // jwtObjFindMatch[4] => "equalsIgnoreCase() == 'CSPUsr7'" ==> CSPUSR7
        // strip out 'jwt.claims.' from jwt object string in request expression
        let jwtObjToFind = jwtObjFindMatch[1].replace('jwt.claims.', '')
        // determine if pattern is like "equalsIgnoreCase('CSPUsr7') == true" OR "equalsIgnoreCase() == 'CSPUsr7'"
        let jwtObjFindMatchValue = jwtObjFindMatch[4]
          ? jwtObjFindMatch[4]
          : jwtObjFindMatch[5]
        // determine what conversion needs to happen > equalsIgnoreCase || toUpperCase || toLowerCase
        let jwtObjConvertCase = jwtObjFindMatch[2]
        // extract out value from jwtObj
        let jwtObjValue = jexl.evalSync(jwtObjToFind, decodedjwtObj)
        let jwtEvalResult = findMatchUtility.jexlConvertToCase(
          jwtObjConvertCase,
          jwtObjValue,
          jwtObjFindMatchValue
        )
        // evaluate and replace jwtObjString in rqExpression
        evalFinalString = evalFinalString.replace(
          jwtObjFindMatch[0],
          jwtEvalResult
        )
      }
    }

    // evaluate request.headers in reqExpression
    if (reqExpression.indexOf('request.headers') >= 0) {
      let headerRegExp = /(request.headers?\('([\w-]+)'\))(?:\s+)?!?==?=?(?:\s+)?'?([\w-]+)'?/
      let headerObjFindMatch = evalFinalString.match(headerRegExp)
      if (headerObjFindMatch != null && headerObjFindMatch.length == 4) {
        // headerObjFindMatch[1] // header expression
        // headerObjFindMatch[2] // header element
        // headerObjFindMatch[3] // header value
        let getHeaderValue = headerObjFindMatch[2]

        // check if request.headers have 'getHeaderValue'
        //  if not, set to false
        let reqHeaderValue = false
        // if getHeaderValue is found in the req header, then need value in quotes,
        //  if not (eg. match against null) then don't have quotes
        if (request.headers.hasOwnProperty(getHeaderValue)) {
          reqHeaderValue = request.headers[getHeaderValue]
            ? `'${request.headers[getHeaderValue]}'`
            : `${request.header[getHeaderValue]}`
        }
        // only replace part of req expression then mentions header object
        evalFinalString = evalFinalString.replace(
          headerObjFindMatch[1],
          `${reqHeaderValue}`
        )
      }
    }

    // evaluate convertCase [equalsIgnoreCase || toUpperCase || toLowerCase] in reqExpression
    if (
      reqExpression.indexOf('equalsIgnoreCase') >= 0 ||
      reqExpression.indexOf('toUpperCase') >= 0 ||
      reqExpression.indexOf('toLowerCase') >= 0
    ) {
      let convertCaseRegExp = /((\w+)\.(toUpperCase|toLowerCase|equalsIgnoreCase)?\(?'?(\w+)?'?\)?) == '?(\w+)'?/
      let convertObjFindMatch = evalFinalString.match(convertCaseRegExp)

      if (convertObjFindMatch != null && convertObjFindMatch.length == 6) {
        // convertObjFindMatch[1] // convertObj expression
        // convertObjFindMatch[2] // param obj
        // convertObjFindMatch[3] // convertCase String - toUpperCase|toLowerCase|equalsIgnoreCase
        // convertObjFindMatch[4] // convertCaseObj value
        // convertObjFindMatch[5] // match value

        // if param name matches the obj match in req expression
        if (param && param.name == convertObjFindMatch[2]) {
          let convertObjFindMatchValue = convertObjFindMatch[4]
            ? convertObjFindMatch[4]
            : convertObjFindMatch[5]
          let convertObjEvalResult = findMatchUtility.jexlConvertToCase(
            convertObjFindMatch[3],
            param.value,
            convertObjFindMatchValue
          )
          if (convertObjFindMatch[4]) {
            // for match: userId.equalsIgnoreCase('bbdsm1') == true
            evalFinalString = evalFinalString.replace(
              convertObjFindMatch[1],
              `${convertObjEvalResult}`
            )
          } else {
            // for match: userId.equalsIgnoreCase() == 'bbdsm1'
            evalFinalString = evalFinalString.replace(
              convertObjFindMatch[0],
              `${convertObjEvalResult}`
            )
          }
        } else {
          // default result to false
          evalFinalString = evalFinalString.replace(
            convertObjFindMatch[0],
            `false`
          )
        }
      }
    }

    // catch all check if 'request.body' is not cleaned up
    if (evalFinalString.indexOf('request.body') >= 0) {
      evalFinalString = evalFinalString.replace(/request.body\(\)/g, 'body')
      evalFinalString = evalFinalString.replace(/contains/g, '~=')
    }

    // if param exists then add to request object
    if (param && param.hasOwnProperty('name')) {
      request[param.name] = param.value
    }

    // evaluate requestExpression
    if (
      reqExpression.indexOf('request.queryString') >= 0 ||
      reqExpression.indexOf('queryString') >= 0
    ) {
      // handle if queryString is JSON object
      try {
        let updatedReqExpression = reqExpression.replace(
          /request\.queryString|queryString\./g,
          ''
        )
        finalResult = jexl.evalSync(updatedReqExpression, request.query)
      } catch (e) {
        // ignore error
        logger.info(`error: ${e}`)
      }
    } else {
      try {
        finalResult = jexl.evalSync(evalFinalString, request)
      } catch (e) {
        logger.info(
          `Unable to evaluate jexl expression: ${evalFinalString} | error: ${e}`
        )
      }
    }
    return finalResult
  }
}

module.exports = findMatchUtility
