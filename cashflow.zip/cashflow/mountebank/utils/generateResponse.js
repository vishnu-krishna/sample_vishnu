const _ = require('lodash')
const fs = require('fs')
const path = require('path')

let generateResponseUtility = {
  /**
   *
   * @param {logger} logger
   * @param {object} matchingResponse json object containing the matching request
   * @param {object} param json object containing objects
   * @param {string} pathToTemplatesFolder string
   *
   * **/
  generateMatchingResponse (
    logger,
    matchingResponse,
    param,
    pathToTemplatesFolder
  ) {
    var response = {}
    // check if responseFile property exists, if it doesn't return empty body
    if (matchingResponse.hasOwnProperty('responseFile')) {
      var rspFileName = matchingResponse.responseFile
      logger.info(
        `Match found for [${JSON.stringify(
          matchingResponse.requestMatcher
        )}] return file [${rspFileName}]`
      )

      if (param && param.hasOwnProperty('name')) {
        // check for and replace param name in responseFile value
        let regex = `.*\\$\\{${param.name}\\}.*`
        let pResponseFile = matchingResponse.responseFile.match(regex)
        if (pResponseFile) {
          rspFileName = matchingResponse.responseFile.replace(
            `\$\{${param.name}\}`,
            `${param.value}`
          )
          logger.info(`replace responseFile value with: ${rspFileName}`)
        }
      }

      var responseFilePath = path.join(pathToTemplatesFolder, rspFileName)
      response.body = fs.readFileSync(responseFilePath, 'utf-8')
    } else {
      response.body = ''
    }

    response.statusCode = parseInt(matchingResponse.statusCode)
    response.headers = matchingResponse.responseHeaders

    return response
  },

  /**
   *
   * @param {logger} logger
   * @param {string} applicableTo string to define applicable to value
   * @param {object} applyLookupObj filtered list of lookup matches
   * @param {string} pathToTemplatesFolder
   * @param {object} defaultStatusCode
   * @param {integer} defaultStatusCode.default
   * @param {integer} defaultStatusCode.notFound
   * @returns {object} response
   * @returns {string} response.body
   * @returns {string} response.headers
   * @returns {string} response.statusCode
   * **/
  generateDefaultResponse (
    logger,
    applicableTo,
    applyLookupObj,
    pathToTemplatesFolder,
    defaultStatusCode
  ) {
    var response = {}
    // set default values
    if (!defaultStatusCode.hasOwnProperty('default')) {
      defaultStatusCode.default = 200
    }

    if (!defaultStatusCode.hasOwnProperty('notFound')) {
      defaultStatusCode.notFound = 500
    }

    logger.info(`find default response for applicableTo [ ${applicableTo} ]`)
    var defaultResponse = _.find(applyLookupObj, function (findMatch) {
      return findMatch.applicableTo == applicableTo && findMatch.defaultResponse
    })

    // look for default response if defined in mapper json
    if (!_.isUndefined(defaultResponse)) {
      if (defaultResponse.hasOwnProperty('responseFile')) {
        var responseFilePath = path.join(
          pathToTemplatesFolder,
          defaultResponse.responseFile
        )
        response.body = fs.readFileSync(responseFilePath, 'utf-8')
      } else {
        logger.info('default response has no responseFile set')
        response.body = ''
      }
      // if no statusCode returned from response, then use defaultResponse values
      response.statusCode = isNaN(parseInt(defaultResponse.statusCode))
        ? defaultStatusCode.default
        : parseInt(defaultResponse.statusCode)
      logger.info(
        `default response found:  file: ${
          defaultResponse.responseFile
        } | status code: ${response.statusCode}`
      )
    } else {
      logger.info('default response not found')
      response.statusCode = defaultStatusCode.notFound
      response.body = ''
    }

    // Use default match if not match found
    logger.info('Use Default Response ..')
    response.statusCode = !response.statusCode
      ? defaultStatusCode.default
      : response.statusCode

    return response
  }
}

module.exports = generateResponseUtility
