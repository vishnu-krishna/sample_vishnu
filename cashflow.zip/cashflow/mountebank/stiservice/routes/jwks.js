module.exports = function handleGet (request, state, logger) {
  console.info('Incoming Request', { url: request.path, query: request.query })

  const tokenUtils = require(`${
    process.env.INJECT_EXEC_TO_PROJECT_HOME
  }/mountebank/stiservice/public/javascripts/tokenUtils.js`)
  const jwkSet = JSON.stringify(tokenUtils.getJWKSet())
  return {
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Access-Control-Allow-Origin': '*',
      Connection: 'keep-alive',
      'Content-Length': Buffer.byteLength(jwkSet)
    },
    statusCode: 200,
    body: jwkSet
  }
}
