/**
 * Handler for Authorize POST request
 * @param request
 * @param state
 * @param logger
 * @returns {{body: string, statusCode: number}}
 */
module.exports = function handlePost (request, state, logger) {
  const bodyData = JSON.parse(request.body)

  console.info('Incoming Request', { url: request.url, body: bodyData })

  const tokenUtils = require(`${
    process.env.INJECT_EXEC_TO_PROJECT_HOME
  }/mountebank/stiservice/public/javascripts/tokenUtils.js`)
  const { getValuesFromQueryData } = require(`${
    process.env.INJECT_EXEC_TO_PROJECT_HOME
  }/mountebank/stiservice/routes/utils.js`)

  const accessToken = tokenUtils.generateAccessToken(
    getValuesFromQueryData(bodyData)
  )
  const idToken = tokenUtils.generateIdToken(getValuesFromQueryData(bodyData))
  const auth_response = {
    access_token: accessToken,
    id_token: idToken,
    token_type: 'Bearer',
    expires_in: process.env.EXPIRES_IN ? process.env.EXPIRES_IN : 900,
    scope: request.body.scope
  }

  const responseBody = JSON.stringify(auth_response)
  return {
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Access-Control-Allow-Origin': '*',
      Connection: 'keep-alive',
      'Content-Length': Buffer.byteLength(responseBody)
    },
    statusCode: 200,
    body: responseBody
  }
}
