/**
 * Handler for Authorize GET request
 *
 * @param request
 * @param state
 * @param logger
 * @returns {{headers: {Location: string}, statusCode: number}}
 */
module.exports = function handleGet (request, state, logger) {
  console.info('Incoming Request', { url: request.path, query: request.query })

  const buildUrl = require('build-url')
  const tokenUtils = require(`${
    process.env.INJECT_EXEC_TO_PROJECT_HOME
  }/mountebank/stiservice/public/javascripts/tokenUtils.js`)
  const { getValuesFromQueryData } = require(`${
    process.env.INJECT_EXEC_TO_PROJECT_HOME
  }/mountebank/stiservice/routes/utils.js`)

  const queryData = request.query
  const access_token = tokenUtils.generateAccessToken(
    getValuesFromQueryData(queryData)
  )

  queryData.at_hash = tokenUtils.hashAccessToken(access_token)

  console.error(getValuesFromQueryData(queryData))

  const redirect_url = buildUrl(queryData.redirect_uri, {
    queryParams: {
      expires_at: 10,
      scope: queryData.scope,
      nonce: queryData.nonce,
      state: queryData.state,
      expires_in: process.env.EXPIRES_IN ? process.env.EXPIRES_IN : 900,
      token_type: 'Bearer',
      id_token: tokenUtils.generateIdToken(getValuesFromQueryData(queryData)),
      access_token: access_token
    }
  })

  // console.info(redirect_url)

  return {
    headers: {
      Location: redirect_url
    },
    statusCode: 302
  }
}
