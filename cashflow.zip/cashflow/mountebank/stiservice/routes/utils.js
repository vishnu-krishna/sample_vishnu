function getValuesFromQueryData (queryData) {
  let sub = process.env.SUBJECT
  const expires_in = process.env.EXPIRES_IN ? process.env.EXPIRES_IN : 900
  console.info('expires_in :: ' + expires_in)
  const groups = process.env.LDAP_GROUPS
    ? process.env.LDAP_GROUPS.split(',')
    : []
  console.info('groups to be added in ID Token :: ' + groups)
  if (queryData.username) sub = queryData.username
  else if (global.subject) sub = global.subject

  return {
    client_id: queryData.client_id,
    nonce: queryData.nonce,
    subject: sub || process.env.TOKEN_SUB,
    scope: queryData.scope,
    at_hash: queryData.at_hash,
    expires_in: expires_in,
    issuer_url: process.env.ISSUER_URL,
    groups: groups
  }
}

module.exports = {
  getValuesFromQueryData: getValuesFromQueryData
}
