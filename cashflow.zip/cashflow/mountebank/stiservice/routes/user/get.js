/**
 *
 * @param request
 * @param state
 * @param logger
 * @returns {{headers: {"Access-Control-Allow-Origin": string, Connection: string, "Content-Length": number, "Content-Type": string}, body: string, statusCode: number}}
 */
module.exports = function handleGet (request, state, logger) {
  console.info('Incoming Request', { url: request.path })

  const tokenUtils = require(`${
    process.env.INJECT_EXEC_TO_PROJECT_HOME
  }/mountebank/stiservice/public/javascripts/tokenUtils.js`)

  const sub = JSON.stringify({
    sub: tokenUtils.getUserInfo(request.headers['Authorization'])
  })
  return {
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Access-Control-Allow-Origin': '*',
      Connection: 'keep-alive',
      'Content-Length': Buffer.byteLength(sub)
    },
    statusCode: 200,
    body: sub
  }
}
