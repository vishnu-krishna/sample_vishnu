/**
 * Created by renganr1 on 4/20/18.
 */
const winston = require('winston')

//libraries for JWT signing
const jwt = require('jsonwebtoken')
const fs = require('fs')

//library for token hashing
const jsrsasign = require('jsrsasign')

function generateIdToken (queryData) {
  winston.info('Generating ID Token for client_id :: ' + queryData.client_id)

  const iat = Math.floor(new Date().getTime() / 1000)

  const id_token = {
    aud: queryData.client_id,
    nonce: queryData.nonce,
    acr: 'IAL3.AAL1.FAL1',
    iat: iat,
    sub: queryData.subject,
    at_hash: queryData.at_hash,
    amr: ['wia'],
    iss: queryData.issuer_url,
    exp: Number(iat) + Number(queryData.expires_in),
    groups: queryData.groups
  }

  return signToken(id_token)
}

function generateAccessToken (queryData) {
  winston.info(
    'Generating Access Token for client_id :: ' + queryData.client_id
  )

  const iat = Math.floor(new Date().getTime() / 1000)

  const access_token = {
    aud: queryData.client_id,
    acr: 'IAL3.AAL1.FAL1',
    iat: Math.floor(new Date().getTime() / 1000),
    sub: queryData.subject,
    amr: ['wia'],
    iss: queryData.issuer_url,
    scopes: queryData.scope.split(' '),
    exp: Number(iat) + Number(queryData.expires_in)
  }

  return signToken(access_token)
}

function getJWKSet () {
  winston.info('Returning JWK Set')
  // const pub_cert = fs.readFileSync('./public/certs/public.pem');  // get public key
  const jwks = {
    keys: [
      {
        alg: 'RS256',
        key_ops: ['verify'],
        e: 'AQAB',
        n:
          's3JmBmGvJUyiUjYvcAciRwNLXdnXjsNrpLA--7z19Z-kF6h_Ui455uIoB5jODRFiL5XFH7Y6IC5wwPgWfWDVapOEft4aR5ZMlImJNQeY8UMHbs2itmIVnWmIocf_V4i4Dfu3dds85x23KOWB3jxGYcqhItO6bGJho-ty6M_5pMhPtm8w7diJqyE3Vo-tbO9ojECjK6IdT4QXZRixSl7uQqyhN_ftg-9S3ZLmeaD2hJi9ONQZBrsfMW2AgXw3QpqmmgqDiBpOe20drGK2_ps6j-6O3CVfE4zGfIwwLD56WqPYvTGt_rQhNzqzGfaNn1Lpoy-_6-4l0wcBpl2xsujLBw',
        kty: 'RSA',
        use: 'sig',
        kid: 'F3F8PShvxS76_6neac53dkVUJvXYNhSoII5U3k3fmok'
      }
    ]
  }
  return jwks
}

function getUserInfo (authorization) {
  winston.info('Generating userInfo response ' + authorization)

  // stripping off the Bearer keyword
  const decoded_token = jwt.decode(authorization.substr(7))

  winston.info(decoded_token)

  // we are interested only in the subject
  return decoded_token.sub
}

function signToken (payload) {
  //sign with RSA SHA256
  const private_cert = fs.readFileSync(
    'mountebank/stiservice/public/certs/private.pem'
  ) // get private key
  return jwt.sign(payload, private_cert, {
    algorithm: 'RS256',
    keyid: 'F3F8PShvxS76_6neac53dkVUJvXYNhSoII5U3k3fmok'
  })
}

// function verifyToken (signedToken) {
//   // verify a token asymmetric
//   const pub_cert = fs.readFileSync(
//     'mountebank/stiservice/public/certs/public.pem'
//   ) // get public key
//   jwt.verify(signedToken, pub_cert, function (err, decoded_token) {
//     winston.info(decoded_token)
//   })
// }

function hashAccessToken (accessToken) {
  const hash = jsrsasign.crypto.Util.hashString(accessToken, 'sha256')
  const left = hash.substr(0, hash.length / 2)
  return jsrsasign.hextob64u(left)
}

module.exports = {
  generateIdToken: generateIdToken,
  generateAccessToken: generateAccessToken,
  // verifyToken: verifyToken,
  getJWKSet: getJWKSet,
  getUserInfo: getUserInfo,
  hashAccessToken: hashAccessToken
}
