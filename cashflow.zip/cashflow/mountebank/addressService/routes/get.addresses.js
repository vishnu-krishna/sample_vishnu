module.exports = function (request, state, logger) {
  logger.info('addressService :: get.addresses is called >> ')

  const fs = require('fs')
  const path = require('path')
  const reqPath = request.path

  const matchUtils = require(`${
    process.env.INJECT_EXEC_TO_PROJECT_HOME
  }/mountebank/utils/findResponse.js`)
  const generateResponse = require(`${
    process.env.INJECT_EXEC_TO_PROJECT_HOME
  }/mountebank/utils/generateResponse.js`)
  const utils = require(`${
    process.env.INJECT_EXEC_TO_PROJECT_HOME
  }/mountebank/utils/utils.js`)

  // clean and parse request.query before passing into find matching response
  //  sometimes have errant " in the request.query value

  request.query = utils.cleanRequestQuery(request.query)
  logger.info(`cleaned request.query: ${JSON.stringify(request.query)}`)
  let param = {}

  // get map json object to determine applicableTo file mapping
  let responseMapFile = path.join(
    'mountebank/addressService/mapping',
    'address-search.json'
  )

  // determine applicable to from request query search object
  let applicableTo = 'address-search'
  let lookupObj = JSON.parse(fs.readFileSync(responseMapFile))

  let findMatch = false
  let filteredLookupObj = lookupObj[applicableTo]
  let response

  findMatch = matchUtils.findMatchingResponseForJSON(
    logger,
    request,
    filteredLookupObj,
    applicableTo,
    param
  )

  let templateFilePath = 'mountebank/addressService/responses/address'
  let defaultStatusCode = {}
  defaultStatusCode.default = 200

  if (findMatch && findMatch.hasOwnProperty('responseFile')) {
    response = generateResponse.generateMatchingResponse(
      logger,
      findMatch,
      param,
      templateFilePath
    )
  } else {
    logger.info('Find Default Response')
    response = generateResponse.generateDefaultResponse(
      logger,
      applicableTo,
      filteredLookupObj,
      templateFilePath,
      defaultStatusCode
    )
  }

  logger.info('Send Response ..')

  if (!response.headers) {
    response.headers = {
      'HTTP-Response-Code': `${response.statusCode}`,
      'HTTP-Response-Code-Text': 'OK',
      'Content-Type': 'application/json'
    }
  }
  return {
    headers: response.headers,
    statusCode: response.statusCode,
    body: response.body
  }
}
