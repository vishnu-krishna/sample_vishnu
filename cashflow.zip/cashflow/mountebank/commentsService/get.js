function match (request, state, logger) {
  logger.info('Comments Service GET is called')

  const fs = require('fs')

  let responseCode = 200
  let reqPath = request.path
  const method = request.method.toLowerCase()

  const JSONPath = `mountebank/commentsService/response/comments/get.json`

  let body = null
  if (JSONPath) {
    body = JSON.parse(fs.readFileSync(JSONPath))
  }

  return {
    headers: {
      'Content-Type': 'application/json'
    },
    statusCode: responseCode,
    body: JSON.stringify(body)
  }
}
