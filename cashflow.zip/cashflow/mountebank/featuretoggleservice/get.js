function match (request, state, logger) {
  logger.info('featuretoggleservice GET is called')

  const fs = require('fs')

  let responseCode = 200
  let reqPath = request.path
  const method = request.method.toLowerCase()
  console.log('reqPath', reqPath)

  const splitReqPath = reqPath.split('/')
  const feature = splitReqPath[splitReqPath.length - 1]

  console.log('received feature', feature)

  let featureToBeActive

  switch (feature) {
    case 'com.anz.csp.bbd.cashflow.r2.2':
      featureToBeActive = 'FEATURE_R2_2_ACTIVE'
      break
    case 'com.anz.csp.bbd.cashflow.scratchpad':
      featureToBeActive = 'FEATURE_SCRATCH_PAD_ACTIVE'
      break
  }

  let filename = process.env[featureToBeActive]
    ? `${method}-active.json`
    : `${method}-inactive.json`

  const JSONPath = `${reqPath.replace(
    '/api/featuretoggleservice',
    'mountebank/featuretoggleservice/response'
  )}/${filename}`
  console.log('jsonPath', JSONPath)

  let body = null
  if (JSONPath) {
    body = JSON.parse(fs.readFileSync(JSONPath))
  }

  return {
    headers: {
      'Content-Type': 'application/json'
    },
    statusCode: responseCode,
    body: JSON.stringify(body)
  }
}
