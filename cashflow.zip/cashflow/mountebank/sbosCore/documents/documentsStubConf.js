function match (request, state, logger) {
  logger.info('sbosCore Service is called!')

  const fs = require('fs')
  const path = require('path')

  const reqPath = request.path
  const method = request.method.toLowerCase()
  const responseBaseDir = path.join(
    'mountebank',
    'sbosCore',
    'responses',
    'documents'
  )
  let responsePath = null
  let statusCode = 200
  const getResponsePath = jsonFile => {
    return path.join(responseBaseDir, `${jsonFile}.json`)
  }

  const [appId] = reqPath.match(/\d+/)
  switch (parseInt(appId)) {
    case 1000000101:
      responsePath = getResponsePath('1000000101')
      break
    case 1000000001:
      responsePath = getResponsePath('1000000001')
      break
    case 1000002013:
      responsePath = getResponsePath('1000002013')
      break
    default:
      responsePath = getResponsePath('default')
  }

  if (!fs.existsSync(responsePath)) {
    return {
      headers: {
        'Content-Type': 'application/json'
      },
      statusCode: 404
    }
  }

  let body = state[responsePath]
  if (responsePath && !body) {
    body = JSON.parse(fs.readFileSync(responsePath))
    state[responsePath] = body
    console.error(responsePath)
  }
  if (method !== 'get') {
    body = {}
  }

  return {
    headers: {
      'Content-Type': 'application/json'
    },
    statusCode: statusCode,
    body: JSON.stringify(body)
  }
}
