function match (request, state, logger) {
  logger.info('sbosCore Service consent-button is called!')

  const fs = require('fs')
  const path = require('path')

  const reqPath = request.path
  const method = request.method.toLowerCase()
  const query = request.query

  console.log(reqPath)

  const responseBaseDir = path.join(
    'mountebank',
    'sbosCore',
    'responses',
    'consent-buttonControl'
  )
  let responsePath = null
  let statusCode = 201
  const getResponsePath = jsonFile => {
    return path.join(responseBaseDir, `${jsonFile}.json`)
  }

  const [appId] = reqPath.match(/\d+/)
  switch (parseInt(appId)) {
    case 4:
      if (query && query.action === 'remove') {
        responsePath = getResponsePath('201_not_require')
      } else {
        responsePath = getResponsePath('201')
      }
      statusCode = 201
      break
    case 5:
      if (method === 'put') {
        responsePath = getResponsePath('201_package_failed')
        statusCode = 200
      } else {
        responsePath = getResponsePath('201_request_failed')
        statusCode = 201
      }
      break
    case 6:
      responsePath = getResponsePath('201')
      statusCode = 201
      break
    case 7:
      responsePath = getResponsePath('201')
      break
    default:
      if (query && query.action === 'remove') {
        responsePath = getResponsePath('201_not_require')
      } else {
        responsePath = getResponsePath('201')
      }
  }

  if (!fs.existsSync(responsePath)) {
    return {
      headers: {
        'Content-Type': 'application/json'
      },
      statusCode: 404
    }
  }

  let body = state[responsePath]
  if (responsePath && !body) {
    body = JSON.parse(fs.readFileSync(responsePath))
    state[responsePath] = body
    console.error(responsePath)
  }
  if (method !== 'post' && method !== 'put') {
    body = {}
  }

  return {
    headers: {
      'Content-Type': 'application/json'
    },
    statusCode: statusCode,
    body: JSON.stringify(body)
  }
}
