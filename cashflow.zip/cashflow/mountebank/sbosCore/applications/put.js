function match (request, state, logger) {
  logger.info('save application has been called!')

  const method = request.method.toLowerCase()
  const requestBody = JSON.parse(request.body)
  const reqPath = request.path
  const JSONPath = `${reqPath.replace(
    '/api/sbosCore/',
    'mountebank/sbosCore/responses/'
  )}/${method}.json`.replace('put.json', 'get.json')

  let responseCode = 200

  const key = `response.put.${method}`

  requestBody.applicationVersion++

  const response = state[key] || {
    orderNumber: requestBody.applicationId,
    version: requestBody.applicationVersion,
    createdDateTime: new Date(),
    revision: 2
  }

  response.createdDateTime = new Date()
  state[key] = response

  //Following step makes the put call to a get call response and set as get call state hence retains the value entered
  state[JSONPath] = { application: requestBody }
  console.error(JSONPath)

  return {
    statusCode: responseCode,
    body: JSON.stringify(response)
  }
}
