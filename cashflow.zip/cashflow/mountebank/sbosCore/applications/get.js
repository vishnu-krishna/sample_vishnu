function match (request, state, logger) {
  const fs = require('fs')
  const reqPath = request.path
  const method = request.method.toLowerCase()
  const queryParams = request.query

  const JSONPath = `${reqPath.replace(
    '/api/sbosCore/',
    'mountebank/sbosCore/responses/'
  )}/${method}.json`

  logger.info(`${reqPath} is called - start`)

  const headers = {
    'Content-Type': 'application/json'
  }

  if (!fs.existsSync(JSONPath)) {
    return {
      headers: headers,
      statusCode: 404
    }
  }

  const body = JSON.parse(fs.readFileSync(JSONPath))

  const entityType = queryParams.summaryType

  if (
    entityType &&
    body.customerProfile.customerType.toLowerCase() !== entityType
  ) {
    return {
      headers: headers,
      statusCode: 404
    }
  }

  return {
    headers: headers,
    statusCode: 200,
    body: body
  }
}
