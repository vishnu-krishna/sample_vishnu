function match (request, state, logger) {
  logger.info('relinkCustomer has been called!')

  const path = require('path')

  const INFLIGHT_FILE = () =>
    path.join('mountebank', 'sbosCore', 'responses', 'inflight.json')

  const SUCCESSFUL_FILE = () =>
    path.join('mountebank', 'sbosCore', 'responses', 'successful.json')

  const getApplicationId = reqPath => reqPath.split('/')[4]
  const getEntityId = reqPath => reqPath.split('/')[6]

  const statusApplication = (inflightData, applicationId) => {
    const summaries = inflightData.frontline.summaries
    const application = summaries.find(
      app => app.applicationId === applicationId
    )
    application.status = 'PENDING_CUSTOMER_LINK'

    return application
  }

  let responseCode = 200
  let reqPath = request.path

  const applicationId = getApplicationId(reqPath)
  const entityId = getEntityId(reqPath)
  const inflightData = state[INFLIGHT_FILE()]
  const application = statusApplication(inflightData, applicationId)

  return {
    statusCode: responseCode
  }
}
