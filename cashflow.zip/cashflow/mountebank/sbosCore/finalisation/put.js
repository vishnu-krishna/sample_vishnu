function match (request, state, logger) {
  logger.info('Finalisation has been called!')

  const path = require('path')

  const SUCCESSFUL_FILE = () =>
    path.join('mountebank', 'sbosCore', 'responses', 'successful.json')

  const getApplicationId = reqPath => {
    reqPath
      .replace('/api/sbosCore/applications/', '')
      .replace('/states/finalise', '')
  }

  const finaliseApplication = (successfulData, applicationId) => {
    const summaries = successfulData.frontline.summaries
    const application = summaries.find(
      app => app.applicationId === applicationId
    )
    application.status = 'FINALISED'

    return application
  }

  let responseCode = 200
  let reqPath = request.path

  const applicationId = getApplicationId(reqPath)

  const successfulData = state[SUCCESSFUL_FILE()]
  finaliseApplication(successfulData, applicationId)

  return {
    headers: {
      'Content-Type': 'application/json'
    },
    statusCode: responseCode,
    body: { finalisationDate: new Date(Date.now()) }
  }
}
