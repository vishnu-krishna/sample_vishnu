function match (request, state, logger) {
  logger.info('assign-person has been called!')

  const path = require('path')

  const INFLIGHT_FILE = () =>
    path.join('mountebank', 'sbosCore', 'responses', 'inflight.json')
  const SUCCESSFUL_FILE = () =>
    path.join('mountebank', 'sbosCore', 'responses', 'successful.json')

  const getApplicationId = reqPath =>
    reqPath
      .replace('/api/sbosCore/applications/', '')
      .replace('/assigned-persons', '')

  const updateApplication = (applicationId, requestBody) => {
    const matchAppId = app => app.applicationId === applicationId
    const inflightData = state[INFLIGHT_FILE()]
    const successData = state[SUCCESSFUL_FILE()]

    console.error(successData)

    let application = inflightData.frontline.summaries.find(matchAppId)

    if (!application) {
      application = successData.frontline.summaries.find(matchAppId)
    }

    application.owner = true
    application.anzUser = requestBody.fullName
  }

  let responseCode = 200
  let reqPath = request.path

  const requestBody = JSON.parse(request.body)
  const applicationId = getApplicationId(reqPath)

  updateApplication(applicationId, requestBody)

  return {
    statusCode: responseCode
  }
}
