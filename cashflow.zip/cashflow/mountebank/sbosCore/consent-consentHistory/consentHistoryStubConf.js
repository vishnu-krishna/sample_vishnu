function match (request, state, logger) {
  logger.info('sbosCore Service consent-history is called!')

  const fs = require('fs')
  const path = require('path')

  const reqPath = request.path
  const method = request.method.toLowerCase()
  console.log(reqPath)
  console.log(method)
  const responseBaseDir = path.join(
    'mountebank',
    'sbosCore',
    'responses',
    'consent-History'
  )
  let responsePath = null
  let statusCode = 200
  const getResponsePath = jsonFile => {
    return path.join(responseBaseDir, `${jsonFile}.json`)
  }

  const [appId] = reqPath.split('/589')[1]
  switch (parseInt(appId)) {
    case 4:
      responsePath = getResponsePath('200')
      statusCode = 200
      break
    case 5:
      responsePath = getResponsePath('200')
      statusCode = 200
      break
    case 6:
      responsePath = getResponsePath('400')
      statusCode = 400
      break
    case 7:
      responsePath = getResponsePath('400')
      statusCode = 400
      break
    default:
      responsePath = getResponsePath('400')
  }
  console.log(responsePath)
  if (!fs.existsSync(responsePath)) {
    return {
      headers: {
        'Content-Type': 'application/json'
      },
      statusCode: 404
    }
  }

  let body = state[responsePath]
  if (responsePath && !body) {
    body = JSON.parse(fs.readFileSync(responsePath))
    state[responsePath] = body
    console.error(responsePath)
  }
  if (method !== 'get') {
    body = {}
  }

  return {
    headers: {
      'Content-Type': 'application/json'
    },
    statusCode: statusCode,
    body: JSON.stringify(body)
  }
}
