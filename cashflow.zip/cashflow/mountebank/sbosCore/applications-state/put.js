function match (request, state, logger) {
  logger.info('finalise application has been called!')

  let responseCode = 200

  return {
    statusCode: responseCode,
    body: JSON.stringify({})
  }
}
