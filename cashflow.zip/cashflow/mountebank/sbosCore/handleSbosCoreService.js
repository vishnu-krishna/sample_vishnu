async function match (request, state, logger) {
  logger.info('sbosCore Service is called!')

  const fs = require('fs')
  const path = require('path')
  let updateFlag = false

  const INFLIGHT_FILE = () =>
    path.join('mountebank', 'sbosCore', 'responses', 'inflight.json')
  const SUCCESSFUL_FILE = () =>
    path.join('mountebank', 'sbosCore', 'responses', 'successful.json')
  const CURRENT_USER = () =>
    path.join(
      'mountebank',
      'sbosCore',
      'responses',
      'users',
      'current',
      'get.json'
    )
  const APP_HISTORY = () =>
    path.join('mountebank', 'sbosCore', 'responses', 'app_history.json')
  const INFLIGHT_ASSIGNED_APP = appId =>
    path.join(
      'mountebank',
      'sbosCore',
      'responses',
      'applications',
      appId,
      'get.json'
    )
  const INFLIGHT_ASSIGNED_APP_V1 = appId =>
    path.join(
      'mountebank',
      'sbosCore',
      'responses',
      'applications',
      appId,
      'versions',
      '1',
      'get.json'
    )
  const CUSTOMER_SUMMARY_CF = appId =>
    path.join(
      'mountebank',
      'sbosCore',
      'responses',
      'customer-summary',
      appId,
      'applications-summaries',
      'get.json'
    )
  const EXTERNAL_APPLICATION = () =>
    path.join(
      'mountebank',
      'sbosCore',
      'responses',
      'applications',
      'external-application',
      'summaries',
      'get.json'
    )
  const CUSTOMER_SUMMARY_SBOS = appId =>
    path.join(
      'mountebank',
      'sbosCore',
      'responses',
      'customer-summary',
      appId,
      'applications-summaries',
      'getBBD.json'
    )
  const CONSENT_DOCUMENTS_SBOS = appId =>
    path.join(
      'mountebank',
      'sbosCore',
      'responses',
      'consent-documents',
      appId,
      'get.json'
    )

  const CUSTOMER_HISTORY = () =>
    path.join('mountebank', 'sbosCore', 'responses', 'app_history.json')

  const reqPath = request.path
  const query = request.query
  const method = request.method.toLowerCase()
  let JSONPath = null

  const applicationStatusType = query.applicationStatusType

  const getApplicationId = reqPath =>
    reqPath
      .replace('/api/sbosCore/applications/', '')
      .replace('/versions/1', '')
  const getCapId = reqPath =>
    reqPath
      .replace('/api/sbosCore/customer-summary/', '')
      .replace('/applications-summaries', '')
  const getDocApplicationId = reqPath =>
    reqPath
      .replace('/api/sbosCore/application/', '')
      .replace('/documents/consent', '')

  if (applicationStatusType && applicationStatusType.includes('INFLIGHT')) {
    JSONPath = INFLIGHT_FILE()
  } else if (
    applicationStatusType &&
    applicationStatusType.includes('SUCCESSFUL')
  ) {
    JSONPath = SUCCESSFUL_FILE()
  } else if (
    reqPath.startsWith('/api/sbosCore/users/current') &&
    reqPath.endsWith('')
  ) {
    JSONPath = CURRENT_USER()
  } else if (
    reqPath.startsWith('/api/sbosCore/applications') &&
    reqPath.endsWith('/history')
  ) {
    JSONPath = APP_HISTORY()
  } else if (
    reqPath.startsWith('/api/sbosCore/applications') &&
    reqPath.endsWith('/versions/1')
  ) {
    JSONPath = INFLIGHT_ASSIGNED_APP_V1(getApplicationId(reqPath))
    updateFlag = true
  } else if (
    request.headers['anz-application-id'] === 'ANZ-AU-BBD-CASHFLOW' &&
    reqPath.startsWith('/api/sbosCore/applications') &&
    reqPath.includes('external-application')
  ) {
    JSONPath = EXTERNAL_APPLICATION()
  } else if (
    reqPath.startsWith('/api/sbosCore/applications') &&
    reqPath.endsWith('')
  ) {
    JSONPath = INFLIGHT_ASSIGNED_APP(getApplicationId(reqPath))
    updateFlag = true
  } else if (
    reqPath.startsWith('/api/sbosCore/customer-summary') &&
    reqPath.endsWith('applications-summaries') &&
    request.headers['anz-application-id'] === 'ANZ-AU-BBD-CASHFLOW'
  ) {
    JSONPath = CUSTOMER_SUMMARY_CF(getCapId(reqPath))
  } else if (
    reqPath.startsWith('api/sbosCore/applications') &&
    reqPath.endsWith('/history')
  ) {
    JSONPath = CUSTOMER_HISTORY()
  } else if (
    request.headers['anz-application-id'] === 'ANZ-AU-SBOS' &&
    reqPath.startsWith('/api/sbosCore/customer-summary') &&
    reqPath.includes('applications-summaries')
  ) {
    JSONPath = CUSTOMER_SUMMARY_SBOS(getCapId(reqPath))
  } else if (
    reqPath.startsWith('/api/sbosCore/application/') &&
    reqPath.endsWith('/documents/consent')
  ) {
    JSONPath = CONSENT_DOCUMENTS_SBOS(getDocApplicationId(reqPath))
    if (!fs.existsSync(JSONPath)) {
      JSONPath = CONSENT_DOCUMENTS_SBOS('1199000003')
    }
  }

  if (!fs.existsSync(JSONPath)) {
    return {
      headers: {
        'Content-Type': 'application/json'
      },
      statusCode: 404
    }
  }

  const updateApplication = (applicationIdIs, body) => {
    if (
      (reqPath.startsWith('/api/sbosCore/applications') ||
        reqPath.endsWith('/versions/1')) &&
      updateFlag
    ) {
      const matchAppId = app => app.applicationId === applicationIdIs
      const inflightData = state[INFLIGHT_FILE()]
      if (inflightData) {
        const application = inflightData.frontline.summaries.find(matchAppId)
        if (
          application &&
          !!application.owner &&
          body.application.applicationStatus === 'PENDING_CUSTOMER_LINK'
        ) {
          body.application.isOwner = true
          return body
        }
      }
    }
    return body
  }

  let body = state[JSONPath]

  body = body ? updateApplication(getApplicationId(reqPath), body) : body

  if (JSONPath && !body) {
    body = JSON.parse(await fs.readFileSync(JSONPath))
    body = updateApplication(getApplicationId(reqPath), body)
    state[JSONPath] = body
    console.error(JSONPath)
  }

  return {
    headers: {
      'Content-Type': 'application/json'
    },
    statusCode: 200,
    body: JSON.stringify(body)
  }
}
