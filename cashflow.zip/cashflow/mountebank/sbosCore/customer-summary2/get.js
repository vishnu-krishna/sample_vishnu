function match (request, state, logger) {
  const fs = require('fs')
  const reqPath = request.path
  const method = request.method.toLowerCase()
  const queryParams = request.query

  let JSONPath = `${reqPath.replace(
    '/api/sbosCore/',
    'mountebank/sbosCore/responses/'
  )}/${method}.json`

  logger.info('customer-summary2 GET is called - start')

  const headers = {
    'Content-Type': 'application/json'
  }

  logger.info('customer-summary2 ' + JSONPath)

  const body = JSON.parse(fs.readFileSync(JSONPath))

  const entityType = queryParams.summaryType
  if (
    entityType &&
    body.customerProfile.customerType.toLowerCase() !== entityType
  ) {
    return {
      headers: headers,
      statusCode: 404
    }
  }

  const STATUS_CODE = body.customerProfile ? 200 : 500
  return {
    headers: headers,
    statusCode: STATUS_CODE,
    body: body
  }
}
