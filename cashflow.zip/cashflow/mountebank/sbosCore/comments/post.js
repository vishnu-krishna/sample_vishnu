function match (request, state, logger) {
  logger.info('sbos comments has been called!')

  const method = request.method.toLowerCase()
  const requestBody = JSON.parse(request.body)
  const reqPath = request.path
  const JSONPath = `mountebank/sbosCore/responses/comments/get.json`
  let responseCode = 200
  const fs = require('fs')

  const key = `response.post.${method}`

  requestBody.applicationVersion++
  const response = state[key] || JSON.parse(fs.readFileSync(JSONPath))

  response.createdDateTime = new Date()
  state[key] = response

  return {
    statusCode: responseCode,
    body: JSON.stringify(response)
  }
}
