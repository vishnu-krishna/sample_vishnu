/* Caters for success and failure scenarios after happy flow is complete.
Currently failures are based on facilities check section selection as yes */
function match (request, state, logger) {
  const fs = require('fs')
  const reqPath = request.path
  const body = JSON.parse(request.body)
  const method = request.method.toLowerCase()
  const JSONPath = `${reqPath.replace(
    '/api/sbosCore/',
    'mountebank/sbosCore/responses/'
  )}/${method}.json`
  const headers = {
    'Content-Type': 'application/json'
  }

  if (!fs.existsSync(JSONPath)) {
    return {
      headers: headers,
      statusCode: 404
    }
  }
  const responseBody = JSON.parse(fs.readFileSync(JSONPath))

  const isTotODAboveLimit = body.facilityVerification['isTotODAboveLimit']
  const isSoleTraderIndSame =
    body.entities.borrowers[0].proposed.companyStructureVerification
      .isSoleTraderIndSame

  if (isTotODAboveLimit || isSoleTraderIndSame === false) {
    return {
      statusCode: 200,
      body: responseBody
    }
  } else {
    return {
      statusCode: 200,
      body: []
    }
  }
}
