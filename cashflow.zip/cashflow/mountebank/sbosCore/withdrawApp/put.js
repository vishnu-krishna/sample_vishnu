function match (request, state, logger) {
  logger.info('withdrawApp has been called!')

  const path = require('path')

  const INFLIGHT_FILE = () =>
    path.join('mountebank', 'sbosCore', 'responses', 'inflight.json')

  const SUCCESSFUL_FILE = () =>
    path.join('mountebank', 'sbosCore', 'responses', 'successful.json')

  const getApplicationId = reqPath =>
    reqPath
      .replace('/api/sbosCore/applications/', '')
      .replace('/states/withdraw', '')

  const removeApplication = (inflightData, applicationId) => {
    const summaries = inflightData.frontline.summaries
    const application = summaries.find(
      app => app.applicationId === applicationId
    )
    application.status = 'WITHDRAWN'

    summaries.splice(summaries.indexOf(application), 1)
    return application
  }

  const addApplication = (successfulData, application) => {
    successfulData.frontline.summaries.push(application)
  }

  let responseCode = 200
  let reqPath = request.path

  const applicationId = getApplicationId(reqPath)

  const inflightData = state[INFLIGHT_FILE()]
  const application = removeApplication(inflightData, applicationId)

  const successfulData = state[SUCCESSFUL_FILE()]
  addApplication(successfulData, application)

  return {
    statusCode: responseCode
  }
}
