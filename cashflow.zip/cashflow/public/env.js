window.env = {
  tokenissuerUrl: "http://localhost:4997/oidc",
  tokenissuerClientId: "8069a657-a0d8-4268-92e4-c4972db8670f",
  tokenissuerClientUrl: "http://localhost:3000/",
  tokenissuerScope: "AU.ANZ_INTERNAL.ADDRESS.READ AU.RETAIL.ESIGN.ALL AU.ANZ_INTERNAL.CONSENT.ALL",
  BBD_URL: "http://localhost:9099",
}
