[![Repo Audit Status](https://repopolice.apps.omni.service.test/audit/csp/cashflow-ui/statusbadge)](https://repopolice.apps.omni.service.test/audit/csp/cashflow-ui/report)

# cashflow-ui

This is the front-end component for Cashflow Project (cashflow-ui).

Pre-processing screens have been designed for Cashflow Lending Online Applications, to enable the banker to verify the legal structure of the customer, link the customer to an existing profile in ANZ systems and perform a series of checks to ensure they are eligible for cashflow lending.

# Installing

# Install NVM

# Adding new Packages

To add any packages please use ANZ registry
make sure registy in ~/.npmrc is
registry=https://artifactory.gcp.anz/artifactory/api/npm/npmjs-org

# Node setup

# ANZ Node Dist

export NVM_NODEJS_ORG_MIRROR=https://artifactory.gcp.anz/artifactory/nodejs-dist

After NVM is installed run `nvm ls-remote`.
This will fetch nodejs from anz registry. Run `nvm use 10.16.0`.

Modify your path to make sure you have a '/usr/bin/node' path (for SourceTree users, but general good practice)

```
# Edit your '.bash_profile' to make to make it permanent

nodeLocation=$(which node)
sudo ln -s $nodeLocation /usr/bin/node
```

## Run the project

Run the commands below in terminal to start the project

- `nvm use` (this will use node 10.16.0 LTS)
- Install dependencies - `yarn install`
- Start local dev server - `yarn start`
- Run tests - `yarn test`
- Run prettier-standard to format code - `yarn format`
- Build project for production - `yarn build`
- Publish app folder as a package `yarn release`

## Storybook

Run Storybook with `yarn storybook`.

Each component should have an associated Storybook playground and should be placed in the same folder as the component
with the format `<component>.stories.js`.

## Running local stubs

- Install mountebank `npm install -g mountebank`
- Run stubs from within root directory - `yarn run-stub`
- Run stubs for R2.2 mode from within root directory  `yarn run-stub-r2_2` (will return back `ACTIVE` for R2.2 feature toggle)

## Running e2e tests

Refer to [README.md](./e2e/README.md) in `cashflow-ui/e2e`

## Contributing

Refer to [CONTRIBUTING.md](./.github/CONTRIBUTING.md) on how to contribute to this repository.

## Releasing

Refer to [https://confluence.service.anz/display/BBD/BB+Cluster+-+Release+cut+guide#BBCluster-Releasecutguide-CashflowUI](https://confluence.service.anz/display/BBD/BB+Cluster+-+Release+cut+guide#BBCluster-Releasecutguide-CashflowUI) for more information on the release process.

When generating the code coverage statistics (found here for example, [https://confluence.service.anz/display/BX/CSP+20.4+BBD#CSP20.4BBD-DevelopedCodeUnitTestCoverage](https://confluence.service.anz/display/BX/CSP+20.4+BBD#CSP20.4BBD-DevelopedCodeUnitTestCoverage)): run the following script from the root directory to automatically generate the results:

`./scripts/release-coverage.sh -n [NEW_RELEASE_SHA] -p [PREVIOUS_RELEASE_SHA]` and substitute the SHA with the last release tag (Can be a commit SHA, or more preferred the release tag found in the previous release page, eg: [https://confluence.service.anz/display/BX/CSP+20.4+BBD#CSP20.4BBD-CodeBranchCuts,BuildsandCodeScansprogress](https://confluence.service.anz/display/BX/CSP+20.4+BBD#CSP20.4BBD-CodeBranchCuts,BuildsandCodeScansprogress))

Example usage:

```
./scripts/release-coverage.sh -n 0.1.0-rc.500 -p 0.1.0-rc.420
```

After some time, that will generate the following:

```
PREVIOUS RELEASE LINE COVERAGE PERCENTAGE (A): 90.65%
PREVIOUS_RELEASE_NUMBER_OF_LINES (B): 3144
NUMBER_OF_LINES_ADDED_IN_CHANGE (C): 6
PROPORTION OF CHANGE (C/B * 100) (D) .19083969465648854900 %
NEW RELEASE LINE COVERAGE PERCENTAGE (E): 90.32%
Met code coverage increase requirements: (E - A > 0.5 * D) then true, else false
COVERAGE: -.33 COVERAGE_THRESHOLD: .09541984732824427450
Met code coverage: false
```

Plug that into the table for `Developed Code Unit Test Coverage`.


## Screen record and attach a gif, to give a snapshot of the story/bugfix in the pull request

To give a snapshot of the story/bugfix in the pull request 
(recommended but optional), refer following steps

Record the changes
- Use 'QuickTime Player' in your mac for screen recording
- File -> New Screen Recording -> Select the region -> Record
- note where the .mov file is saved

Convert .mov to .gif

- Install the following tools

`brew install ffmpeg`
`brew install gifsicle`

- From the terminalm, go to the saved .mov file location and execute the following command 
  note: the file name used here is `in.mov`

  `` ffmpeg -i in.mov -pix_fmt rgb24 -r 10 -f gif - | gifsicle --optimize=10 --delay=3 > out.gif ``

- The gif file `out.gif` is saved to the same location of the input file 
- copy and attach the file to the pull request

