#!/bin/bash

echo "Starting cashflow-ui release coverage tool..."

# extract command line arguments
while getopts ":n:p:" opt; do
      case $opt in
        p ) PREVIOUS_RELEASE_SHA="$OPTARG";;
        n ) NEW_RELEASE_SHA="$OPTARG";;
        \?) echo "Invalid option: -"$OPTARG"" >&2
            exit 1;;
      esac
    done

# early exit if mandatory arguments aren't provided
if [ ! "$PREVIOUS_RELEASE_SHA" ] || [ ! "$NEW_RELEASE_SHA" ]
then
  echo "Missing arguments. Make sure both -p and -n are provided followed by SHA values"
  exit -1
fi

echo "PREVIOUS_RELEASE_SHA: $PREVIOUS_RELEASE_SHA"
echo "NEW_RELEASE_SHA: $NEW_RELEASE_SHA"
echo "Checking out new release..."

# checkout new release, get latest code and install deps
git checkout $NEW_RELEASE_SHA
git pull
yarn install --offline --pure-lockfile

echo "Running tests on new release SHA"

# 13 lines should be enough to get the coverage summary text
# { print $3 } is the 3rd split argument from awk's text processing
NEW_RELEASE_TEST_REPORT_SUMMARY=$(yarn test | tail -n 13)

echo "------"
echo "$NEW_RELEASE_TEST_REPORT_SUMMARY"
echo "------"

# $3 is the 3rd argument to get the % coverage
NEW_RELEASE_LINE_COVERAGE_PERCENTAGE=$(echo "$NEW_RELEASE_TEST_REPORT_SUMMARY" | grep Lines | awk '{print $3}')
echo "NEW RELEASE LINE COVERAGE PERCENTAGE (E): $NEW_RELEASE_LINE_COVERAGE_PERCENTAGE"

# $5 is the argument to get the total line count
NEW_RELEASE_NUMBER_OF_LINES=$(echo "$NEW_RELEASE_TEST_REPORT_SUMMARY" | grep Lines | awk '{ print $5 }' | tr '/' '\n' | tail -n 1)
echo "NEW_RELEASE_NUMBER_OF_LINES: $NEW_RELEASE_NUMBER_OF_LINES"


git checkout $PREVIOUS_RELEASE_SHA
git pull

yarn install --offline --pure-lockfile

PREVIOUS_RELEASE_TEST_REPORT_SUMMARY=$(yarn test | tail -n 13)

PREVIOUS_RELEASE_LINE_COVERAGE_PERCENTAGE=$(echo "$PREVIOUS_RELEASE_TEST_REPORT_SUMMARY" | grep Lines | awk '{print $3}')
PREVIOUS_RELEASE_NUMBER_OF_LINES=$(echo "$PREVIOUS_RELEASE_TEST_REPORT_SUMMARY" | grep Lines | awk '{ print $5 }' | tr '/' '\n' | tail -n 1)

echo "PREVIOUS RELEASE LINE COVERAGE PERCENTAGE (A): $PREVIOUS_RELEASE_LINE_COVERAGE_PERCENTAGE"
echo "PREVIOUS_RELEASE_NUMBER_OF_LINES (B): $PREVIOUS_RELEASE_NUMBER_OF_LINES"
NUMBER_OF_LINES_ADDED_IN_CHANGE=$((NEW_RELEASE_NUMBER_OF_LINES-$PREVIOUS_RELEASE_NUMBER_OF_LINES))
echo "NUMBER_OF_LINES_ADDED_IN_CHANGE (C): $NUMBER_OF_LINES_ADDED_IN_CHANGE"
PROPORTION=$(bc -l <<< "$NUMBER_OF_LINES_ADDED_IN_CHANGE/$PREVIOUS_RELEASE_NUMBER_OF_LINES")
PROPORTION_OF_CHANGE=$(bc -l <<< $PROPORTION*100)
echo "PROPORTION OF CHANGE (C/B * 100) (D) $PROPORTION_OF_CHANGE % "
echo "NEW RELEASE LINE COVERAGE PERCENTAGE (E): $NEW_RELEASE_LINE_COVERAGE_PERCENTAGE"
echo "Met code coverage increase requirements: (E - A > 0.5 * D) then true, else false "

COVERAGE=$(bc -l <<< "$(echo $NEW_RELEASE_LINE_COVERAGE_PERCENTAGE | tr '%' ' ')-$(echo $PREVIOUS_RELEASE_LINE_COVERAGE_PERCENTAGE | tr '%' ' ')")
COVERAGE_THRESHOLD=$(bc -l <<< 0.5*$PROPORTION_OF_CHANGE)
MET_COVERAGE=$(bc -l <<< "$COVERAGE > $COVERAGE_THRESHOLD")
if [[ $MET_COVERAGE == 1 ]]; then echo "Met code coverage: true"; else echo "Met code coverage: false"; fi
