# Advanced GraphQL wtih Node.js
> Learn more advanced skills for GraphQL APIs

Check out the [slides](https://docs.google.com/presentation/d/1DaTDx2Jdolkws2xPx44ee6WuQYMiIAyaaEmN-IBaW1s/edit?usp=sharing)

## Requirements
* Node.js version `>= 6`

## Solutions
There is a solution branch
`git checkout solution`
