# GraphQL Chat Sample

Sample application used in the [GraphQL by Example](https://bit.ly/graphql-by-example) course.
